
def create_donation_flow(file_input: list[str]):
    """
    Creates a donation flow for Facebook data, explicitly trying each extractor function.
    Only creates tables for data that's available in the provided files.
    """

    return None
