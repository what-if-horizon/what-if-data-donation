window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "",
        "website" : "",
        "location" : "United Kingdom"
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1854508604444782604/maJh3zim.jpg"
    }
  }
]