window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "georgia.dagher@rhul.ac.uk",
      "createdVia" : "oauth:3033300",
      "username" : "daggeo91",
      "accountId" : "1854507704154497024",
      "createdAt" : "2024-11-07T12:55:28.588Z",
      "accountDisplayName" : "geo dag"
    }
  }
]