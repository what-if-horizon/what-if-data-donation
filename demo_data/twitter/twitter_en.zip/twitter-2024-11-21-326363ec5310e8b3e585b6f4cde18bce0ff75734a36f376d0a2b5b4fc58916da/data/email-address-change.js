window.YTD.email_address_change.part0 = [
  {
    "emailAddressChange" : {
      "accountId" : "1854507704154497024",
      "emailChange" : {
        "changedAt" : "2024-11-07T12:55:28.000Z",
        "changedTo" : "georgia.dagher@rhul.ac.uk"
      }
    }
  }
]