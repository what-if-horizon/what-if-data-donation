window.YTD.tweet_headers.part0 = [
  {
    "tweet" : {
      "tweet_id" : "1858865773487247535",
      "user_id" : "1854507704154497024",
      "created_at" : "Tue Nov 19 13:31:51 +0000 2024"
    }
  }
]