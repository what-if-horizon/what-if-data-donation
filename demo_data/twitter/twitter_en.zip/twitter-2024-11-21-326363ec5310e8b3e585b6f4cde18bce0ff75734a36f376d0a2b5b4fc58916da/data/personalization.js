window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "English",
            "isDisabled" : false
          },
          {
            "language" : "French",
            "isDisabled" : false
          },
          {
            "language" : "art (Private-Use: emoji)",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : "male"
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "Animal Crossing",
            "isDisabled" : false
          },
          {
            "name" : "Anime",
            "isDisabled" : false
          },
          {
            "name" : "Art",
            "isDisabled" : false
          },
          {
            "name" : "Arts and Crafts",
            "isDisabled" : false
          },
          {
            "name" : "Based on your searches",
            "isDisabled" : false
          },
          {
            "name" : "Birdwatching",
            "isDisabled" : false
          },
          {
            "name" : "Books",
            "isDisabled" : false
          },
          {
            "name" : "Business personalities",
            "isDisabled" : false
          },
          {
            "name" : "COVID-19",
            "isDisabled" : false
          },
          {
            "name" : "Comics",
            "isDisabled" : false
          },
          {
            "name" : "Cooking videos",
            "isDisabled" : false
          },
          {
            "name" : "Cybersecurity",
            "isDisabled" : false
          },
          {
            "name" : "Cycling",
            "isDisabled" : false
          },
          {
            "name" : "DIY",
            "isDisabled" : false
          },
          {
            "name" : "Data science",
            "isDisabled" : false
          },
          {
            "name" : "David Tennant",
            "isDisabled" : false
          },
          {
            "name" : "Elon Musk",
            "isDisabled" : false
          },
          {
            "name" : "Fashion",
            "isDisabled" : false
          },
          {
            "name" : "Fintech",
            "isDisabled" : false
          },
          {
            "name" : "Food influencers",
            "isDisabled" : false
          },
          {
            "name" : "Food inspiration",
            "isDisabled" : false
          },
          {
            "name" : "Formula 1",
            "isDisabled" : false
          },
          {
            "name" : "Funny Tweets",
            "isDisabled" : false
          },
          {
            "name" : "Gaming news",
            "isDisabled" : false
          },
          {
            "name" : "Gardening",
            "isDisabled" : false
          },
          {
            "name" : "Gordon Ramsay",
            "isDisabled" : false
          },
          {
            "name" : "History",
            "isDisabled" : false
          },
          {
            "name" : "Information security",
            "isDisabled" : false
          },
          {
            "name" : "Knitting",
            "isDisabled" : false
          },
          {
            "name" : "Lady Gaga",
            "isDisabled" : false
          },
          {
            "name" : "Language learning",
            "isDisabled" : false
          },
          {
            "name" : "Machine learning",
            "isDisabled" : false
          },
          {
            "name" : "Minecraft",
            "isDisabled" : false
          },
          {
            "name" : "Movies",
            "isDisabled" : false
          },
          {
            "name" : "Nature",
            "isDisabled" : false
          },
          {
            "name" : "News",
            "isDisabled" : false
          },
          {
            "name" : "News outlets",
            "isDisabled" : false
          },
          {
            "name" : "Nintendo",
            "isDisabled" : false
          },
          {
            "name" : "Organic foods",
            "isDisabled" : false
          },
          {
            "name" : "PewDiePie",
            "isDisabled" : false
          },
          {
            "name" : "Physics",
            "isDisabled" : false
          },
          {
            "name" : "PlayStation",
            "isDisabled" : false
          },
          {
            "name" : "Politics",
            "isDisabled" : false
          },
          {
            "name" : "Popular Videos",
            "isDisabled" : false
          },
          {
            "name" : "Reuters",
            "isDisabled" : false
          },
          {
            "name" : "Rock climbing",
            "isDisabled" : false
          },
          {
            "name" : "Science news",
            "isDisabled" : false
          },
          {
            "name" : "Seasonal cooking",
            "isDisabled" : false
          },
          {
            "name" : "Space",
            "isDisabled" : false
          },
          {
            "name" : "Space agencies & companies",
            "isDisabled" : false
          },
          {
            "name" : "SpaceX",
            "isDisabled" : false
          },
          {
            "name" : "Tech news",
            "isDisabled" : false
          },
          {
            "name" : "Tech personalities",
            "isDisabled" : false
          },
          {
            "name" : "Travel guides",
            "isDisabled" : false
          },
          {
            "name" : "US national news",
            "isDisabled" : false
          },
          {
            "name" : "United Kingdom travel",
            "isDisabled" : false
          },
          {
            "name" : "United States politics",
            "isDisabled" : false
          },
          {
            "name" : "Veganism",
            "isDisabled" : false
          },
          {
            "name" : "Viral Tweets",
            "isDisabled" : false
          },
          {
            "name" : "Virtual reality",
            "isDisabled" : false
          },
          {
            "name" : "World news",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "lookalikeAdvertisers" : [ ],
          "advertisers" : [ ],
          "doNotReachAdvertisers" : [ ],
          "catalogAudienceAdvertisers" : [ ],
          "numAudiences" : "0"
        },
        "shows" : [ ]
      },
      "locationHistory" : [ ],
      "inferredAgeInfo" : {
        "age" : [ ],
        "birthDate" : ""
      }
    }
  }
]