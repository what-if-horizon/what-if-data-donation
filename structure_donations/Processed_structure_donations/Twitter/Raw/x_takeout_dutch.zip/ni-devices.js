window.YTD.ni_devices.part0 = [
  {
    "niDeviceResponse" : {
      "pushDevice" : {
        "deviceVersion" : "10.79.2",
        "udid" : "21692C9A-AF60-4505-9222-12CEA5E873F6",
        "deviceType" : "Twitter for iOS",
        "token" : "0uPV9JEbuTWZGhYorQHTmS38x4YzJCCX14lg1Cs01ao=",
        "updatedDate" : "2025.02.08",
        "createdDate" : "2024.11.22"
      }
    }
  },
  {
    "niDeviceResponse" : {
      "pushDevice" : {
        "deviceVersion" : "10.79.2",
        "udid" : "21692C9A-AF60-4505-9222-12CEA5E873F6",
        "deviceType" : "Twitter for iOS",
        "token" : "draG1qs7oEtFTfz+SRIaY3wsUMEGN58VHTGKCc24g+U=",
        "updatedDate" : "2025.02.08",
        "createdDate" : "2024.11.22"
      }
    }
  }
]