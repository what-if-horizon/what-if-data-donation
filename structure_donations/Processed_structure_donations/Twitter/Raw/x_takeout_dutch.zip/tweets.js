window.YTD.tweets.part0 = [
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1887811860734287878"
          ],
          "editableUntil" : "2025-02-07T11:33:16.104Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Al Jazeera English",
            "screen_name" : "AJEnglish",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "4970411",
            "id" : "4970411"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1887811860734287878",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1887811860734287878",
      "created_at" : "Fri Feb 07 10:33:16 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @AJEnglish: Israeli PM Netanyahu gave US President Trump a golden pager, referencing Israel’s pager attacks on Lebanon that killed dozen…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1887811203587559587"
          ],
          "editableUntil" : "2025-02-07T11:30:39.428Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "out of context dogs",
            "screen_name" : "contextdogs",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "1408480800438374406",
            "id" : "1408480800438374406"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/contextdogs/status/1887524159426626033/photo/1",
            "source_status_id" : "1887524159426626033",
            "indices" : [
              "17",
              "40"
            ],
            "url" : "https://t.co/VM6vx3ptfk",
            "media_url" : "http://pbs.twimg.com/media/GjHVN3zWUAAsOcS.jpg",
            "id_str" : "1887524153139286016",
            "source_user_id" : "1408480800438374406",
            "id" : "1887524153139286016",
            "media_url_https" : "https://pbs.twimg.com/media/GjHVN3zWUAAsOcS.jpg",
            "source_user_id_str" : "1408480800438374406",
            "sizes" : {
              "medium" : {
                "w" : "576",
                "h" : "960",
                "resize" : "fit"
              },
              "small" : {
                "w" : "408",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "576",
                "h" : "960",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1887524159426626033",
            "display_url" : "pic.x.com/VM6vx3ptfk"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "id_str" : "1887811203587559587",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1887811203587559587",
      "possibly_sensitive" : false,
      "created_at" : "Fri Feb 07 10:30:39 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @contextdogs: https://t.co/VM6vx3ptfk",
      "lang" : "zxx",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/contextdogs/status/1887524159426626033/photo/1",
            "source_status_id" : "1887524159426626033",
            "indices" : [
              "17",
              "40"
            ],
            "url" : "https://t.co/VM6vx3ptfk",
            "media_url" : "http://pbs.twimg.com/media/GjHVN3zWUAAsOcS.jpg",
            "id_str" : "1887524153139286016",
            "source_user_id" : "1408480800438374406",
            "id" : "1887524153139286016",
            "media_url_https" : "https://pbs.twimg.com/media/GjHVN3zWUAAsOcS.jpg",
            "source_user_id_str" : "1408480800438374406",
            "sizes" : {
              "medium" : {
                "w" : "576",
                "h" : "960",
                "resize" : "fit"
              },
              "small" : {
                "w" : "408",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "576",
                "h" : "960",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1887524159426626033",
            "display_url" : "pic.x.com/VM6vx3ptfk"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1887811183727489237"
          ],
          "editableUntil" : "2025-02-07T11:30:34.693Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Why you should have a cat",
            "screen_name" : "ShouldHaveCat",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1310275768191193088",
            "id" : "1310275768191193088"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/ShouldHaveCat/status/1887367553984483571/photo/1",
            "source_status_id" : "1887367553984483571",
            "indices" : [
              "19",
              "42"
            ],
            "url" : "https://t.co/gBg5a14yp1",
            "media_url" : "http://pbs.twimg.com/media/GjFGyd6WQAAc7FY.jpg",
            "id_str" : "1887367551681708032",
            "source_user_id" : "1310275768191193088",
            "id" : "1887367551681708032",
            "media_url_https" : "https://pbs.twimg.com/media/GjFGyd6WQAAc7FY.jpg",
            "source_user_id_str" : "1310275768191193088",
            "sizes" : {
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "736",
                "h" : "981",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "736",
                "h" : "981",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1887367553984483571",
            "display_url" : "pic.x.com/gBg5a14yp1"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "0",
      "id_str" : "1887811183727489237",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1887811183727489237",
      "possibly_sensitive" : false,
      "created_at" : "Fri Feb 07 10:30:34 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @ShouldHaveCat: https://t.co/gBg5a14yp1",
      "lang" : "zxx",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/ShouldHaveCat/status/1887367553984483571/photo/1",
            "source_status_id" : "1887367553984483571",
            "indices" : [
              "19",
              "42"
            ],
            "url" : "https://t.co/gBg5a14yp1",
            "media_url" : "http://pbs.twimg.com/media/GjFGyd6WQAAc7FY.jpg",
            "id_str" : "1887367551681708032",
            "source_user_id" : "1310275768191193088",
            "id" : "1887367551681708032",
            "media_url_https" : "https://pbs.twimg.com/media/GjFGyd6WQAAc7FY.jpg",
            "source_user_id_str" : "1310275768191193088",
            "sizes" : {
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "736",
                "h" : "981",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "736",
                "h" : "981",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1887367553984483571",
            "display_url" : "pic.x.com/gBg5a14yp1"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1885056970735899035"
          ],
          "editableUntil" : "2025-01-30T21:06:19.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "out of context raccoons",
            "screen_name" : "contextraccoons",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1650863136424230912",
            "id" : "1650863136424230912"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1884451425213628536",
      "id_str" : "1885056970735899035",
      "in_reply_to_user_id" : "1650863136424230912",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1885056970735899035",
      "in_reply_to_status_id" : "1884451425213628536",
      "created_at" : "Thu Jan 30 20:06:19 +0000 2025",
      "favorited" : false,
      "full_text" : "@contextraccoons so cute",
      "lang" : "en",
      "in_reply_to_screen_name" : "contextraccoons",
      "in_reply_to_user_id_str" : "1650863136424230912"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1864227208530669712"
          ],
          "editableUntil" : "2024-12-04T09:36:16.837Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Nature is Amazing ☘️",
            "screen_name" : "AMAZlNGNATURE",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "2828212668",
            "id" : "2828212668"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/AMAZlNGNATURE/status/1864070971088375986/photo/1",
            "source_status_id" : "1864070971088375986",
            "indices" : [
              "57",
              "80"
            ],
            "url" : "https://t.co/qho3M4KZu2",
            "media_url" : "http://pbs.twimg.com/media/Gd6Cq01WQAAlsYT.jpg",
            "id_str" : "1864070968026480640",
            "source_user_id" : "2828212668",
            "id" : "1864070968026480640",
            "media_url_https" : "https://pbs.twimg.com/media/Gd6Cq01WQAAlsYT.jpg",
            "source_user_id_str" : "2828212668",
            "sizes" : {
              "small" : {
                "w" : "545",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "962",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1179",
                "h" : "1470",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1864070971088375986",
            "display_url" : "pic.x.com/qho3M4KZu2"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "80"
      ],
      "favorite_count" : "0",
      "id_str" : "1864227208530669712",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1864227208530669712",
      "possibly_sensitive" : false,
      "created_at" : "Wed Dec 04 08:36:16 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @AMAZlNGNATURE: her name is ava and she is adorable 🥹 https://t.co/qho3M4KZu2",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/AMAZlNGNATURE/status/1864070971088375986/photo/1",
            "source_status_id" : "1864070971088375986",
            "indices" : [
              "57",
              "80"
            ],
            "url" : "https://t.co/qho3M4KZu2",
            "media_url" : "http://pbs.twimg.com/media/Gd6Cq01WQAAlsYT.jpg",
            "id_str" : "1864070968026480640",
            "source_user_id" : "2828212668",
            "id" : "1864070968026480640",
            "media_url_https" : "https://pbs.twimg.com/media/Gd6Cq01WQAAlsYT.jpg",
            "source_user_id_str" : "2828212668",
            "sizes" : {
              "small" : {
                "w" : "545",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "962",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1179",
                "h" : "1470",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1864070971088375986",
            "display_url" : "pic.x.com/qho3M4KZu2"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1860611463569686724"
          ],
          "editableUntil" : "2024-11-24T10:08:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dolce",
            "screen_name" : "daily_dolce",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1335567526684729347",
            "id" : "1335567526684729347"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1860012287412830534",
      "id_str" : "1860611463569686724",
      "in_reply_to_user_id" : "1335567526684729347",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1860611463569686724",
      "in_reply_to_status_id" : "1860012287412830534",
      "created_at" : "Sun Nov 24 09:08:36 +0000 2024",
      "favorited" : false,
      "full_text" : "@daily_dolce I wish I could bake just to make these",
      "lang" : "en",
      "in_reply_to_screen_name" : "daily_dolce",
      "in_reply_to_user_id_str" : "1335567526684729347"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1860610742912774647"
          ],
          "editableUntil" : "2024-11-24T10:05:44.243Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Why you should love animals",
            "screen_name" : "animals_twts",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1829620436025360385",
            "id" : "1829620436025360385"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/animals_twts/status/1860321678963736971/photo/1",
            "source_status_id" : "1860321678963736971",
            "indices" : [
              "53",
              "76"
            ],
            "url" : "https://t.co/Wlj8ofr9TY",
            "media_url" : "http://pbs.twimg.com/media/GdEwlbTXAAA8y6S.jpg",
            "id_str" : "1860321540622974976",
            "source_user_id" : "1829620436025360385",
            "id" : "1860321540622974976",
            "media_url_https" : "https://pbs.twimg.com/media/GdEwlbTXAAA8y6S.jpg",
            "source_user_id_str" : "1829620436025360385",
            "sizes" : {
              "large" : {
                "w" : "700",
                "h" : "814",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "585",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "700",
                "h" : "814",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1860321678963736971",
            "display_url" : "pic.x.com/Wlj8ofr9TY"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "76"
      ],
      "favorite_count" : "0",
      "id_str" : "1860610742912774647",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1860610742912774647",
      "possibly_sensitive" : false,
      "created_at" : "Sun Nov 24 09:05:44 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @animals_twts: \"Excuse me, have you seen my son?\" https://t.co/Wlj8ofr9TY",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/animals_twts/status/1860321678963736971/photo/1",
            "source_status_id" : "1860321678963736971",
            "indices" : [
              "53",
              "76"
            ],
            "url" : "https://t.co/Wlj8ofr9TY",
            "media_url" : "http://pbs.twimg.com/media/GdEwlbTXAAA8y6S.jpg",
            "id_str" : "1860321540622974976",
            "source_user_id" : "1829620436025360385",
            "id" : "1860321540622974976",
            "media_url_https" : "https://pbs.twimg.com/media/GdEwlbTXAAA8y6S.jpg",
            "source_user_id_str" : "1829620436025360385",
            "sizes" : {
              "large" : {
                "w" : "700",
                "h" : "814",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "585",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "700",
                "h" : "814",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1860321678963736971",
            "display_url" : "pic.x.com/Wlj8ofr9TY"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1860091431882490193"
          ],
          "editableUntil" : "2024-11-22T23:42:10.845Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "out of context dogs",
            "screen_name" : "contextdogs",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "1408480800438374406",
            "id" : "1408480800438374406"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/contextdogs/status/1859386336588742762/photo/1",
            "source_status_id" : "1859386336588742762",
            "indices" : [
              "17",
              "40"
            ],
            "url" : "https://t.co/MQCTmVzI42",
            "media_url" : "http://pbs.twimg.com/media/Gc3eBQgWsAAQTzv.jpg",
            "id_str" : "1859386334365790208",
            "source_user_id" : "1408480800438374406",
            "id" : "1859386334365790208",
            "media_url_https" : "https://pbs.twimg.com/media/Gc3eBQgWsAAQTzv.jpg",
            "source_user_id_str" : "1408480800438374406",
            "sizes" : {
              "large" : {
                "w" : "474",
                "h" : "587",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "474",
                "h" : "587",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "474",
                "h" : "587",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1859386336588742762",
            "display_url" : "pic.x.com/MQCTmVzI42"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "id_str" : "1860091431882490193",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1860091431882490193",
      "possibly_sensitive" : false,
      "created_at" : "Fri Nov 22 22:42:10 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @contextdogs: https://t.co/MQCTmVzI42",
      "lang" : "zxx",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/contextdogs/status/1859386336588742762/photo/1",
            "source_status_id" : "1859386336588742762",
            "indices" : [
              "17",
              "40"
            ],
            "url" : "https://t.co/MQCTmVzI42",
            "media_url" : "http://pbs.twimg.com/media/Gc3eBQgWsAAQTzv.jpg",
            "id_str" : "1859386334365790208",
            "source_user_id" : "1408480800438374406",
            "id" : "1859386334365790208",
            "media_url_https" : "https://pbs.twimg.com/media/Gc3eBQgWsAAQTzv.jpg",
            "source_user_id_str" : "1408480800438374406",
            "sizes" : {
              "large" : {
                "w" : "474",
                "h" : "587",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "474",
                "h" : "587",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "474",
                "h" : "587",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1859386336588742762",
            "display_url" : "pic.x.com/MQCTmVzI42"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1860090739629400229"
          ],
          "editableUntil" : "2024-11-22T23:39:25.799Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "out of context dogs",
            "screen_name" : "contextdogs",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "1408480800438374406",
            "id" : "1408480800438374406"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/contextdogs/status/1859492011520242044/photo/1",
            "source_status_id" : "1859492011520242044",
            "indices" : [
              "17",
              "40"
            ],
            "url" : "https://t.co/0AW01uFLS8",
            "media_url" : "http://pbs.twimg.com/media/Gc4-IV0WoAAKBCD.jpg",
            "id_str" : "1859492009167200256",
            "source_user_id" : "1408480800438374406",
            "id" : "1859492009167200256",
            "media_url_https" : "https://pbs.twimg.com/media/Gc4-IV0WoAAKBCD.jpg",
            "source_user_id_str" : "1408480800438374406",
            "sizes" : {
              "small" : {
                "w" : "474",
                "h" : "632",
                "resize" : "fit"
              },
              "large" : {
                "w" : "474",
                "h" : "632",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "474",
                "h" : "632",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1859492011520242044",
            "display_url" : "pic.x.com/0AW01uFLS8"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "id_str" : "1860090739629400229",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1860090739629400229",
      "possibly_sensitive" : false,
      "created_at" : "Fri Nov 22 22:39:25 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @contextdogs: https://t.co/0AW01uFLS8",
      "lang" : "zxx",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/contextdogs/status/1859492011520242044/photo/1",
            "source_status_id" : "1859492011520242044",
            "indices" : [
              "17",
              "40"
            ],
            "url" : "https://t.co/0AW01uFLS8",
            "media_url" : "http://pbs.twimg.com/media/Gc4-IV0WoAAKBCD.jpg",
            "id_str" : "1859492009167200256",
            "source_user_id" : "1408480800438374406",
            "id" : "1859492009167200256",
            "media_url_https" : "https://pbs.twimg.com/media/Gc4-IV0WoAAKBCD.jpg",
            "source_user_id_str" : "1408480800438374406",
            "sizes" : {
              "small" : {
                "w" : "474",
                "h" : "632",
                "resize" : "fit"
              },
              "large" : {
                "w" : "474",
                "h" : "632",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "474",
                "h" : "632",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1859492011520242044",
            "display_url" : "pic.x.com/0AW01uFLS8"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1858865773487247535"
          ],
          "editableUntil" : "2024-11-19T14:31:51.112Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1858865773487247535",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1858865773487247535",
      "created_at" : "Tue Nov 19 13:31:51 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @elonmusk: If you look closely, you can see a human walking around the base of the rocket. \n\nEach Raptor rocket engine produces twice as…",
      "lang" : "en"
    }
  }
]