window.YTD.follower.part0 = [
  {
    "follower" : {
      "accountId" : "1758407110029697024",
      "userLink" : "https://twitter.com/intent/user?user_id=1758407110029697024"
    }
  }
]