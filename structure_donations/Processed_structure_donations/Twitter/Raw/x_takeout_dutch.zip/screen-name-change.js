window.YTD.screen_name_change.part0 = [
  {
    "screenNameChange" : {
      "accountId" : "1854507704154497024",
      "screenNameChange" : {
        "changedAt" : "2024-11-19T13:27:30.000Z",
        "changedFrom" : "geo_cooper53221",
        "changedTo" : "daggeo91"
      }
    }
  }
]