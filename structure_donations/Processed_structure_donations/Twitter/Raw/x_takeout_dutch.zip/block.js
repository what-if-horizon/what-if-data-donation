window.YTD.block.part0 = [
  {
    "blocking" : {
      "accountId" : "628253959",
      "userLink" : "https://twitter.com/intent/user?user_id=628253959"
    }
  },
  {
    "blocking" : {
      "accountId" : "1367531",
      "userLink" : "https://twitter.com/intent/user?user_id=1367531"
    }
  }
]