window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1856360821170835967",
      "fullText" : "https://t.co/2YaXwPEA3W",
      "expandedUrl" : "https://twitter.com/i/web/status/1856360821170835967"
    }
  },
  {
    "like" : {
      "tweetId" : "1855988966727500255",
      "fullText" : "On Veterans Day, we owe our veterans and their families our thanks, our respect, and our freedom. To all those who bravely served, thank you for your service to our country. https://t.co/IlWKtEYqTi",
      "expandedUrl" : "https://twitter.com/i/web/status/1855988966727500255"
    }
  },
  {
    "like" : {
      "tweetId" : "1854201929519247803",
      "fullText" : "It is morning in America again https://t.co/GNTE0cUWoc",
      "expandedUrl" : "https://twitter.com/i/web/status/1854201929519247803"
    }
  },
  {
    "like" : {
      "tweetId" : "1854419015503925638",
      "fullText" : "My hunting dog is on high alert https://t.co/XPGkmoWMRF",
      "expandedUrl" : "https://twitter.com/i/web/status/1854419015503925638"
    }
  },
  {
    "like" : {
      "tweetId" : "1854065606137376835",
      "fullText" : "Memecoin Super cycle 💰🚀 \n\n$DOGE https://t.co/Rs0WcJVZVN",
      "expandedUrl" : "https://twitter.com/i/web/status/1854065606137376835"
    }
  },
  {
    "like" : {
      "tweetId" : "1854431364906369071",
      "fullText" : "@PopBase remove “are you a convicted felon” from All job applications moving forward.",
      "expandedUrl" : "https://twitter.com/i/web/status/1854431364906369071"
    }
  },
  {
    "like" : {
      "tweetId" : "1854298119241904632",
      "fullText" : "Every person tomorrow who pre ordered their ps5 pro \n\n#PS5Pro https://t.co/l5U3bAO9kL",
      "expandedUrl" : "https://twitter.com/i/web/status/1854298119241904632"
    }
  },
  {
    "like" : {
      "tweetId" : "1854499228447633458",
      "fullText" : "LIVE: US presidential election 2024 results https://t.co/4s3oRQxUv6",
      "expandedUrl" : "https://twitter.com/i/web/status/1854499228447633458"
    }
  }
]