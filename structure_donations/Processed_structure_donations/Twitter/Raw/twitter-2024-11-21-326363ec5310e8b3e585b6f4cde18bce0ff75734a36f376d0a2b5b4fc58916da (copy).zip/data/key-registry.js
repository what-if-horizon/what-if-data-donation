window.YTD.key_registry.part0 = [
  {
    "keyRegistryData" : {
      "userId" : "1854507704154497024",
      "registeredDevices" : {
        "deviceMetadataList" : [
          {
            "userAgent" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
            "registrationToken" : "bf83853c64e8b2ad7d25c65ea6cbe2c2",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEEDFxC7VdyNudMNiQpVU+/uk3hdkjoDWO50gTJtKnL1pw2+dOc5fT9O2jZ8ZiZtzLmbd5rtEXzgEo2aRWj6+T5w==",
            "createdAt" : "2024-11-07T13:11:07.952Z",
            "deviceId" : "8cb20314-521e-44e8-aeae-923017b82dfe"
          }
        ]
      },
      "deregisteredDevices" : {
        "deRegisteredDeviceMetadataList" : [ ]
      }
    }
  }
]