window.YTD.verified.part0 = [
  {
    "verified" : {
      "accountId" : "1312048977538437120",
      "verified" : false
    }
  }
]