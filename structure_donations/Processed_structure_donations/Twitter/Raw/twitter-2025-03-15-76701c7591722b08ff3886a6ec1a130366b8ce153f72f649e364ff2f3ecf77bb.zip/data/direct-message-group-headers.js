window.YTD.direct_message_group_headers.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "1632657560749633536",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "1639621292482592772",
            "senderId" : "1917680526",
            "createdAt" : "2023-03-25T13:32:33.511Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1638590403636019210",
            "senderId" : "1917680526",
            "createdAt" : "2023-03-22T17:16:10.446Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1638590291664936966",
            "senderId" : "1917680526",
            "createdAt" : "2023-03-22T17:15:43.753Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1638479860237496324",
            "senderId" : "1312048977538437120",
            "createdAt" : "2023-03-22T09:56:54.847Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1638473050818576389",
            "senderId" : "171421468",
            "createdAt" : "2023-03-22T09:29:51.367Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1632677646353014794",
            "senderId" : "1312048977538437120",
            "createdAt" : "2023-03-06T09:40:59.253Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1632657560749633540",
            "senderId" : "171421468",
            "createdAt" : "2023-03-06T08:21:10.512Z"
          }
        },
        {
          "joinConversation" : {
            "initiatingUserId" : "171421468",
            "participantsSnapshot" : [
              "1312048977538437120",
              "1917680526",
              "171421468"
            ],
            "createdAt" : "2023-03-06T08:21:10.509Z"
          }
        }
      ]
    }
  }
]