window.YTD.community_note_rating.part0 = [
  {
    "communityNoteRating" : {
      "noteId" : "1698441220651905268",
      "helpfulnessLevel" : "Helpful",
      "createdAt" : "2023-09-04T21:55:48.974Z",
      "userId" : "1312048977538437120",
      "helpfulTags" : [
        "ImportantContext",
        "UnbiasedLanguage",
        "Clear",
        "AddressesClaim"
      ]
    }
  },
  {
    "communityNoteRating" : {
      "noteId" : "1727069146087620663",
      "helpfulnessLevel" : "Helpful",
      "createdAt" : "2023-11-22T06:07:30.661Z",
      "userId" : "1312048977538437120",
      "helpfulTags" : [
        "ImportantContext",
        "AddressesClaim",
        "GoodSources",
        "UnbiasedLanguage",
        "Clear"
      ]
    }
  }
]