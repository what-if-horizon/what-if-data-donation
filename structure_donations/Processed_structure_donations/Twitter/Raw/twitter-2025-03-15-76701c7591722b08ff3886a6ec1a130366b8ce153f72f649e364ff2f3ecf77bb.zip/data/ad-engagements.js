window.YTD.ad_engagements.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1847999738504753235",
                  "tweetText" : "¡La NFL EN DIRECTO en Netflix esta Navidad! 🏈🎄\nMiércoles 25 de diciembre. \nChiefs vs. Steelers a las 19:00 (hora peninsular)\nRavens vs. Texans a las 22:30 (hora peninsular) https://t.co/aDgT76WDQ1",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/aDgT76WDQ1"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Netflix España",
                  "screenName" : "@NetflixES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 34"
                  }
                ],
                "impressionTime" : "2024-12-15 20:54:45"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-15 20:55:06",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-15 20:54:49",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-15 20:54:51",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-12-15 20:54:48",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "Spotlight",
                "promotedTrendInfo" : {
                  "trendId" : "105080",
                  "name" : "#GTAOnline",
                  "description" : "Agents of Sabotage - Juega ya"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Rockstar Games",
                  "screenName" : "@RockstarGames"
                },
                "impressionTime" : "2024-12-15 20:54:48"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-15 20:54:51",
                  "engagementType" : "SpotlightView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1866493245141725328",
                  "tweetText" : "🎁🤔 A l'hora de fer les compres de #Nadal t'animem a abaixar revolucions i fer un consum més reflexiu: planifica, compara qualitat i preus i pensa en les conseqüències de les teves decisions de compra.\n\n🎄Perquè per Nadal, tot es cuina a foc lent\n\n📲 https://t.co/IF1znhqVYr https://t.co/qGBzyPpfCD",
                  "urls" : [
                    "https://t.co/IF1znhqVYr"
                  ],
                  "mediaUrls" : [
                    "https://t.co/qGBzyPpfCD"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Consum",
                  "screenName" : "@consumcat"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Catalonia"
                  }
                ],
                "impressionTime" : "2024-12-17 20:23:02"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-17 20:23:37",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-12-17 20:23:50",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-17 20:23:35",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-17 20:23:41",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-12-17 20:23:10",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1868929877350748160",
                  "tweetText" : "Step into your leading role to see if you can spot some festive friends along the way 🎬",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Qatar Airways",
                  "screenName" : "@qatarairways"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Artificial intelligence"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "trips"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Brand 2024 - create video (to be excluded)"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Brand 2024 – page views (to be included) "
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-12-17 20:12:02"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-17 20:12:07",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-17 20:12:05",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-17 20:12:05",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1864686415562637324",
                  "tweetText" : "Aquest Nadal regala o regala’t Zoo!\n\nFes-te membre del #ZooClub amb un descompte especial i emporta’t un portaentrepans sostenible de regal!\n\nEntrades il·limitades, descomptes, activitats exclusives i molt més! Dona’t d’alta ara: https://t.co/rbMJfypIRg\n\n#ViuElZoo",
                  "urls" : [
                    "https://t.co/rbMJfypIRg"
                  ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "zoobarcelona",
                  "screenName" : "@ZooBarcelona"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Barcelona"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Barcelona"
                  }
                ],
                "impressionTime" : "2024-12-17 20:13:26"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-17 20:13:28",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1868982297535385631",
                  "tweetText" : "La NFL en DIRECTO en Netflix ¡por primera vez! Chiefs vs. Steelers a las 19:00 (hora peninsular) y Ravens vs. Texans a las 22:30 (hora peninsular).",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Netflix España",
                  "screenName" : "@NetflixES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 34"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-12-17 20:11:42"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-17 20:13:39",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-17 20:13:40",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-17 20:13:38",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1862526661310521483",
                  "tweetText" : "📍 ¿Ya sabes que Barcelona tiene su dominio en internet? Consigue el tuyo y muestra con orgullo los valores de la ciudad en tu web. 💫 ¡Porque si pasa en Barcelona tiene el dominio de Barcelona!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "puntBarcelona",
                  "screenName" : "@puntBarcelona"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Barcelona"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Barcelona"
                  }
                ],
                "impressionTime" : "2024-12-17 20:24:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-17 20:24:21",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1863992054335819865",
                  "tweetText" : "Quan esculls 🐟 peix local, t'estàs cuidant a tu i molta més gent.\n\nPerquè darrera del nostre peix hi ha molt més que 🎣 pesca.\n\nHi ha cultura, gastronomia, comunitat i l'esforç de milers de persones... I tota la pesca‼️ https://t.co/ILeTN8fPDn",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/ILeTN8fPDn"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Agricultura",
                  "screenName" : "@agriculturacat"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Catalonia"
                  }
                ],
                "impressionTime" : "2024-12-17 20:23:56"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-17 20:24:11",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2024-12-17 20:24:14",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-17 20:24:11",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2024-12-17 20:24:04",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-12-17 20:24:13",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-12-17 20:24:10",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-12-17 20:24:09",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-12-17 20:24:07",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1811036149944832443",
                  "tweetText" : "Make a global impact with your immunology research and become part of the dialogue within your discipline.\n📖 Increase the discoverability of your research\n🗺 Reach a global audience to make a difference with your insights.\nExplore our open access journals today.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Taylor & Francis Research Insights",
                  "screenName" : "@tandfonline"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "PHD"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-17 20:25:05"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-17 20:25:11",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-17 20:25:12",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1868721760910377368",
                  "tweetText" : "¡PREPÁRATE! Netflix te trae la WWE en enero de 2025",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Netflix España",
                  "screenName" : "@NetflixES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Boxing"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Martial arts"
                  },
                  {
                    "targetingType" : "Movies and TV shows",
                    "targetingValue" : "WWE Friday Night SmackDown"
                  },
                  {
                    "targetingType" : "Movies and TV shows",
                    "targetingValue" : "WWE Monday Night RAW"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-17 20:13:25"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-17 20:36:10",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-17 20:25:15",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-17 20:21:27",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-12-17 20:21:27",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1865397207668789412",
                  "tweetText" : "Long battery life supports overnight use with quick USB-C charging.\nGet it: https://t.co/oS3tP4aLva https://t.co/tRWFyatkNe",
                  "urls" : [
                    "https://t.co/oS3tP4aLva"
                  ],
                  "mediaUrls" : [
                    "https://t.co/tRWFyatkNe"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Zeneaseco",
                  "screenName" : "@Zeneaseco"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "sound"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "fun"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "kids"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "love"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "news"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "2023"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "coming"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "styles"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "deal"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "women"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "set"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "snow"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "games"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "day"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "game"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "peace"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "hand"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "family"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "save"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "sale"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "design"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "master"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "star"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  }
                ],
                "impressionTime" : "2024-12-17 20:23:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-17 20:23:27",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-12-17 20:23:25",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-12-17 20:23:23",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-17 20:23:29",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-12-17 20:23:30",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2024-12-17 20:23:33",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-12-17 20:23:34",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2024-12-17 20:23:34",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1868597694157160658",
                  "tweetText" : "Inspira con tu ejemplo. \n\n#LALIGAVSODIO #LaFuerzaDeNuestroFútbol https://t.co/6dTAKCoHeC",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/6dTAKCoHeC"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "LALIGA",
                  "screenName" : "@LaLiga"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "futbol"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "messi"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "sports"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "real madrid"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-12-17 20:24:54"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-17 20:24:57",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-12-17 20:24:58",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-17 20:25:03",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-17 20:25:02",
                  "engagementType" : "VideoContentMrcView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1872674211258642833",
                  "tweetText" : "¡PREPÁRATE! Netflix te trae la WWE en enero de 2025",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Netflix España",
                  "screenName" : "@NetflixES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Movies and TV shows",
                    "targetingValue" : "WWE Friday Night SmackDown"
                  },
                  {
                    "targetingType" : "Movies and TV shows",
                    "targetingValue" : "WWE Monday Night RAW"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Boxing"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Martial arts"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-12-29 09:43:48"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-30 04:03:48",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-30 04:03:47",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-12-30 04:03:49",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "advertiserInfo" : {
                  "advertiserName" : "Forynia",
                  "screenName" : "@Foryniastore"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "love"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "news"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "2023"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "kids"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "para"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "fun"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "coming"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "baby"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "match"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "star"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "son"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "game"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "look"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "family"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "day"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "hand"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "support"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "save"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "deal"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "set"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "red"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "women"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "games"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-29 09:42:51"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-29 09:43:01",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-29 09:42:59",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "Spotlight",
                "promotedTrendInfo" : {
                  "trendId" : "105406",
                  "name" : "#AdiosMovistar",
                  "description" : "Movistar te quita 14 canales de TV. Que nada nos separe"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Canal Cocina",
                  "screenName" : "@CanalCocina"
                },
                "impressionTime" : "2024-12-29 09:39:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-29 09:39:20",
                  "engagementType" : "SpotlightView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1869312695704666394",
                  "tweetText" : "👑 Descuentos de REYES para los mejores regalos 🎁 Disfruta de nuestras mágicas ofertas a precios increíbles y ahorra a lo grande✨",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Carrefour España",
                  "screenName" : "@CarrefourES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "niños"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "niño"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2024-12-29 09:42:23"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-29 09:42:26",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1869397522260939207",
                  "tweetText" : "Todo es posible en Navidad…Bueno, todo menos que David Bisbal te indique dónde tienes que coger tu próximo vuelo, eso quizá no 😉🎄 \n#Aena #UnaNavidadEnElAeropuerto",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Aena",
                  "screenName" : "@aena"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-12-30 09:45:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-30 09:46:47",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1873651073229205663",
                  "tweetText" : "JUST 48 HOURS LEFT!\n\nClaim Your ENTRY to WIN $ 1 MILLION+ in our Prize Builder!\n\nEvery entry adds to the final prize - how high will it go?\n\nEnter Now for a CHANCE TO WIN: \n➡️ https://t.co/D14GA1XhKI",
                  "urls" : [
                    "https://t.co/D14GA1XhKI"
                  ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "METAWIN",
                  "screenName" : "@Meta_Winners"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Cryptocurrencies"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 to 49"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-12-30 09:47:05"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-30 09:47:10",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1860006107042971851",
                  "tweetText" : "RT @fever_es: Las puertas del antiguo Egipto ya están abiertas en Valencia. ✨",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Fever US",
                  "screenName" : "@fever_us"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 to 49"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Community of Valencia"
                  }
                ],
                "impressionTime" : "2024-12-30 04:04:06"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-30 04:04:38",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1862360841514823979",
                  "tweetText" : "Raquel sale del punto A, pero no encuentra lo que está buscando. Marta, desde el punto B, tiene las herramientas para ayudarla a encontrarlo. Conoce su histo-ria para saber dónde se encuentran. Porque nosotros no creemos en las coinci-dencias, creemos en las oportunidades.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Fundación ”la Caixa”",
                  "screenName" : "@FundlaCaixa"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-30 04:06:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-30 04:08:47",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-30 04:08:27",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-12-30 04:08:36",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1872486470054711797",
                  "tweetText" : "Whether you're gifting it or enjoying it yourself, these mugs add a touch of luxury to every drink.\nGet it: https://t.co/h9pSDfCwqx https://t.co/nAWeKhAPmX",
                  "urls" : [
                    "https://t.co/h9pSDfCwqx"
                  ],
                  "mediaUrls" : [
                    "https://t.co/nAWeKhAPmX"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Rynolia",
                  "screenName" : "@Rynoliashop"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "drinking"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "love"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "free"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "2023"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "drink"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "fun"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "kids"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "harmful"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "deal"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "women"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "day"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "games"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "family"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "bad"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "set"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "new"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "look"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "designed"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "support"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "win"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "cool"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "star"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "damaged"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "son"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  }
                ],
                "impressionTime" : "2024-12-30 04:04:06"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-30 04:04:27",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-12-30 04:04:25",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-30 04:04:26",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-12-30 04:04:31",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1863959626972086337",
                  "tweetText" : "Encuentra tu nuevo coche en el concesionario más grande de Europa.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Real Madrid Basket",
                  "screenName" : "@RMBaloncesto"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "MINI"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-30 04:10:44"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-30 04:11:52",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1872575652945162342",
                  "tweetText" : "¿A qué suena una neurona? ¿Cómo transmitir con notas musicales la emoción detrás de una caricia, un beso o un abrazo? \n\nEl maestro Lucas Vidal nos explica cómo compuso la banda sonora de ‘Neurona’, el tercer y último spot de nuestro Centenario. #Imaginémonos #Telefónica100 https://t.co/TXYYdjytIy",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/TXYYdjytIy"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Telefónica",
                  "screenName" : "@Telefonica"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-30 04:06:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-30 04:07:04",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-12-30 04:06:39",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-30 04:06:54",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2024-12-30 04:07:29",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "advertiserInfo" : {
                  "advertiserName" : "Mohammed Al-Issa محمد العيسى",
                  "screenName" : "@MhmdAlissa"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  }
                ],
                "impressionTime" : "2024-12-30 04:06:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-30 04:09:35",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1872940805763018811",
                  "tweetText" : "♟️ Escàndol al Mundial d'Escacs: expulsen Magnus Carlsen, número 1 del món, per vestir texans",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "ElNacional.cat",
                  "screenName" : "@elnacionalcat"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@diariARA"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@MonDiari"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "Spanish"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "Catalan"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Community of Valencia"
                  }
                ],
                "impressionTime" : "2024-12-30 04:06:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-30 04:08:59",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1864316972130861495",
                  "tweetText" : "Win tickets to an upcoming #UCL match now! \n\n👉 Comment with who you think will win, and #UCLwithCryptoCom:\n👉 Follow @cryptocom\n👉 Like and RT\n\nFull details 👉: https://t.co/IOsrDBbeqa https://t.co/Hj3mMuxACF",
                  "urls" : [
                    "https://t.co/IOsrDBbeqa"
                  ],
                  "mediaUrls" : [
                    "https://t.co/Hj3mMuxACF"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Crypto.com",
                  "screenName" : "@cryptocom"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "#uefa"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-30 04:06:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-30 04:09:19",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-30 04:09:18",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1869676228632093175",
                  "tweetText" : "COLD VR the NEW time-manipulating action VR game with live-action storytelling and Backrooms Horror elements is coming to Steam VR January 21st! ❄️😱\n\nTime moves when you don't, so you better keep moving! 🏃‍♂️💨\n\n#Wishlist now on @Steam! 💥\n\n#VR #Gaming",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Perp Games | UNDERDOGS | March 25th on PSVR2 🥊",
                  "screenName" : "@PerpGames"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "gaming"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Computer gaming"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-30 04:10:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-30 04:11:36",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-30 04:11:25",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "advertiserInfo" : {
                  "advertiserName" : "MadMuscles",
                  "screenName" : "@MadmusclesPlans"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Purchase GTM"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "Spanish"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-30 04:03:50"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-30 04:03:52",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1846813043205763390",
                  "tweetText" : "¡Conoce a los Popular Investors de eToro! 🚀 Inversores experimentados que puedes copiar con un solo clic. \n\nÚnete a eToro y aprovecha sus estrategias y conocimientos para convertirte en el inversor que deseas ser🔥👇🏻",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "eToro en Español",
                  "screenName" : "@eToroES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Beginning investing"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Financial news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Investing"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Options"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Business and finance"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@elconfidencial"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-30 04:06:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-30 04:07:49",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-30 04:07:51",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-12-30 04:08:02",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-30 04:07:52",
                  "engagementType" : "VideoContentMrcView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1869049476679106882",
                  "tweetText" : "Todo es posible en Navidad…Bueno, todo menos que David Bisbal te indique dónde tienes que coger tu próximo vuelo, eso quizá no 😉🎄 \n#Aena #UnaNavidadEnElAeropuerto",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Aena",
                  "screenName" : "@aena"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-12-30 04:08:48"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-30 04:10:53",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1871219975664415015",
                  "tweetText" : "🚨 ALERTA 2025: Todo Cambiará en los Mercados\n\nLos próximos meses definirán el futuro del trading.\n\n¿Estás preparado?\n\nDESBLOQUEA TU 2025 🚀\n→ Guía Esencial de Trading\n→ Análisis Exclusivo\n→ Oportunidades Únicas\n\n⚡️ DESCARGA GRATUITA\n👉 https://t.co/euK5gIyTCk",
                  "urls" : [
                    "https://t.co/euK5gIyTCk"
                  ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "IG España",
                  "screenName" : "@IGEspana"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "Spanish"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-30 04:04:06"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-30 04:04:57",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1873299714793156852",
                  "tweetText" : "Decode with confidence and expertise every time.\n\nGet: https://t.co/N3fmCrSyj0 https://t.co/CSluAcHaVr",
                  "urls" : [
                    "https://t.co/N3fmCrSyj0"
                  ],
                  "mediaUrls" : [
                    "https://t.co/CSluAcHaVr"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "John Williams",
                  "screenName" : "@JohnWillia25188"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "design"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "general"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "games"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "family"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "set"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "new"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "technology"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "fun"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "hello"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "issues"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "home"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "deal"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "women"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "star"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "hand"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "save"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "love"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "peace"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "day"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "2023"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "bad"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "kids"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-31 12:11:36"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-31 12:11:45",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-31 12:11:40",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1865195718425874730",
                  "tweetText" : "Sin contratos de larga duración.\n\nFácil de pedir por internet.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Starlink",
                  "screenName" : "@Starlink"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "List",
                    "targetingValue" : "Starlink Global Customer list"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "All Starlink Customers"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Purchasers"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "Spanish"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-31 12:11:45"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-31 12:11:49",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "ProfileTweets",
                "promotedTweetInfo" : {
                  "tweetId" : "1873735649318338657",
                  "tweetText" : "🔄 ¡Cambiar de red nunca ha sido tan fácil! Con eSIM io, disfruta de una conectividad perfecta allá donde vayas, sin necesidad de tarjetas SIM físicas. ¡Bienvenido al futuro de la tecnología móvil! 📲 ✨ #eSIMio #eSIM #StayConnected",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "eSIM io",
                  "screenName" : "@theesimio"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  }
                ],
                "impressionTime" : "2025-01-01 10:10:44"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-01 10:11:37",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-01 10:11:16",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-01 10:11:15",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-01-01 10:11:18",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1873564664488919088",
                  "tweetText" : "Wuthering Waves | Exposición de Resonator | Carlotta — EL BANQUETE\nNo hace falta apurarse... El baile apenas comienza.\n\nSigue a @WW_ES_Official y retuitea esta entrada. Se elegirán 5 ganadores para un Adorno acrílico de arenas movedizas de Resonador.\n#WutheringWaves https://t.co/vFEXo5TP6m",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/vFEXo5TP6m"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wuthering Waves ES",
                  "screenName" : "@WW_ES_Official"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Computer gaming"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 34"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "Spanish"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2025-01-01 10:04:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-01 10:10:40",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2025-01-01 10:10:40",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2025-01-01 10:11:45",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-01 10:10:38",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-01 10:11:18",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-01 10:10:41",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2025-01-01 10:10:38",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-01-01 10:10:41",
                  "engagementType" : "VideoContentViewThreshold"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1862360842055913947",
                  "tweetText" : "En Rubèn surt del punt A, però sembla que està perdut. En Carles surt del punt B i ell el pot ajudar a trobar la motivació. Coneix la seva història o descobreix on es trobaran. Perquè nosaltres no creiem en les coincidències, creiem en les oportunitats.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Fundación ”la Caixa”",
                  "screenName" : "@FundlaCaixa"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Community of Valencia"
                  }
                ],
                "impressionTime" : "2025-01-01 10:10:36"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-01 10:12:05",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-01-01 10:12:06",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-01 10:12:06",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1871216851767926836",
                  "tweetText" : "¡Haz que cada día sea una aventura con nuestras ofertas! 🚂 Disfruta de un 40% de descuento en juguetes y bicicletas 🚲 Solo hasta el 07/01 ⏳",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Carrefour España",
                  "screenName" : "@CarrefourES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Babies and toddlers"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Daycare and preschool"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Parenting K-6 kids"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Cycling"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Console gaming"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Gaming news and general info"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Chess"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "niño"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "niños"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2025-01-01 10:02:27"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-01 10:03:29",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "advertiserInfo" : {
                  "advertiserName" : "Qylarix",
                  "screenName" : "@Qylarix"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "digital"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "model"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "sound"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "movies"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "2023"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "golf"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "design"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "sale"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "sales"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "fan"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "hand"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "amazon"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "left"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "technology"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "cat"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "gadgets"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "style"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-01 10:03:27"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-01 10:03:58",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2025-01-01 10:04:00",
                  "engagementType" : "VideoContentPlayback95"
                },
                {
                  "engagementTime" : "2025-01-01 10:03:45",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-01 10:03:38",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-01 10:10:38",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-01 10:04:47",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-01 10:03:59",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2025-01-01 10:03:49",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2025-01-01 10:03:53",
                  "engagementType" : "VideoContentPlayback50"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1869698944579899442",
                  "tweetText" : "En Telefónica creemos en el poder de las conexiones para garantizar progreso y oportunidades para todos. \n\nAhora que estamos mejor conectados que nunca, imaginémonos lo lejos que podremos llegar. \n\n#Imaginémonos #Telefónica100 https://t.co/MBZrZ3usa1",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/MBZrZ3usa1"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Telefónica",
                  "screenName" : "@Telefonica"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-01 10:13:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-01 13:57:47",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-01 13:57:45",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-01 13:57:46",
                  "engagementType" : "VideoContent1secView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "advertiserInfo" : {
                  "advertiserName" : "Zyxalion",
                  "screenName" : "@Zyxalion"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "love"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "best"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "women"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "access"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "set"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "new"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "family"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "home"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "baby"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "look"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "day"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "game"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "son"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "large"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "hand"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "support"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-01 10:10:43"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-01 10:11:41",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2025-01-01 10:11:38",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-01 10:11:42",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1872211077674795433",
                  "tweetText" : "Los momentos más virales y noticias impactantes: this year on X ha sido extraordinario 🔥\n\nHemos reunido los mejores acontecimientos del año en 🇪🇸. ¿Cuál fue tu favorito? 👀",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "X Business Europe",
                  "screenName" : "@XBusinessEurope"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-01 21:15:04"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-01 21:15:11",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-01 21:15:10",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-01-01 21:15:13",
                  "engagementType" : "VideoSession"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1862360845407457489",
                  "tweetText" : "Rosa sale del punto A y su trayecto es muy solitario, mientras que María sale del punto B y su camino es mucho más frenético. Si quieres saber dónde se en-cuentran, conoce su historia. Porque nosotros no creemos en las coincidencias, creemos en las oportunidades",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Fundación ”la Caixa”",
                  "screenName" : "@FundlaCaixa"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-02 09:00:42"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-02 09:02:07",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-02 09:02:11",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-02 09:02:06",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "advertiserInfo" : {
                  "advertiserName" : "Mohammed Al-Issa محمد العيسى",
                  "screenName" : "@MhmdAlissa"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-02 09:03:50"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-02 09:03:52",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1871155793929572696",
                  "tweetText" : "👑✨ ¿Quieres tener una videollamada con tu Rey Mago favorito? ¡Vive un momento mágico e inolvidable! 🐫🌟",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Iberia",
                  "screenName" : "@Iberia"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Adventure travel"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Air travel"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Traveling with kids"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Eastern Europe"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Europe"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Mexico and Central America"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "South America"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "United Kingdom"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2025-01-02 09:00:42"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-02 09:01:21",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-02 09:01:17",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1872756804163387428",
                  "tweetText" : "Vale 160k es bueno? 🤔 https://t.co/G2TXYMd0xJ",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/G2TXYMd0xJ"
                  ]
                },
                "publisherInfo" : {
                  "publisherName" : "..PikA..",
                  "screenName" : "@PikAHiMoViC"
                },
                "advertiserInfo" : {
                  "advertiserName" : "McDonald's España",
                  "screenName" : "@mcdonalds_es"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Computer gaming"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Console gaming"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Roleplaying games"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Gaming news and general info"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Action and adventure"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Drama"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Romance"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Cartoons"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Dining out"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Foodie news and general info"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 54"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-02 09:04:18"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-02 09:07:39",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-02 09:07:14",
                  "engagementType" : "VideoAdPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1869327330730217853",
                  "tweetText" : "RT @FCBarcelona: ¿Qué se compró con la primera transacción con criptomonedas? Las jugadoras se enfrentan a un examen con @WhiteBit 🍕",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "publisherInfo" : {
                  "publisherName" : "WhiteBIT",
                  "screenName" : "@WhiteBit"
                },
                "advertiserInfo" : {
                  "advertiserName" : "WhiteBIT",
                  "screenName" : "@WhiteBit"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Financial news"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 34"
                  }
                ],
                "impressionTime" : "2025-01-02 09:04:18"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-02 09:05:05",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-01-02 09:05:31",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-02 09:05:54",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1873735549942648968",
                  "tweetText" : "🔄 ¡Cambiar de red nunca ha sido tan fácil! Con eSIM io, disfruta de una conectividad perfecta allá donde vayas, sin necesidad de tarjetas SIM físicas. ¡Bienvenido al futuro de la tecnología móvil! 📲 ✨ #eSIMio #eSIM #StayConnected",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "eSIM io",
                  "screenName" : "@theesimio"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-02 09:00:42"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-02 09:03:35",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1803343859574796750",
                  "tweetText" : "♻️ La recogida de los iglús verdes la realizan camiones que transportan solo vidrio. En casos muy concretos de que lleven otros materiales tienen compartimentos en su interior.\n\nTienes nuestra palabra de que nadie deshace el trabajo que tú has hecho en casa 🤝 #VidrioTransparente https://t.co/WrStlHT4p8",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/WrStlHT4p8"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Ecovidrio 🌍",
                  "screenName" : "@ecovidrio"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2025-01-02 09:02:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-02 09:04:40",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-02 09:04:17",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-02 09:04:17",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1868612038089662571",
                  "tweetText" : "En Navidad también hay un montón de #FormasTontasDeCargarseElMundo. Por favor, evítalas siempre que puedas 🙏🌍 https://t.co/tUYljgWTP7",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/tUYljgWTP7"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Ecovidrio 🌍",
                  "screenName" : "@ecovidrio"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "13 to 54"
                  }
                ],
                "impressionTime" : "2025-01-02 09:04:15"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-03 08:09:41",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-03 08:09:37",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-01-03 08:09:38",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-03 08:09:40",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2025-01-03 08:09:45",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1868726034398679450",
                  "tweetText" : "¡PREPÁRATE! Netflix te trae la WWE en enero de 2025",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Netflix España",
                  "screenName" : "@NetflixES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Boxing"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Martial arts"
                  },
                  {
                    "targetingType" : "Movies and TV shows",
                    "targetingValue" : "WWE Friday Night SmackDown"
                  },
                  {
                    "targetingType" : "Movies and TV shows",
                    "targetingValue" : "WWE Monday Night RAW"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-02 08:58:42"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-02 08:58:51",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-02 08:58:59",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-02 08:58:56",
                  "engagementType" : "VideoContentPlaybackComplete"
                },
                {
                  "engagementTime" : "2025-01-02 08:58:53",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2025-01-02 08:58:56",
                  "engagementType" : "VideoContentPlayback95"
                },
                {
                  "engagementTime" : "2025-01-02 08:58:50",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-01-02 08:58:56",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2025-01-02 08:58:54",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2025-01-02 08:58:56",
                  "engagementType" : "VideoContentPlayback75"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1869312695704666394",
                  "tweetText" : "👑 Descuentos de REYES para los mejores regalos 🎁 Disfruta de nuestras mágicas ofertas a precios increíbles y ahorra a lo grande✨",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Carrefour España",
                  "screenName" : "@CarrefourES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "niños"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "niño"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2025-01-03 08:09:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-03 08:09:23",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1868943661104349538",
                  "tweetText" : "La industria del juego sostiene casi 200.000 puestos de trabajo entre público y privado, máquinas B en hostelería y otros empleos asociados. Miles de familias viven en España gracias al juego y hay quienes aún lo critican. 🤯",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "CEJUEGO",
                  "screenName" : "@CeJuego"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "news"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "vox"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "podemos"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "Spanish"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 54"
                  }
                ],
                "impressionTime" : "2025-01-04 11:53:00"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-04 11:53:18",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1873718325974577424",
                  "tweetText" : "Andreu Buenafuente repassa el 2024 amb humor i un monòleg complet des del Teatre Victòria.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "3Cat",
                  "screenName" : "@som3cat"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Catalonia"
                  }
                ],
                "impressionTime" : "2025-01-06 00:02:26"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-06 00:02:34",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2025-01-06 00:02:34",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2025-01-06 00:02:27",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-01-06 00:02:28",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-06 00:02:35",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-06 00:03:09",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-06 00:02:30",
                  "engagementType" : "VideoContentMrcView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1874786240039616870",
                  "tweetText" : "Viu un Un Nadal ple d'entusiasme amb 3Cat",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "3Cat",
                  "screenName" : "@som3cat"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Catalonia"
                  }
                ],
                "impressionTime" : "2025-01-06 17:03:48"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-06 17:05:13",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-06 17:05:12",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-01-06 17:05:12",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1861491614608433345",
                  "tweetText" : "¿Alguien ha dicho 🍌🍌🍌?\n\nDonkey Kong Country Returns HD llega el 16 de enero para Nintendo Switch.\n\n¡Resérvalo antes de su lanzamiento y llévate estos stickers de regalo y un -15% en tu próxima compra en Gaming! \nhttps://t.co/xRpZtfUqq8 https://t.co/0lVuJdfZOq",
                  "urls" : [
                    "https://t.co/xRpZtfUqq8"
                  ],
                  "mediaUrls" : [
                    "https://t.co/0lVuJdfZOq"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Fnac Gamers",
                  "screenName" : "@Fnac_Gamers"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Super Mario"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Nintendo Switch"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-06 17:05:18"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-06 17:05:22",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1861056938143776939",
                  "tweetText" : "Luz + gas para tu hogar con 70€ en tu factura. Rápido, claro y sin permanencia. 🐙 \n\n¿A qué esperas? 💡🔥",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Octopus Energy España",
                  "screenName" : "@OctopusEnergyES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Sports news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Science news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Financial news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Business and news"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@elconfidencial"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@el_pais"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@LaVanguardia"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@20m"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@PSOE"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-06 17:05:22"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-06 17:11:46",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1871153198259737080",
                  "tweetText" : "Retrobades amb els teus aquest Nadal! \n\nDescobreix mercats amb encant, escapades úniques i ciutats europees. Tot comença a l’Estació Barcelona Nord! \n\n#BarcelonaNord!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Estació Barcelona Nord",
                  "screenName" : "@BarcelonaNord"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Adventure travel"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Europe"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Catalonia"
                  }
                ],
                "impressionTime" : "2025-01-06 17:05:18"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-06 17:07:42",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2025-01-06 17:09:50",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-06 17:07:11",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-01-06 17:07:41",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1869698944579899442",
                  "tweetText" : "En Telefónica creemos en el poder de las conexiones para garantizar progreso y oportunidades para todos. \n\nAhora que estamos mejor conectados que nunca, imaginémonos lo lejos que podremos llegar. \n\n#Imaginémonos #Telefónica100 https://t.co/MBZrZ3usa1",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/MBZrZ3usa1"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Telefónica",
                  "screenName" : "@Telefonica"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-06 17:05:18"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-06 17:05:34",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-06 17:05:32",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-06 17:05:34",
                  "engagementType" : "VideoContent1secView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1861056938143776939",
                  "tweetText" : "Luz + gas para tu hogar con 70€ en tu factura. Rápido, claro y sin permanencia. 🐙 \n\n¿A qué esperas? 💡🔥",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Octopus Energy España",
                  "screenName" : "@OctopusEnergyES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Sports news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Science news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Financial news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Business and news"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@elconfidencial"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@el_pais"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@LaVanguardia"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@20m"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@PSOE"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2025-01-09 07:30:59"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-10 05:21:17",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1876901660108206560",
                  "tweetText" : "¡Los Pink Days ya están aquí!\n\n¿Cansado del turrón y las comidas familiares? Te mereces una escapada. Solo el 8 y 9 de enero, billetes por 9€, 15€, 19€ ó 25€. ✨ ¡Entra en https://t.co/Gg0yMmPJmQ y empieza el año viajando! 🚅 #OUIGOLetsGo",
                  "urls" : [
                    "https://t.co/Gg0yMmPJmQ"
                  ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "OUIGO España",
                  "screenName" : "@OUIGO_Es"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Barcelona"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 54"
                  }
                ],
                "impressionTime" : "2025-01-09 07:30:02"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-09 07:30:22",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1871808715902582876",
                  "tweetText" : "Provides soft and supportive sleep experience.\nShop: https://t.co/jISUN0Yx9w https://t.co/fBtaNkTR9I",
                  "urls" : [
                    "https://t.co/jISUN0Yx9w"
                  ],
                  "mediaUrls" : [
                    "https://t.co/fBtaNkTR9I"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Velonar",
                  "screenName" : "@VelonarUS"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "2023"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "job"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "fun"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "harmful"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "design"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "uv"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "cool"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "general"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "school"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "male"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "spring"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "new"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "model"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "women"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "day"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-09 07:28:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-09 07:29:40",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2025-01-09 07:29:36",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2025-01-09 07:29:29",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-09 07:29:34",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2025-01-09 07:29:43",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-09 07:29:32",
                  "engagementType" : "VideoContentMrcView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1874785148237181084",
                  "tweetText" : "Gràcies per fer del 2024 un any increïble. I ara, per un 2025 ple d’entusiasme!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "3Cat",
                  "screenName" : "@som3cat"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Catalonia"
                  }
                ],
                "impressionTime" : "2025-01-09 07:30:26"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-09 07:30:48",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-09 07:30:43",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2025-01-09 07:30:32",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-09 07:30:44",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2025-01-09 07:30:41",
                  "engagementType" : "VideoContentPlayback25"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1868927615077134828",
                  "tweetText" : "🚆✈️🏨 Marxes de viatge aquests dies de #Nadal? \n\n✅️ Doncs no perdis de vista aquests consells per tenir-ho tot sota control\n\n➕️info a https://t.co/DSa5sVp0Ah https://t.co/0Ta14Mnztz",
                  "urls" : [
                    "https://t.co/DSa5sVp0Ah"
                  ],
                  "mediaUrls" : [
                    "https://t.co/0Ta14Mnztz"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Consum",
                  "screenName" : "@consumcat"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Catalonia"
                  }
                ],
                "impressionTime" : "2024-12-18 18:38:41"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-18 18:39:14",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-18 18:39:17",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-18 18:39:08",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1861056938143776939",
                  "tweetText" : "Luz + gas para tu hogar con 70€ en tu factura. Rápido, claro y sin permanencia. 🐙 \n\n¿A qué esperas? 💡🔥",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Octopus Energy España",
                  "screenName" : "@OctopusEnergyES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@elconfidencial"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@el_pais"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@LaVanguardia"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@20m"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@PSOE"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Sports news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Science news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Financial news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Business and news"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2025-01-11 10:53:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-12 08:33:04",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1877618629166149707",
                  "tweetText" : "🎬 Si te perdiste el último capítulo de #NefroLateShowConTorre, ¡no te preocupes! \n\n🔗 Ahora puedes volver a verlo y descubrir por qué \"La Nefro mola\" aquí: \n\n@torreandfriends",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "CSL Vifor ES",
                  "screenName" : "@CSLViforES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-12 08:35:06"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-12 08:35:49",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1876973751734272189",
                  "tweetText" : "🚀 Play more than 5000+ games without limit! ⚡Instant access, no sign-up needed! 🌍 Privacy-first, VPN-friendly",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "CasinoPunkz",
                  "screenName" : "@CasinoPunkz"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "gaming"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Betfair"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "NFTs"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Cryptocurrencies"
                  },
                  {
                    "targetingType" : "New device targeting",
                    "targetingValue" : "2 months"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-12 08:33:51"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-12 08:35:00",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1871184483195523251",
                  "tweetText" : "Invierte como tú quieras con acceso a mercados de todo el mundo en una plataforma de primera. 🌎 ¡Abre una cuenta hoy mismo! Invertir conlleva riesgo de pérdida.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "DEGIRO",
                  "screenName" : "@DEGIRO"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Investing"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Investing"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Beginning investing"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Financial news"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Sign Ups "
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Trader"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Open an Account button "
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Final Step Onboarding "
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 to 49"
                  }
                ],
                "impressionTime" : "2025-01-12 08:33:04"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-12 08:36:36",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-12 08:36:35",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-01-12 08:37:08",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-12 08:36:37",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1871762791289462854",
                  "tweetText" : "Retro vibes, modern convenience—gaming nostalgia at its best.\nPick it: https://t.co/5TBg13iAWk https://t.co/cNJf2QSmWN",
                  "urls" : [
                    "https://t.co/5TBg13iAWk"
                  ],
                  "mediaUrls" : [
                    "https://t.co/cNJf2QSmWN"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "VXGME",
                  "screenName" : "@vxgmeofficial"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-12 08:36:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-12 16:24:59",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-12 16:24:58",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1877671445150474601",
                  "tweetText" : "⚽️🏆 ¡El Clásico en la final de la Supercopa de España!\n¿Quién se llevará el título?\n \nRegístrate en bet365™, apuesta y consigue:\n💶 Hasta 100 € en créditos de apuesta en \"Deportes\".\n⭐ 10 fichas doradas en juegos seleccionados.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "bet365 España",
                  "screenName" : "@bet365_es"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2025-01-12 16:24:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-12 16:24:59",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1875155901642129907",
                  "tweetText" : "Nada es más auténtico que disfrutar de lo que te gusta a tu ritmo.\n\nBallantine’s 10\n\nHecho a nuestra manera, para que la disfrutes a la tuya.\n\n#StayTrue",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Ballantine's España",
                  "screenName" : "@Ballantines_ES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Retargeting campaign engager",
                    "targetingValue" : "Retargeting campaign engager: 37677535"
                  },
                  {
                    "targetingType" : "Retargeting engagement type",
                    "targetingValue" : "Retargeting engagement type: 3"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-12 21:11:18"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-12 21:11:22",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-01-12 22:06:16",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-12 21:12:16",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2025-01-12 21:11:23",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-12 21:11:25",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2025-01-12 21:12:16",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2025-01-12 21:12:17",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-12 21:11:24",
                  "engagementType" : "VideoContent1secView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1861056938143776939",
                  "tweetText" : "Luz + gas para tu hogar con 70€ en tu factura. Rápido, claro y sin permanencia. 🐙 \n\n¿A qué esperas? 💡🔥",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Octopus Energy España",
                  "screenName" : "@OctopusEnergyES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@elconfidencial"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@el_pais"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@LaVanguardia"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@20m"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@PSOE"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Sports news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Science news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Financial news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Business and news"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2025-01-12 21:11:18"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-12 21:12:21",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1877264045864317025",
                  "tweetText" : "És increïble el que pot fer una cançó. Ramon Gener t'ho explica com ningú altre ho ha fet abans.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "3Cat",
                  "screenName" : "@som3cat"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Catalonia"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2025-01-12 21:11:18"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-12 21:12:59",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-12 21:12:58",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1877441576529703356",
                  "tweetText" : "\"Ponte de tu parte. Vas a ser quien quieras ser\"\n\nMarta Nieto ofrece en su opera prima una delicada mirada a la maternidad y la identidad de género. \n\nLA MITAD DE ANA  🦋  YA EN CINES",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "elasticafilms",
                  "screenName" : "@ElasticaFilms"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@deformesemanal_"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Barcelona"
                  }
                ],
                "impressionTime" : "2025-01-12 21:11:18"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-12 21:12:50",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-12 21:12:55",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-12 21:12:48",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1863610681658089960",
                  "tweetText" : "Nada es más auténtico que disfrutar de lo que te gusta a tu ritmo.\n\nBallantine’s 10\n\nHecho a nuestra manera, para que la disfrutes a la tuya.\n\n#StayTrue",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Ballantine's España",
                  "screenName" : "@Ballantines_ES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Drinks"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Liquor and spirits"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-12 22:06:49"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-12 22:08:12",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2025-01-12 22:08:10",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-01-12 22:08:12",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2025-01-12 22:08:10",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-12 22:08:15",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1869698944579899442",
                  "tweetText" : "En Telefónica creemos en el poder de las conexiones para garantizar progreso y oportunidades para todos. \n\nAhora que estamos mejor conectados que nunca, imaginémonos lo lejos que podremos llegar. \n\n#Imaginémonos #Telefónica100 https://t.co/MBZrZ3usa1",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/MBZrZ3usa1"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Telefónica",
                  "screenName" : "@Telefonica"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-12 22:06:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-12 22:07:41",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-12 22:07:29",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1874864934774800467",
                  "tweetText" : "Llega a los cines CIENTO VOLANDO🕊️\n\nEl documental del artista vasco Eduardo Chillida que cierra la celebración de los 100 años de su nacimiento. El film de Arantxa Aguirre se presentó en el Festival de San Sebastián y se estrenará el próximo 10 de enero solo en cines.\n\n🎟️… https://t.co/cy5pmzQiAz",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/cy5pmzQiAz"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "A Contracorriente",
                  "screenName" : "@acontrafilms"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Movie festivals"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "arte"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Barcelona"
                  }
                ],
                "impressionTime" : "2025-01-12 22:06:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-12 22:06:48",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-12 22:06:34",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-01-12 22:06:36",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-12 22:06:39",
                  "engagementType" : "VideoContent1secView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1861056938143776939",
                  "tweetText" : "Luz + gas para tu hogar con 70€ en tu factura. Rápido, claro y sin permanencia. 🐙 \n\n¿A qué esperas? 💡🔥",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Octopus Energy España",
                  "screenName" : "@OctopusEnergyES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@elconfidencial"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@el_pais"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@LaVanguardia"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@20m"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@PSOE"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Sports news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Science news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Financial news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Business and news"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-12 22:06:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-12 22:06:16",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1877739573402276221",
                  "tweetText" : "Por si queréis cambiar de táctica en FC25 os dejamos la 4-5-1 explicada por @Gravesen_1. https://t.co/oMuraFvqJC",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/oMuraFvqJC"
                  ]
                },
                "publisherInfo" : {
                  "publisherName" : "DUX Gaming",
                  "screenName" : "@TeamDUXGaming"
                },
                "advertiserInfo" : {
                  "advertiserName" : "McDonald's España",
                  "screenName" : "@mcdonalds_es"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Computer gaming"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Console gaming"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Roleplaying games"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Gaming news and general info"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Action and adventure"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Drama"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Romance"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Cartoons"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Dining out"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Foodie news and general info"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 54"
                  }
                ],
                "impressionTime" : "2025-01-12 22:06:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-12 22:07:51",
                  "engagementType" : "VideoAdPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-12 22:07:54",
                  "engagementType" : "VideoAdPlayback25"
                },
                {
                  "engagementTime" : "2025-01-12 22:07:54",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1877441576529703356",
                  "tweetText" : "\"Ponte de tu parte. Vas a ser quien quieras ser\"\n\nMarta Nieto ofrece en su opera prima una delicada mirada a la maternidad y la identidad de género. \n\nLA MITAD DE ANA  🦋  YA EN CINES",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "elasticafilms",
                  "screenName" : "@ElasticaFilms"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@deformesemanal_"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Barcelona"
                  }
                ],
                "impressionTime" : "2025-01-12 22:06:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-12 22:06:26",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-12 22:06:25",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-01-12 22:06:33",
                  "engagementType" : "VideoSession"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1877441576529703356",
                  "tweetText" : "\"Ponte de tu parte. Vas a ser quien quieras ser\"\n\nMarta Nieto ofrece en su opera prima una delicada mirada a la maternidad y la identidad de género. \n\nLA MITAD DE ANA  🦋  YA EN CINES",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "elasticafilms",
                  "screenName" : "@ElasticaFilms"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@deformesemanal_"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Barcelona"
                  }
                ],
                "impressionTime" : "2025-01-13 15:36:14"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-13 15:36:37",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1877144385315381286",
                  "tweetText" : "Empezamos a trabajar los combos con Beebo! https://t.co/IMXVHZvSQw",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/IMXVHZvSQw"
                  ]
                },
                "publisherInfo" : {
                  "publisherName" : "Eric 'Diablo' Murillo",
                  "screenName" : "@DiabloEMT"
                },
                "advertiserInfo" : {
                  "advertiserName" : "McDonald's España",
                  "screenName" : "@mcdonalds_es"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Computer gaming"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Console gaming"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Roleplaying games"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Gaming news and general info"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Action and adventure"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Drama"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Romance"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Cartoons"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Dining out"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Foodie news and general info"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 54"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-14 06:33:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-14 06:35:17",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-14 06:34:03",
                  "engagementType" : "VideoAdPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1878389881480806669",
                  "tweetText" : "🍷 In the shadows, mutant apes brewed something dangerously good. Fine wine, a drop of serum—and the Mutated Wine Collection were born.\n\n 99 Blanc. 99 Red. So potent, they need a special container.\n💎 NFTs, soon fully tradable on the SuperWine platform.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "SuperWine",
                  "screenName" : "@SuperwineIO"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "wine"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2025-01-14 06:33:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-14 06:33:16",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-01-14 06:33:19",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2025-01-14 06:33:20",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-14 06:33:17",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1877264045864317025",
                  "tweetText" : "És increïble el que pot fer una cançó. Ramon Gener t'ho explica com ningú altre ho ha fet abans.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "3Cat",
                  "screenName" : "@som3cat"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Catalonia"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2025-01-14 06:33:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-14 06:33:26",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-01-14 06:33:32",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2025-01-14 06:33:29",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2025-01-14 06:33:32",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2025-01-14 06:33:33",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2025-01-14 06:33:30",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2025-01-14 06:33:27",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-14 06:33:32",
                  "engagementType" : "VideoContentPlayback25"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1861056938143776939",
                  "tweetText" : "Luz + gas para tu hogar con 70€ en tu factura. Rápido, claro y sin permanencia. 🐙 \n\n¿A qué esperas? 💡🔥",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Octopus Energy España",
                  "screenName" : "@OctopusEnergyES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@elconfidencial"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@el_pais"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@LaVanguardia"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@20m"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@PSOE"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Sports news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Science news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Financial news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Business and news"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-14 06:32:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-14 06:32:12",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1876705364701311327",
                  "tweetText" : "🎁 Fiestas navideñas acabadas, limpieza de casa inaugurada.\n\nTe traemos los mejores trucos para limpiarla con productos caseros y ecológicos.\n\n#ConsumidoresBIENInformados #Salud #Limpieza #EroskiConsumer",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Consumer EROSKI. Consumidores bien informados.",
                  "screenName" : "@eroskiconsumer"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-14 06:33:16"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-14 06:37:59",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1828725474010296820",
                  "tweetText" : "La mejor guía práctica que existe sobre la IA",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "eToro",
                  "screenName" : "@eToro"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "ai"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Investors and patents"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Business news and general info"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Beginning investing"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Financial news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Investing"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Options"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Business and finance"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Business & finance"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Investing"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Personal finance"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Personal finance"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Investing"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "eToro"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install eToro: Trade. Invest. Connect. ANDROID All"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "110_Depositors_4mfqsb"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "101_AllRegistrations_4mfqsb"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-19 17:01:51"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-20 09:27:03",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-01-20 09:27:46",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-20 09:27:03",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1871762908658438479",
                  "tweetText" : "Step back in time—vintage gaming fun in a modern world.\nPick it: https://t.co/5TBg13i36M https://t.co/aYyIEyRvYY",
                  "urls" : [
                    "https://t.co/5TBg13i36M"
                  ],
                  "mediaUrls" : [
                    "https://t.co/aYyIEyRvYY"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "VXGME",
                  "screenName" : "@vxgmeofficial"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-01-21 10:14:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-21 10:15:18",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2025-01-21 10:15:23",
                  "engagementType" : "VideoContentPlayback95"
                },
                {
                  "engagementTime" : "2025-01-21 10:14:59",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2025-01-21 10:15:21",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2025-01-21 10:15:24",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2025-01-21 10:14:59",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2025-01-21 10:14:57",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2025-01-21 10:14:59",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2025-01-21 10:14:58",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2025-01-21 10:16:26",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-21 10:14:53",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-21 10:15:24",
                  "engagementType" : "VideoContentPlaybackComplete"
                },
                {
                  "engagementTime" : "2025-01-21 10:15:16",
                  "engagementType" : "VideoContent6secView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1867156944617984137",
                  "tweetText" : "¿Sabías que un niño con Leucemia en Finlandia tienes más posibilidades de sobrevivir que un niño en España? Firma la petición para conseguir implantar el protocolo All Together en nuestro país. \n\n#LeucemiaVeteYa",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "unoentrecienmil",
                  "screenName" : "@unoentrecienmil"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Paintball"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Beer"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Holidays"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "padre"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "FUN - Leucemia Vete Ya Visitantes Web LVY"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "FUN - Personas que han Firmado LVY Página Gracias"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "Spanish"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 54"
                  }
                ],
                "impressionTime" : "2025-02-09 20:13:41"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-02-09 20:13:44",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android"
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1890047888006463567",
                  "tweetText" : "El amor se demuestra en los pequeños detalles y el cuidado del día a día 💕 Y, de eso, en #MAPFRE, sabemos bastante 😉 #FelizSanValentín https://t.co/Adkh8wC5sq",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/Adkh8wC5sq"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "MAPFRE España",
                  "screenName" : "@MAPFRE_ES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "amor"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2025-02-14 12:50:25"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-02-14 12:50:36",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android"
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1887047678632321226",
                  "tweetText" : "¿Tienes un proyecto con impacto social? Lanzamos las Convocatorias de Proyectos Sociales 2025 por comunidad autónoma para impulsar iniciativas que promuevan la igualdad de oportunidades. Inscríbete en el formulario para recibir información. https://t.co/B6dYg7d2qU",
                  "urls" : [
                    "https://t.co/B6dYg7d2qU"
                  ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Fundación ”la Caixa”",
                  "screenName" : "@FundlaCaixa"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "ayudas"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2025-02-14 12:50:03"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-02-14 12:50:05",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-02-14 12:50:18",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-02-14 12:50:22",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2025-02-14 12:50:24",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2025-02-14 12:50:20",
                  "engagementType" : "VideoContentMrcView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1869702679498232133",
                  "tweetText" : "Polítiques d'Innovació 👉 usem indicadors que no apunten als problemes estructurals, als que de veritat importen 👉 disparem en la direcció equivocada 👇👇👇\nhttps://t.co/ei1ILQMl5h https://t.co/lSv3XCpRiA",
                  "urls" : [
                    "https://t.co/ei1ILQMl5h"
                  ],
                  "mediaUrls" : [
                    "https://t.co/lSv3XCpRiA"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "esteve almirall",
                  "screenName" : "@ealmirall"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Catalonia"
                  }
                ],
                "impressionTime" : "2024-12-19 11:35:01"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-19 11:35:33",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1868964983507194177",
                  "tweetText" : "La lotería vívela en X 🥳 Este domingo 22/12 cada vez que salga uno de los 13 premios más importantes, ¡corre! 😱 Tendrás 1 minuto para postear #LoteriaMediaMarkt y GANAR PREMIAZOS✨ ¡Participa que es totalmente GRATIS! Repartimos más de 20.000€ en premios 🥰",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "MediaMarkt España",
                  "screenName" : "@MediaMarkt_es"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Catalonia"
                  }
                ],
                "impressionTime" : "2024-12-19 11:34:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-19 11:34:16",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1861061983795298516",
                  "tweetText" : "🎄🐾 Aquest Nadal, viu la màgia de la biodiversitat al #ZooBarcelona\n\n✨ Activitats especials, emocions úniques i propòsits per al planeta. 🌍\n\n👉 Descobreix-ho a https://t.co/x6Jcmq5Jw8\n\n#NadalAlZoo #ViuElZoo #Biodiversitat",
                  "urls" : [
                    "https://t.co/x6Jcmq5Jw8"
                  ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "zoobarcelona",
                  "screenName" : "@ZooBarcelona"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Barcelona"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Barcelona"
                  }
                ],
                "impressionTime" : "2024-12-19 11:37:09"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-19 11:37:15",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1869439988133249030",
                  "tweetText" : "¡Hemos reinventado las estaciones de servicio! \n\nNuestros establecimientos ofrecen: \n\n🔷Soluciones multienergía. \n🔷Servicios de restauracion, ocio y comercio. \n\n¡Toda una experiencia #VIP!\n\nLo cuenta @libertaddigital 📰",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Moeve",
                  "screenName" : "@MoeveGlobal"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-12-19 11:38:00"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-19 11:38:01",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1869397607694705090",
                  "tweetText" : "Todo es posible en Navidad…Bueno, todo menos que David Bisbal te indique dónde tienes que coger tu próximo vuelo, eso quizá no 😉🎄 \n#Aena #UnaNavidadEnElAeropuerto",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Aena",
                  "screenName" : "@aena"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-12-19 11:35:48"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-19 11:36:08",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1864032836312764642",
                  "tweetText" : "✨Aquest Nadal, sorprèn amb un regal que en són 30 amb l’abonament ‘De Bat a Bat’!🎁 \n\n🏰Podrà descobrir castells, monestirs, ciutats ibèriques, gregues i romanes, paisatges monumentals, museus... Tot l’any i tantes vegades com vulgui!\n\n👉Aconsegueix-lo a: https://t.co/qnba7Pke2G https://t.co/lRIKEoSLtl",
                  "urls" : [
                    "https://t.co/qnba7Pke2G"
                  ],
                  "mediaUrls" : [
                    "https://t.co/lRIKEoSLtl"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Patrimoni",
                  "screenName" : "@patrimonigencat"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Catalonia"
                  }
                ],
                "impressionTime" : "2024-12-19 11:37:36"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-19 11:37:43",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-12-19 11:37:50",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-19 11:37:48",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1869774227521589717",
                  "tweetText" : "Con visiones ambiciosas y esfuerzos inspiradores 🇸🇦..\nÉxito excepcional para #IGF2024.\nReconocimiento internacional 🇺🇳 para la 19.ª sesión.\n\n#IGF2024 https://t.co/pLdrO37A4Y",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/pLdrO37A4Y"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "وزارة الاتصالات وتقنية المعلومات",
                  "screenName" : "@McitGovSa"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "Spanish"
                  }
                ],
                "impressionTime" : "2024-12-19 20:18:30"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-19 20:18:39",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1862077308481540415",
                  "tweetText" : "🎄 La Navidad sabe mejor con Carrefour Extra 💫 Disfruta de productos muy especiales al mejor precio ❤️ Solo hasta el 31/12",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Carrefour España",
                  "screenName" : "@CarrefourES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Foodie news and general info"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 54"
                  }
                ],
                "impressionTime" : "2024-12-19 20:18:30"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-19 20:19:16",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1868701410281341007",
                  "tweetText" : "¡La lucha está por comenzar! Dale ❤️ y recibe alertas para no perderte ni un solo golpe. ¡RAW llega en directo a Netflix este 7 de enero!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Netflix España",
                  "screenName" : "@NetflixES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Movies and TV shows",
                    "targetingValue" : "WWE Friday Night SmackDown"
                  },
                  {
                    "targetingType" : "Movies and TV shows",
                    "targetingValue" : "WWE Monday Night RAW"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Boxing"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Martial arts"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-19 20:18:30"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-19 20:18:39",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-19 20:18:39",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1868721760910377368",
                  "tweetText" : "¡PREPÁRATE! Netflix te trae la WWE en enero de 2025",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Netflix España",
                  "screenName" : "@NetflixES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Movies and TV shows",
                    "targetingValue" : "WWE Monday Night RAW"
                  },
                  {
                    "targetingType" : "Movies and TV shows",
                    "targetingValue" : "WWE Friday Night SmackDown"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Boxing"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Martial arts"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-12-19 20:18:30"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-19 20:18:34",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-19 20:18:33",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-12-19 20:18:35",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1869343035819225384",
                  "tweetText" : "Fútbol de Tiki-Taka en la jornada 17 de @LaLiga. ⚽✨\n¿Qué #ConexiónMahou eliges? 👇 https://t.co/lsgMpZOnvb",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/lsgMpZOnvb"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Fútbol Mahou",
                  "screenName" : "@futbolmahou"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "drink"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "beer"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-12-19 20:19:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-19 20:19:35",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-12-19 20:19:35",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-19 20:19:38",
                  "engagementType" : "VideoSession"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android"
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1889759116106801367",
                  "tweetText" : "¡Atención, comunidad! 🎉 Lo que todos esperábamos ha regresado... \n\n#SolanaSpainTour2025 🇪🇸 \n\nEn esta edición, visitaremos 4 ciudades: Madrid, Barcelona, Málaga y Galicia.\n\nY esta vez contaremos con la compañía de @LaFamila_so 💣🕵️‍♂️ https://t.co/SpxXhynGxj",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/SpxXhynGxj"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Heavy Duty Builders",
                  "screenName" : "@HeavyDutyBuild"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "españa"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  }
                ],
                "impressionTime" : "2025-02-17 17:40:59"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-02-17 17:41:19",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1891793783039176784",
                  "tweetText" : "Nuestra plataforma está diseñada pensando en ti, con herramientas fáciles de usar para que cualquier inversor puede beneficiarse. 💪 ¡Empieza hoy mismo! Invertir conlleva riesgo de pérdida.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "DEGIRO",
                  "screenName" : "@DEGIRO"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Investing"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Investing"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Beginning investing"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Financial news"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Sign Ups "
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Trader"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Open an Account button "
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Final Step Onboarding "
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 to 54"
                  }
                ],
                "impressionTime" : "2025-03-01 17:45:47"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-03-01 17:45:50",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android"
                },
                "displayLocation" : "Spotlight",
                "promotedTrendInfo" : {
                  "trendId" : "106246",
                  "name" : "#Xiaomi15Series",
                  "description" : "Lanzamiento Xiaomi, marzo 2025"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Xiaomi España",
                  "screenName" : "@XiaomiEspana"
                },
                "impressionTime" : "2025-03-02 17:05:35"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-03-02 17:05:37",
                  "engagementType" : "SpotlightView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "106240",
                  "name" : "#HONORALPHA",
                  "description" : "Discover more about HONOR ALPHA PLAN at MWC2025"
                },
                "advertiserInfo" : {
                  "advertiserName" : "HONOR",
                  "screenName" : "@Honorglobal"
                },
                "impressionTime" : "2025-03-03 17:32:11"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-03-03 17:32:12",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android"
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1894679006160855202",
                  "tweetText" : "🔜 L'#AMB tancarà aviat la seva participació a #Connects del @BSC_CNS! 💡🔗 Amb +1200 investigadors i un dels supercomputadors més potents, impulsem innovacions per millorar serveis públics i la relació amb la ciutadania. 🚀🔄\n\nhttps://t.co/xlxyMB30LC https://t.co/CaYx8EsQAr",
                  "urls" : [
                    "https://t.co/xlxyMB30LC"
                  ],
                  "mediaUrls" : [
                    "https://t.co/CaYx8EsQAr"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "AMB - Àrea d'Internacional i Metròpolis Digital",
                  "screenName" : "@AMB_MetroGlobal"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "08901"
                  }
                ],
                "impressionTime" : "2025-03-03 20:59:06"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-03-03 21:00:03",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1866846048024514972",
                  "tweetText" : "New holes! New balls! We'll see you on the course soon 😉\n\nGolf With Your Friends 2, coming 2025 from @RadicalForge and Team17! 🏌️\n\n⛳ New courses!\n🤝 Cross-platform multiplayer!\n🏗️ Cross-platform level editor!\n💨 Improved physics!\nAnd more!\n\nWishlist: https://t.co/QV2UrLlBd0 https://t.co/55GwsZnJ6w",
                  "urls" : [
                    "https://t.co/QV2UrLlBd0"
                  ],
                  "mediaUrls" : [
                    "https://t.co/55GwsZnJ6w"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Team17",
                  "screenName" : "@Team17"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Console gaming"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Nintendo Switch"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-22 15:27:04"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-22 15:27:19",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-22 15:27:20",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-22 15:27:24",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-22 15:27:17",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1868982297535385631",
                  "tweetText" : "La NFL en DIRECTO en Netflix ¡por primera vez! Chiefs vs. Steelers a las 19:00 (hora peninsular) y Ravens vs. Texans a las 22:30 (hora peninsular).",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Netflix España",
                  "screenName" : "@NetflixES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 34"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-23 09:15:40"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-23 09:15:47",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-12-23 09:15:44",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-12-23 09:15:43",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-23 09:15:45",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-12-23 09:15:46",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2024-12-23 09:15:46",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2024-12-23 09:15:48",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-23 09:15:42",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1861056835601735976",
                  "tweetText" : "Luz + gas para tu hogar con 70€ en tu factura. Rápido, claro y sin permanencia. 🐙 \n\n¿A qué esperas? 💡🔥",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Octopus Energy España",
                  "screenName" : "@OctopusEnergyES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@elconfidencial"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@el_pais"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@LaVanguardia"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@20m"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@PSOE"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Sports news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Science news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Financial news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Business and news"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-23 13:42:56"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-23 13:49:47",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1861440174095216827",
                  "tweetText" : "⚡️BREAKING NEWS⚡️ \n\nBeefeater Black ha llegado para elevar todas tus noches.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Beefeater",
                  "screenName" : "@beefeatergin_ES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Liquor and spirits"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Foodie news and general info"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Gin"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  }
                ],
                "impressionTime" : "2024-12-23 13:42:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-23 13:46:04",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-12-23 13:46:11",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2024-12-23 13:46:14",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-23 13:46:05",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-23 13:46:07",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-12-23 13:46:12",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2024-12-23 13:46:09",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-12-23 13:46:11",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2024-12-23 13:46:11",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-12-23 13:46:09",
                  "engagementType" : "VideoContentPlayback25"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1870155588023308504",
                  "tweetText" : "🎄 Las Navidades de bet365™\n\n12 días. 12 ofertas.\n\nEn bet365, marcamos la diferencia.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "bet365 España",
                  "screenName" : "@bet365_es"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2024-12-23 13:42:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-23 13:44:11",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1856285678025179183",
                  "tweetText" : "Som la banca pública de promoció de Catalunya i treballem per a impulsar:\n\n🏠 L'habitatge social \n\n🌍 La transició ecològica\n\n♻️ La industrialització verda\n\n🚜 El sector primari  \n\n💡  La innovació\n\nSi tens projectes que vols que deixin de ser projectes, #TensTotElNostreCrèdit.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "ICF",
                  "screenName" : "@icfcat"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Barcelona"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Barcelona"
                  }
                ],
                "impressionTime" : "2024-12-23 13:47:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-23 13:48:57",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-23 13:48:56",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1868740014005231961",
                  "tweetText" : "🗣️ \"𝘌𝘴 𝘶𝘯 𝘤𝘢𝘮𝘪𝘯𝘰 𝘥𝘦 𝘮𝘢́𝘹𝘪𝘮𝘢 𝘦𝘹𝘪𝘨𝘦𝘯𝘤𝘪𝘢\".\n\n🆚 Portugal, Bélgica e Italia: \n\n¡𝗔𝘀𝗶́ 𝘃𝗮𝗹𝗼𝗿𝗮 @montse_tome 𝗮 𝗻𝘂𝗲𝘀𝘁𝗿𝗼𝘀 𝗿𝗶𝘃𝗮𝗹𝗲𝘀!\n\n#JugarLucharYGanar https://t.co/VKkcZFdhM8",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/VKkcZFdhM8"
                  ]
                },
                "publisherInfo" : {
                  "publisherName" : "Selección Española Femenina de Fútbol",
                  "screenName" : "@SEFutbolFem"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Netflix España",
                  "screenName" : "@NetflixES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Boxing"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Martial arts"
                  },
                  {
                    "targetingType" : "Movies and TV shows",
                    "targetingValue" : "WWE Monday Night RAW"
                  },
                  {
                    "targetingType" : "Movies and TV shows",
                    "targetingValue" : "WWE Friday Night SmackDown"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Sports news"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Sports events"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Sports"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-12-23 13:42:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-23 13:42:59",
                  "engagementType" : "VideoAdViewThreshold"
                },
                {
                  "engagementTime" : "2024-12-23 13:43:02",
                  "engagementType" : "VideoAd6secView"
                },
                {
                  "engagementTime" : "2024-12-23 13:42:56",
                  "engagementType" : "VideoAdPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-23 13:43:04",
                  "engagementType" : "VideoAdPlayback25"
                },
                {
                  "engagementTime" : "2024-12-23 13:42:58",
                  "engagementType" : "VideoAdMrcView"
                },
                {
                  "engagementTime" : "2024-12-23 13:42:59",
                  "engagementType" : "VideoAdView"
                },
                {
                  "engagementTime" : "2024-12-23 13:43:06",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-23 13:42:58",
                  "engagementType" : "VideoAd1secView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1865195718425874730",
                  "tweetText" : "Sin contratos de larga duración.\n\nFácil de pedir por internet.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Starlink",
                  "screenName" : "@Starlink"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "List",
                    "targetingValue" : "Starlink Global Customer list"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "All Starlink Customers"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Purchasers"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "Spanish"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2024-12-23 13:42:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-23 13:47:07",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1863610681658089960",
                  "tweetText" : "Nada es más auténtico que disfrutar de lo que te gusta a tu ritmo.\n\nBallantine’s 10\n\nHecho a nuestra manera, para que la disfrutes a la tuya.\n\n#StayTrue",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Ballantine's España",
                  "screenName" : "@Ballantines_ES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Liquor and spirits"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Drinks"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  }
                ],
                "impressionTime" : "2024-12-23 13:42:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-23 13:45:33",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-23 13:45:49",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-23 13:45:32",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1868612389383364838",
                  "tweetText" : "🏆 ¡¡Tercer título de la temporada para la @SEFutbolFem playa!!\n\n👏 Pleno de victorias y campeonas de la 𝙒𝒐𝙢𝒆𝙣'𝙨 𝘼𝙘𝒂𝙥𝒖𝙡𝒄𝙤 𝑩𝙚𝒂𝙘𝒉 𝑺𝙤𝒄𝙘𝒆𝙧 𝘾𝒖𝙥\n\n🆚 🇺🇸 (4-2)\n🆚 🇨🇷 (2-0)\n🆚  🇲🇽 (0-10)\n\n🙌 ¡¡ENHORABUENA!!\n\n#AcapulcoCup https://t.co/o6QCwsEFeb",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/o6QCwsEFeb"
                  ]
                },
                "publisherInfo" : {
                  "publisherName" : "Selección Española Femenina de Fútbol",
                  "screenName" : "@SEFutbolFem"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Netflix España",
                  "screenName" : "@NetflixES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Movies and TV shows",
                    "targetingValue" : "WWE Friday Night SmackDown"
                  },
                  {
                    "targetingType" : "Movies and TV shows",
                    "targetingValue" : "WWE Monday Night RAW"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Sports news"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Sports events"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Sports"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Boxing"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Martial arts"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-23 11:39:28"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-23 13:42:46",
                  "engagementType" : "VideoAdPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-23 13:42:56",
                  "engagementType" : "VideoSession"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1869312695704666394",
                  "tweetText" : "👑 Descuentos de REYES para los mejores regalos 🎁 Disfruta de nuestras mágicas ofertas a precios increíbles y ahorra a lo grande✨",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Carrefour España",
                  "screenName" : "@CarrefourES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "niños"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "niño"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2024-12-24 20:48:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-24 20:48:37",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1869049476679106882",
                  "tweetText" : "Todo es posible en Navidad…Bueno, todo menos que David Bisbal te indique dónde tienes que coger tu próximo vuelo, eso quizá no 😉🎄 \n#Aena #UnaNavidadEnElAeropuerto",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Aena",
                  "screenName" : "@aena"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-12-26 09:32:48"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 09:35:24",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1870020854194581858",
                  "tweetText" : "6.510 voluntarios. 6,6 toneladas de basuraleza liberadas y 43.896 residuos caracterizados. Solamente podemos dar las GRACIAS por formar parte de #LIBERA1m2 por el campo, los bosques y el monte. 🌳\n\n¡Seguimos luchando contra la #basuraleza!\n\n#ProyectoLIBERA @SEO_BirdLife",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Ecoembes",
                  "screenName" : "@ecoembes"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-26 09:36:59"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 09:37:41",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1863561946974593169",
                  "tweetText" : "Rosa sale del punto A y su trayecto es muy solitario, mientras que María sale del punto B y su camino es mucho más frenético. Si quieres saber dónde se en-cuentran, conoce su historia. Porque nosotros no creemos en las coincidencias, creemos en las oportunidades.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "promotedTrendInfo" : {
                  "trendId" : "105220",
                  "name" : "#FundlaCaixa20241226",
                  "description" : ""
                },
                "advertiserInfo" : {
                  "advertiserName" : "Fundación ”la Caixa”",
                  "screenName" : "@FundlaCaixa"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-26 09:31:51"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 09:31:57",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-26 09:38:28",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-26 09:31:57",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-12-26 09:31:56",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-12-26 09:31:54",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1871856180114633190",
                  "tweetText" : "6 DAYS TO GO!! 🥳\n\nThe MetaWin Millionaire draw is almost here! 100 separate winners, the jackpot grows larger with every entry &amp; ZERO ⛽️ !\n\nENTER NOW ➡️ https://t.co/D14GA1XhKI",
                  "urls" : [
                    "https://t.co/D14GA1XhKI"
                  ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "METAWIN",
                  "screenName" : "@Meta_Winners"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Cryptocurrencies"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 to 49"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-12-26 09:35:56"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 09:35:59",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1870038067312263279",
                  "tweetText" : "¡Otro #MAPFREguessr por el norte! Venga, que esta vez no es tan difícil.\n\n¿Serás capaz de adivinar dónde estamos? 😏 https://t.co/lnHHgubQKn",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/lnHHgubQKn"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "MAPFRE Para Ti",
                  "screenName" : "@MAPFRE_ParaTi"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 34"
                  }
                ],
                "impressionTime" : "2024-12-26 09:37:43"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 09:37:45",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "advertiserInfo" : {
                  "advertiserName" : "Mohammed Al-Issa محمد العيسى",
                  "screenName" : "@MhmdAlissa"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-26 09:42:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 09:42:54",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1866804002446360663",
                  "tweetText" : "🎥Ya puedes ver el resumen de las Jornadas de Realidades!\n\n📖Presentamos la Guía de Cohousing Inclusivo y estrenamos la campaña Cultura Para Todas.\n\nMíralo aquí👉https://t.co/XpUldiL9Tn\n\n#CohousingInclusivo #DerechoALaCultura #SinHogarYConDerechos",
                  "urls" : [
                    "https://t.co/XpUldiL9Tn"
                  ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "AsociaciónRealidades",
                  "screenName" : "@RealidadesONG"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "Spanish"
                  }
                ],
                "impressionTime" : "2024-12-26 09:41:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 09:42:24",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "advertiserInfo" : {
                  "advertiserName" : "Loryvel",
                  "screenName" : "@Loryvelshop"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "sale"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "set"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "deals"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "new"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "family"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "win"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "games"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "kids"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "best"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "deal"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "hands"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "support"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "women"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "home"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "offers"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "save"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "gadgets"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "love"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "designed"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "son"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  }
                ],
                "impressionTime" : "2024-12-26 09:37:52"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 09:38:01",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2024-12-26 09:38:00",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-12-26 09:37:56",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-12-26 09:37:54",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-26 09:38:06",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-26 09:38:01",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2024-12-26 09:38:01",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-12-26 09:38:01",
                  "engagementType" : "VideoContentPlayback25"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1868588712449446211",
                  "tweetText" : "El juego no se detiene. La segunda temporada de ‘El juego del calamar’ se estrena el 26 de diciembre, solo en Netflix.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Netflix España",
                  "screenName" : "@NetflixES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 54"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-26 09:38:26"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 09:39:14",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-26 09:39:58",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-26 09:38:54",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1868597694203326821",
                  "tweetText" : "Inspira con tu ejemplo. \n\n#LALIGAVSODIO #LaFuerzaDeNuestroFútbol https://t.co/ifTeVsjtOw",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/ifTeVsjtOw"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "LALIGA",
                  "screenName" : "@LaLiga"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "messi"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "sports"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "real madrid"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "futbol"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-26 09:36:07"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 09:36:10",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-26 09:36:14",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-12-26 09:36:08",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-12-26 09:36:12",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-12-26 09:36:15",
                  "engagementType" : "VideoSession"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1868721760910377368",
                  "tweetText" : "¡PREPÁRATE! Netflix te trae la WWE en enero de 2025",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Netflix España",
                  "screenName" : "@NetflixES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Movies and TV shows",
                    "targetingValue" : "WWE Friday Night SmackDown"
                  },
                  {
                    "targetingType" : "Movies and TV shows",
                    "targetingValue" : "WWE Monday Night RAW"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Boxing"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Martial arts"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-26 11:04:01"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 19:16:45",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1861056835601735976",
                  "tweetText" : "Luz + gas para tu hogar con 70€ en tu factura. Rápido, claro y sin permanencia. 🐙 \n\n¿A qué esperas? 💡🔥",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Octopus Energy España",
                  "screenName" : "@OctopusEnergyES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@elconfidencial"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@el_pais"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@LaVanguardia"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@20m"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@PSOE"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Sports news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Science news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Financial news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Business and news"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2024-12-26 20:13:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 20:15:18",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1870016296093692404",
                  "tweetText" : "Gila está de vuelta, pero no tiene muy claro donde ha ido🤷🏻… #Identiqué #NavidadCampofrío",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Campofrío España",
                  "screenName" : "@Campofrio_es"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 54"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-26 20:13:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 20:15:33",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-12-26 20:15:59",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-26 20:15:56",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1863561676509098031",
                  "tweetText" : "Raquel sale del punto A, pero no encuentra lo que está buscando. Marta, desde el punto B, tiene las herramientas para ayudarla a encontrarlo. Conoce su histo-ria para saber dónde se encuentran. Porque nosotros no creemos en las coinci-dencias, creemos en las oportunidades.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "promotedTrendInfo" : {
                  "trendId" : "105220",
                  "name" : "#FundlaCaixa20241226",
                  "description" : ""
                },
                "advertiserInfo" : {
                  "advertiserName" : "Fundación ”la Caixa”",
                  "screenName" : "@FundlaCaixa"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-26 20:13:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 20:13:39",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-12-26 20:13:39",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-12-26 20:13:36",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-26 20:13:41",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1861056938143776939",
                  "tweetText" : "Luz + gas para tu hogar con 70€ en tu factura. Rápido, claro y sin permanencia. 🐙 \n\n¿A qué esperas? 💡🔥",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Octopus Energy España",
                  "screenName" : "@OctopusEnergyES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@elconfidencial"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@el_pais"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@LaVanguardia"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@20m"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@PSOE"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Sports news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Science news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Financial news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Business and news"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-26 19:16:45"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 19:20:04",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1868491217329377786",
                  "tweetText" : "Compact and convenient—perfect for travel or home use.\nGet it: https://t.co/DI0P4ejomB https://t.co/iqxLBdTDNj",
                  "urls" : [
                    "https://t.co/DI0P4ejomB"
                  ],
                  "mediaUrls" : [
                    "https://t.co/iqxLBdTDNj"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Nesteasehub",
                  "screenName" : "@Nesteasehub"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "news"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "fun"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "kids"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "2023"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "love"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "master"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "sale"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "design"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "sound"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "deal"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "hand"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "day"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "game"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "peace"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "snow"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "women"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "games"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "set"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "star"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "coming"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "family"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "save"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "styles"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Android"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-26 19:27:35"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 19:27:45",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-26 19:27:47",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-26 19:27:57",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1863608463861092787",
                  "tweetText" : "El juego debe continuar. Segunda temporada. 26 de diciembre.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Netflix España",
                  "screenName" : "@NetflixES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 54"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-26 19:16:45"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 19:16:52",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-26 19:16:48",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-26 19:16:47",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1863561946974593169",
                  "tweetText" : "Rosa sale del punto A y su trayecto es muy solitario, mientras que María sale del punto B y su camino es mucho más frenético. Si quieres saber dónde se en-cuentran, conoce su historia. Porque nosotros no creemos en las coincidencias, creemos en las oportunidades.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "promotedTrendInfo" : {
                  "trendId" : "105220",
                  "name" : "#FundlaCaixa20241226",
                  "description" : ""
                },
                "advertiserInfo" : {
                  "advertiserName" : "Fundación ”la Caixa”",
                  "screenName" : "@FundlaCaixa"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-26 19:20:55"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 19:22:20",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-26 19:22:13",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1863610681658089960",
                  "tweetText" : "Nada es más auténtico que disfrutar de lo que te gusta a tu ritmo.\n\nBallantine’s 10\n\nHecho a nuestra manera, para que la disfrutes a la tuya.\n\n#StayTrue",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Ballantine's España",
                  "screenName" : "@Ballantines_ES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Drinks"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Liquor and spirits"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  }
                ],
                "impressionTime" : "2024-12-26 19:16:45"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 19:19:25",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-26 19:18:12",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-26 19:17:45",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1861439314850107579",
                  "tweetText" : "Las noches ya no son las mismas desde que son Black nights.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Beefeater",
                  "screenName" : "@beefeatergin_ES"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Gin"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Liquor and spirits"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Foodie news and general info"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  }
                ],
                "impressionTime" : "2024-12-26 19:16:45"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-26 19:17:20",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-12-26 19:17:19",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-12-26 19:17:21",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-26 19:17:19",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            }
          ]
        }
      }
    }
  }
]