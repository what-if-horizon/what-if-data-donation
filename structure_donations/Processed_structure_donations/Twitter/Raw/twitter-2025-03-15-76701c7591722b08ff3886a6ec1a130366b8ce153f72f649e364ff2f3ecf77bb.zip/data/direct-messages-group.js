window.YTD.direct_messages_group.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "1632657560749633536",
      "messages" : [
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/g56M8ia5t5",
                "expanded" : "https://twitter.com/clauwa/status/1638512491838971906",
                "display" : "twitter.com/clauwa/status/…"
              }
            ],
            "text" : "https://t.co/g56M8ia5t5",
            "mediaUrls" : [ ],
            "senderId" : "1917680526",
            "id" : "1639621292482592772",
            "createdAt" : "2023-03-25T13:32:33.511Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Lo miraré!",
            "mediaUrls" : [ ],
            "senderId" : "1917680526",
            "id" : "1638590403636019210",
            "createdAt" : "2023-03-22T17:16:10.446Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Gracias Camilo!",
            "mediaUrls" : [ ],
            "senderId" : "1917680526",
            "id" : "1638590291664936966",
            "createdAt" : "2023-03-22T17:15:43.753Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Le voy a dar un ojo, parece guay. A ver si mola tanto como Elicit o WriteWise😜",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1638479860237496324",
            "createdAt" : "2023-03-22T09:56:54.847Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/ZMQaVSlnnO",
                "expanded" : "https://twitter.com/adelineylo/status/1638162277986713600",
                "display" : "twitter.com/adelineylo/sta…"
              }
            ],
            "text" : "https://t.co/ZMQaVSlnnO",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1638473050818576389",
            "createdAt" : "2023-03-22T09:29:51.367Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "👌👌👌😜",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1632677646353014794",
            "createdAt" : "2023-03-06T09:40:59.253Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "reactions" : [
              {
                "senderId" : "1917680526",
                "reactionKey" : "agree",
                "eventId" : "1632667416378458112",
                "createdAt" : "2023-03-06T09:00:20.221Z"
              }
            ],
            "urls" : [
              {
                "url" : "https://t.co/TaseDbz7i6",
                "expanded" : "https://twitter.com/Artifexx/status/1632277025472888833",
                "display" : "twitter.com/Artifexx/statu…"
              }
            ],
            "text" : "https://t.co/TaseDbz7i6",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1632657560749633540",
            "createdAt" : "2023-03-06T08:21:10.512Z",
            "editHistory" : [ ]
          }
        },
        {
          "joinConversation" : {
            "initiatingUserId" : "171421468",
            "participantsSnapshot" : [
              "1312048977538437120",
              "1917680526",
              "171421468"
            ],
            "createdAt" : "2023-03-06T08:21:10.509Z"
          }
        }
      ]
    }
  }
]