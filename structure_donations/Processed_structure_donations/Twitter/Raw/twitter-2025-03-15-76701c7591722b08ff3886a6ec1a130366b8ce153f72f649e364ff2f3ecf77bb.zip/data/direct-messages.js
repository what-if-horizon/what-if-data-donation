window.YTD.direct_messages.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "7849082-1312048977538437120",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "No hay de qué!",
            "mediaUrls" : [ ],
            "senderId" : "7849082",
            "id" : "1598345564965539846",
            "createdAt" : "2022-12-01T15:57:33.211Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "7849082",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Muchas gracias, un saludo!",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1598314193786224644",
            "createdAt" : "2022-12-01T13:52:53.731Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Buenos días Andreu. En primer lugar, te informamos que las respuestas a través de este canal no son automáticas ni inmediatas. \nReferente a tu factura, acabamos de enviártela. Revisa tu bandeja de entrada y carpeta spam. Cualquier cosa, nos dices. Saludos",
            "mediaUrls" : [ ],
            "senderId" : "7849082",
            "id" : "1598300973746819076",
            "createdAt" : "2022-12-01T13:00:21.830Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "7849082",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Piensan contestar?",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1598276852862406660",
            "createdAt" : "2022-12-01T11:24:31.016Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "7849082",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Buenos dias, le envio el codigo de mi reserva PIRV3N. Necesito la factura y la he pedido varias veces. La necesito con mucha urgencia porque necesitamos cerrar el presupuesto del ministerio. He intentado comunicarme con vosotros pero parece que no estáis por la labor de solucionarlo. Espero que este último recurso de sus frutos.",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1598262815881674757",
            "createdAt" : "2022-12-01T10:28:44.347Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "171421468-1312048977538437120",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/XediuEa4tQ",
                "expanded" : "https://twitter.com/BowenJin13/status/1895544294473109889",
                "display" : "twitter.com/BowenJin13/sta…"
              }
            ],
            "text" : "https://t.co/XediuEa4tQ",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1897010494629625999",
            "createdAt" : "2025-03-04T19:45:21.376Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/ivk8C8DnDl",
                "expanded" : "https://twitter.com/akshay_pachaar/status/1875883806206673162",
                "display" : "twitter.com/akshay_pachaar…"
              }
            ],
            "text" : "https://t.co/ivk8C8DnDl",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1875993050419257592",
            "createdAt" : "2025-01-05T19:49:32.191Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/rV2E5M0ZiQ",
                "expanded" : "https://twitter.com/akshay_pachaar/status/1865373322932031848",
                "display" : "twitter.com/akshay_pachaar…"
              }
            ],
            "text" : "https://t.co/rV2E5M0ZiQ",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1866153845350699219",
            "createdAt" : "2024-12-09T16:12:02.907Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [
              {
                "senderId" : "1312048977538437120",
                "reactionKey" : "surprised",
                "eventId" : "1855175796043702272",
                "createdAt" : "2024-11-09T09:09:11.941Z"
              }
            ],
            "urls" : [
              {
                "url" : "https://t.co/cJFb4L1PAL",
                "expanded" : "https://twitter.com/rohanpaul_ai/status/1855029275898089839",
                "display" : "twitter.com/rohanpaul_ai/s…"
              }
            ],
            "text" : "https://t.co/cJFb4L1PAL",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1855174797749026999",
            "createdAt" : "2024-11-09T09:05:13.973Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/mCbKaUXflM",
                "expanded" : "https://twitter.com/rohanpaul_ai/status/1851995781533925881",
                "display" : "twitter.com/rohanpaul_ai/s…"
              }
            ],
            "text" : "https://t.co/mCbKaUXflM",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1852424924918411375",
            "createdAt" : "2024-11-01T18:58:13.193Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/6CYA2ckhwc",
                "expanded" : "https://twitter.com/rohanpaul_ai/status/1851997757147693194",
                "display" : "twitter.com/rohanpaul_ai/s…"
              }
            ],
            "text" : "https://t.co/6CYA2ckhwc",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1852289635667345866",
            "createdAt" : "2024-11-01T10:00:37.732Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Es hora de que alguien haga un paper con el timeline de Musk a modo de mofa",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1851532204259602540",
            "createdAt" : "2024-10-30T07:50:51.990Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Vuelve la investigación con Twitter!",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1851532039142494569",
            "createdAt" : "2024-10-30T07:50:12.626Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Wow! Lástima que lo van a petar todo de influencers sintéticos😅😅",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1851531650859253803",
            "createdAt" : "2024-10-30T07:48:40.048Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/1ANQVyyjfg",
                "expanded" : "https://twitter.com/AlexFinnX/status/1851338227925631102",
                "display" : "twitter.com/AlexFinnX/stat…"
              }
            ],
            "text" : "https://t.co/1ANQVyyjfg",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1851517890140471376",
            "createdAt" : "2024-10-30T06:53:59.251Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Lo has probado?",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1847929515756188113",
            "createdAt" : "2024-10-20T09:15:04.131Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/6C4ehBliG0",
                "expanded" : "https://twitter.com/akshay_pachaar/status/1847312752941085148",
                "display" : "twitter.com/akshay_pachaar…"
              }
            ],
            "text" : "Bueno para seguir.... https://t.co/6C4ehBliG0",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1847922144954483160",
            "createdAt" : "2024-10-20T08:45:46.800Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [
              {
                "senderId" : "1312048977538437120",
                "reactionKey" : "surprised",
                "eventId" : "1839524540277260288",
                "createdAt" : "2024-09-27T04:36:41.785Z"
              }
            ],
            "urls" : [
              {
                "url" : "https://t.co/ZkiOQr8I9n",
                "expanded" : "https://twitter.com/AlphaSignalAI/status/1839348216317505735",
                "display" : "twitter.com/AlphaSignalAI/…"
              }
            ],
            "text" : "https://t.co/ZkiOQr8I9n",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1839524222197964834",
            "createdAt" : "2024-09-27T04:35:25.987Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/l5guPhNLIv",
                "expanded" : "https://twitter.com/omarsar0/status/1836599280477299013",
                "display" : "twitter.com/omarsar0/statu…"
              }
            ],
            "text" : "https://t.co/l5guPhNLIv",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1836646299854143632",
            "createdAt" : "2024-09-19T05:59:35.826Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/s0fkiZTWSX",
                "expanded" : "https://twitter.com/DotCSV/status/1835705621657579576",
                "display" : "twitter.com/DotCSV/status/…"
              }
            ],
            "text" : "https://t.co/s0fkiZTWSX",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1836090120971128969",
            "createdAt" : "2024-09-17T17:09:32.459Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/Ul9IsFZohT",
                "expanded" : "https://twitter.com/batista1088/status/1834696727216963623",
                "display" : "twitter.com/batista1088/st…"
              }
            ],
            "text" : "https://t.co/Ul9IsFZohT",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1835009485653282931",
            "createdAt" : "2024-09-14T17:35:28.916Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [
              {
                "senderId" : "1312048977538437120",
                "reactionKey" : "excited",
                "eventId" : "1834645263266594818",
                "createdAt" : "2024-09-13T17:28:11.491Z"
              }
            ],
            "urls" : [
              {
                "url" : "https://t.co/krXH7o2zYL",
                "expanded" : "https://twitter.com/omarsar0/status/1834235024675406012",
                "display" : "twitter.com/omarsar0/statu…"
              }
            ],
            "text" : "https://t.co/krXH7o2zYL",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1834501511776293354",
            "createdAt" : "2024-09-13T07:56:58.507Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "😳😳😳",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1834491533179130196",
            "createdAt" : "2024-09-13T07:17:19.413Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Y el de números y estadísticas de Claude 😯",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1834479499045732485",
            "createdAt" : "2024-09-13T06:29:30.248Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ha salido Strawberry. El nuevo modelo de OpenAI. Olvida lo que te dije de razonamiento de Sonnet. En teoría, éste va a cambiar algunas cosas del razonamiento de los modelos.",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1834461301092782465",
            "createdAt" : "2024-09-13T05:17:11.517Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/SXiYhJ36xP",
                "expanded" : "https://twitter.com/messages/media/1832043969380761738",
                "display" : "pic.twitter.com/SXiYhJ36xP"
              }
            ],
            "text" : "Es viernes... https://t.co/SXiYhJ36xP",
            "mediaUrls" : [
              "https://video.twimg.com/dm_gif/1832043960459505664/lzoeMaTFUlbPw_ytP5IbY7nYswZzfFSVKym4MSYOt9e4NmJdxd.mp4"
            ],
            "senderId" : "171421468",
            "id" : "1832043969380761738",
            "createdAt" : "2024-09-06T13:11:34.794Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Me ha costado leer 3 veces el abstract para pillar lo de DEBATE...",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1832031603557642563",
            "createdAt" : "2024-09-06T12:22:26.482Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Lo de los acrónimos se está llendo de las manos. Los data engineers no están emocionalmente preparados para ponerle el nombre a sus productos...",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1832031463400722546",
            "createdAt" : "2024-09-06T12:21:53.078Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/DgzBzJUDEY",
                "expanded" : "https://twitter.com/ML_Burn/status/1831411456577040575",
                "display" : "twitter.com/ML_Burn/status…"
              }
            ],
            "text" : "https://t.co/DgzBzJUDEY",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1832020655690142202",
            "createdAt" : "2024-09-06T11:38:56.325Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Has pasao al club de la putarenfe. Las reclamaciones las lleva la Iris, que es la presidenta de la asociación",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1830869372598132753",
            "createdAt" : "2024-09-03T07:24:09.033Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Sí... A ver cuánto tardo en el tren",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1830867875541680443",
            "createdAt" : "2024-09-03T07:18:12.103Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hoy vas a la uni?",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1830861760791728551",
            "createdAt" : "2024-09-03T06:53:54.237Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [
              {
                "senderId" : "1312048977538437120",
                "reactionKey" : "agree",
                "eventId" : "1830861725802913792",
                "createdAt" : "2024-09-03T06:53:45.865Z"
              }
            ],
            "urls" : [
              {
                "url" : "https://t.co/YApZS3me13",
                "expanded" : "https://twitter.com/rohanpaul_ai/status/1830569747538202874",
                "display" : "twitter.com/rohanpaul_ai/s…"
              }
            ],
            "text" : "https://t.co/YApZS3me13",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1830853263492817213",
            "createdAt" : "2024-09-03T06:20:08.333Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "No me gusta este rebranding hipster en la línea de Adidas😂😂",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1815775604920164820",
            "createdAt" : "2024-07-23T15:46:54.377Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/0BdLh9iIyx",
                "expanded" : "https://twitter.com/elespectador/status/1815737717352812831",
                "display" : "twitter.com/elespectador/s…"
              }
            ],
            "text" : "Ha actualizado el chándal 🤣 https://t.co/0BdLh9iIyx",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1815739893986759032",
            "createdAt" : "2024-07-23T13:25:00.249Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Podemos mirar donde scrappearlas",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1814262597337686275",
            "createdAt" : "2024-07-19T11:34:45.266Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Totalmente",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1814262542832963942",
            "createdAt" : "2024-07-19T11:34:32.267Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Me interesa por las sentencias de UK... Podemos comparar!",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1814239288051048599",
            "createdAt" : "2024-07-19T10:02:07.895Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Es absurdo que pase y nadie diga nada.",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1814228785522512081",
            "createdAt" : "2024-07-19T09:20:23.901Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/ZAvzJ27JJX",
                "expanded" : "https://twitter.com/GoodLawProject/status/1814192198360912178",
                "display" : "twitter.com/GoodLawProject…"
              }
            ],
            "text" : "https://t.co/ZAvzJ27JJX",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1814216837342671173",
            "createdAt" : "2024-07-19T08:32:55.246Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Sii, lo he compartido",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1806336267065672168",
            "createdAt" : "2024-06-27T14:38:20.858Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/ErPdycS5Re",
                "expanded" : "https://twitter.com/CPoliticaUB/status/1806001491427148070",
                "display" : "twitter.com/CPoliticaUB/st…"
              }
            ],
            "text" : "https://t.co/ErPdycS5Re",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1806336169413853419",
            "createdAt" : "2024-06-27T14:37:57.593Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Deja a Marisa tranquila que ya tiene bastante...😜",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1805972022763364817",
            "createdAt" : "2024-06-26T14:30:58.253Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "La Montse 🤣",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1805971889157820883",
            "createdAt" : "2024-06-26T14:30:26.399Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Eso se lo dices a los de recerca y te lo arreglan en un momento",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1805971743107842231",
            "createdAt" : "2024-06-26T14:29:51.577Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Dile a tu jefe que nos compre un par 😀",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1805971486374572263",
            "createdAt" : "2024-06-26T14:28:50.375Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/sSozr61eJ7",
                "expanded" : "https://twitter.com/Etched/status/1805625693113663834",
                "display" : "twitter.com/Etched/status/…"
              }
            ],
            "text" : "https://t.co/sSozr61eJ7",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1805966748551962943",
            "createdAt" : "2024-06-26T14:10:00.801Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Wow, pinta de puta madre. Muchas gracias!",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1805138217299026381",
            "createdAt" : "2024-06-24T07:17:43.536Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/wq8BNnc9zZ",
                "expanded" : "https://twitter.com/ZainHasan6/status/1804365076889018519",
                "display" : "twitter.com/ZainHasan6/sta…"
              }
            ],
            "text" : "https://t.co/wq8BNnc9zZ",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1805094700258656523",
            "createdAt" : "2024-06-24T04:24:48.280Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/4DvQPufjXe",
                "expanded" : "https://twitter.com/XimGutierrez/status/1779967968236949926",
                "display" : "twitter.com/XimGutierrez/s…"
              }
            ],
            "text" : "https://t.co/4DvQPufjXe",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1781351143626399753",
            "createdAt" : "2024-04-19T15:56:23.263Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/4DvQPufjXe",
                "expanded" : "https://twitter.com/XimGutierrez/status/1779967968236949926",
                "display" : "twitter.com/XimGutierrez/s…"
              }
            ],
            "text" : "https://t.co/4DvQPufjXe",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1781351103625388529",
            "createdAt" : "2024-04-19T15:56:13.733Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [
              {
                "senderId" : "171421468",
                "reactionKey" : "surprised",
                "eventId" : "1776238470358306817",
                "createdAt" : "2024-04-05T13:20:26.918Z"
              }
            ],
            "urls" : [
              {
                "url" : "https://t.co/DJ9lGNUYm6",
                "expanded" : "https://twitter.com/auroraonx/status/1775900864886223258",
                "display" : "twitter.com/auroraonx/stat…"
              }
            ],
            "text" : "https://t.co/DJ9lGNUYm6",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1776238275453194578",
            "createdAt" : "2024-04-05T13:19:40.493Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/iGUtSdOmi7",
                "expanded" : "https://twitter.com/omarsar0/status/1749456036111568901",
                "display" : "twitter.com/omarsar0/statu…"
              }
            ],
            "text" : "https://t.co/iGUtSdOmi7",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1749828196286046532",
            "createdAt" : "2024-01-23T16:15:26.940Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [
              {
                "senderId" : "171421468",
                "reactionKey" : "agree",
                "eventId" : "1696892493596442624",
                "createdAt" : "2023-08-30T14:27:51.889Z"
              }
            ],
            "urls" : [ ],
            "text" : "Sii, lo escribió mi co-host en Oslo y mañana me discute el paper el otro autor del articulo. Gracias por pasarlo!",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1696892237802537297",
            "createdAt" : "2023-08-30T14:26:50.930Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/TXMUP8LARp",
                "expanded" : "https://www.cambridge.org/core/journals/american-political-science-review/article/shadow-effect-of-courts-judicial-review-and-the-politics-of-preemptive-reform/8200C801ACCC37057FC153B394C87015",
                "display" : "cambridge.org/core/journals/…"
              }
            ],
            "text" : "https://t.co/TXMUP8LARp",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1696891624310104350",
            "createdAt" : "2023-08-30T14:24:24.726Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/dFyBmHkAtQ",
                "expanded" : "https://twitter.com/teshsidi/status/1679467682071040001",
                "display" : "twitter.com/teshsidi/statu…"
              }
            ],
            "text" : "Firma por las enmiendas! https://t.co/dFyBmHkAtQ",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1679732091607449604",
            "createdAt" : "2023-07-14T05:58:33.259Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/mIa8ocsH60",
                "expanded" : "https://twitter.com/pj_castillo_/status/1653643560632164354",
                "display" : "twitter.com/pj_castillo_/s…"
              }
            ],
            "text" : "https://t.co/mIa8ocsH60",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1654002444324552708",
            "createdAt" : "2023-05-04T05:58:07.311Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "La putada es que ahora se queda colgao cada dos por tress, pero para aprender Python es la hostia✌️✌️",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1624692775844290566",
            "createdAt" : "2023-02-12T08:51:57.784Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/KNc81kqSWB",
                "expanded" : "https://twitter.com/svpino/status/1624392828154712064",
                "display" : "twitter.com/svpino/status/…"
              }
            ],
            "text" : "https://t.co/KNc81kqSWB",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1624666759721631751",
            "createdAt" : "2023-02-12T07:08:35.071Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Uff, me viene de lujo. No tenía plan para este finde😜😜",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1624135065646112772",
            "createdAt" : "2023-02-10T19:55:49.305Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/UBkKgqSskZ",
                "expanded" : "https://twitter.com/StatModeling/status/1621118045690253313",
                "display" : "twitter.com/StatModeling/s…"
              }
            ],
            "text" : "Si os habéis quedado con ganas... https://t.co/UBkKgqSskZ",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1621422365262417924",
            "createdAt" : "2023-02-03T08:16:31.152Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "171421468",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hostia, lo veré en diferido que aquí no tengo internet. Gracias, Camilo! El martes nos vemos de nuevo",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1601086294112624646",
            "createdAt" : "2022-12-09T05:28:13.944Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/6Y9QZfxcdA",
                "expanded" : "https://twitter.com/SomosNLP_/status/1600912882123694080",
                "display" : "twitter.com/SomosNLP_/stat…"
              }
            ],
            "text" : "https://t.co/6Y9QZfxcdA",
            "mediaUrls" : [ ],
            "senderId" : "171421468",
            "id" : "1600918170256265221",
            "createdAt" : "2022-12-08T18:20:10.112Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "246751440-1312048977538437120",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/Nnk2WWSMWu",
                "expanded" : "https://mcyt.educa.madrid.org/empleo/ofertas-destacadas/",
                "display" : "mcyt.educa.madrid.org/empleo/ofertas…"
              },
              {
                "url" : "https://t.co/fldOWtLWag",
                "expanded" : "http://www.facebook.com/pages/Empleo-madrid-IDi/188213711199483",
                "display" : "facebook.com/pages/Empleo-m…"
              },
              {
                "url" : "https://t.co/ZE1Etfv3kD",
                "expanded" : "http://www.linkedin.com/groups?home=&gid=4843254&trk=anet_ug_hm",
                "display" : "linkedin.com/groups?home=&g…"
              }
            ],
            "text" : "Gracias por seguirmos! Conózca todas las ofertas de I+D+i visitando nuestra web: https://t.co/Nnk2WWSMWu\nTambién puedes seguirnos en nuestras redes sociales:\nFacebook: \nhttps://t.co/fldOWtLWag\ny\nLinkedin: \nhttps://t.co/ZE1Etfv3kD",
            "mediaUrls" : [ ],
            "senderId" : "246751440",
            "id" : "1605212424294080519",
            "createdAt" : "2022-12-20T14:44:00.089Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "952639101320253440-1312048977538437120",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "952639101320253440",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/bJvk5XTI8V",
                "expanded" : "https://twitter.com/mborrellporta/status/1837167696649314508",
                "display" : "twitter.com/mborrellporta/…"
              },
              {
                "url" : "https://t.co/bJvk5XTI8V",
                "expanded" : "https://twitter.com/mborrellporta/status/1837167696649314508",
                "display" : "twitter.com/mborrellporta/…"
              }
            ],
            "text" : "https://t.co/bJvk5XTI8V https://t.co/bJvk5XTI8V",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1838622575661830351",
            "createdAt" : "2024-09-24T16:52:36.709Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1167736846010503169-1312048977538437120",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/gpmMwskaLu",
                "expanded" : "https://twitter.com/UniBarcelona/status/1773259193249669197",
                "display" : "twitter.com/UniBarcelona/s…"
              }
            ],
            "text" : "https://t.co/gpmMwskaLu",
            "mediaUrls" : [ ],
            "senderId" : "1167736846010503169",
            "id" : "1775119951155601612",
            "createdAt" : "2024-04-02T11:15:51.195Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/SV5BBPX4iH",
                "expanded" : "https://twitter.com/chriswratil/status/1757706961712300289",
                "display" : "twitter.com/chriswratil/st…"
              }
            ],
            "text" : "https://t.co/SV5BBPX4iH",
            "mediaUrls" : [ ],
            "senderId" : "1167736846010503169",
            "id" : "1757717158056931839",
            "createdAt" : "2024-02-14T10:43:21.994Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048977538437120",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/OtKncwgLVX",
                "expanded" : "https://twitter.com/DanBischof/status/1755880129245429993",
                "display" : "twitter.com/DanBischof/sta…"
              }
            ],
            "text" : "https://t.co/OtKncwgLVX",
            "mediaUrls" : [ ],
            "senderId" : "1167736846010503169",
            "id" : "1755886096297185500",
            "createdAt" : "2024-02-09T09:27:22.854Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1312048977538437120-1504893143325589512",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1504893143325589512",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Mucha suerte!!🤞🤞🤞🤞",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1838133106001211470",
            "createdAt" : "2024-09-23T08:27:38.024Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1504893143325589512",
            "reactions" : [
              {
                "senderId" : "1504893143325589512",
                "reactionKey" : "like",
                "eventId" : "1838128232086020096",
                "createdAt" : "2024-09-23T08:08:15.972Z"
              }
            ],
            "urls" : [
              {
                "url" : "https://t.co/bJvk5XTI8V",
                "expanded" : "https://twitter.com/mborrellporta/status/1837167696649314508",
                "display" : "twitter.com/mborrellporta/…"
              }
            ],
            "text" : "https://t.co/bJvk5XTI8V",
            "mediaUrls" : [ ],
            "senderId" : "1312048977538437120",
            "id" : "1837756351075807696",
            "createdAt" : "2024-09-22T07:30:32.671Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  }
]