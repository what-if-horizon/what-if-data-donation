window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "oQQHR0GSNdRFHahiuNN2kKIbdMQZN0BM7eqJHBlI",
      "createdAt" : "2023-10-26T09:41:09.754Z",
      "lastSeenAt" : "2023-10-26T09:41:09.756Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "EMAvJ9wYBkbB7bbcKu4HZjLLiDW02nSeNzxGN1K3",
      "createdAt" : "2024-05-06T10:10:16.610Z",
      "lastSeenAt" : "2024-05-06T10:10:16.611Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "t0qlmM2LPOCJWPGTvBxtQrD53tfna3qRPCZwxuz5",
      "createdAt" : "2024-10-24T14:24:56.332Z",
      "lastSeenAt" : "2024-10-24T14:34:28.468Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "258901",
      "token" : "Jx11s6pOFeU7PMYQvFMVHl4M3KClohxqsSy4k1my",
      "createdAt" : "2024-10-24T15:27:38.392Z",
      "lastSeenAt" : "2024-10-24T15:27:38.395Z",
      "clientApplicationName" : "Twitter for Android (Twitter, Inc.)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "2Ym2riNWXCZ9BgarhSQyh48FSBnWqbo4pPKnPZmG",
      "createdAt" : "2025-02-09T20:13:39.983Z",
      "lastSeenAt" : "2025-02-09T20:13:39.985Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "RLvlq4sZ7wO4Rwr4kxNZpTghCLywVGsAZ1OqWGGd",
      "createdAt" : "2024-10-24T14:19:05.792Z",
      "lastSeenAt" : "2025-02-20T12:32:21.265Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  }
]