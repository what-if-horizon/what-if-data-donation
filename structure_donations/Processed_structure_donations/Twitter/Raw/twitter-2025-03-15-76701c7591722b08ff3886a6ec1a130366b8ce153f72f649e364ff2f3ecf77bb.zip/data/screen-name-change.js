window.YTD.screen_name_change.part0 = [
  {
    "screenNameChange" : {
      "accountId" : "1312048977538437120",
      "screenNameChange" : {
        "changedAt" : "2021-09-15T14:46:35.000Z",
        "changedFrom" : "aroaro17405870",
        "changedTo" : "PSUBRodilla"
      }
    }
  }
]