window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1892573988901077387",
      "fullText" : "Great work showing solid evidence about how ideological polarization has become a defining feature of judges' behaviour on the Spanish Constitutional Tribunal. https://t.co/QQ6Ng2yY6T",
      "expandedUrl" : "https://twitter.com/i/web/status/1892573988901077387"
    }
  },
  {
    "like" : {
      "tweetId" : "1878760297638645949",
      "fullText" : "📢 First seminar of the year! @pauvallprat will present \"The Democratic Consequences of Female Political Empowerment under Autocracies\" co-autored with @albahuidobro \n\n🕐13:00\n\n📍Sala de Juntes \n\nJoin us!",
      "expandedUrl" : "https://twitter.com/i/web/status/1878760297638645949"
    }
  },
  {
    "like" : {
      "tweetId" : "1867221377520185509",
      "fullText" : "About to fly back from the UK when I was informed I am a recipient of the Icrea Acadèmia, a “research intensification grant to outstanding university professors” https://t.co/mmNcpVAywu @PolitiquesUPF @UPFBarcelona \n\n🎊Incredibly happy😄 https://t.co/ozXP1AuZKG",
      "expandedUrl" : "https://twitter.com/i/web/status/1867221377520185509"
    }
  },
  {
    "like" : {
      "tweetId" : "1858807647832596605",
      "fullText" : "🎉 Excited to share that our paper (w/ @AlbertoBueno_) proposing a model for empirically measuring the political culture of defence is now published in European Politics and Society @epsj_, Vol. 25, Issue 5! Check it out! 📖\n\nFree prints here\nhttps://t.co/Ni20n5JuPJ https://t.co/NkrX5V5oTO",
      "expandedUrl" : "https://twitter.com/i/web/status/1858807647832596605"
    }
  },
  {
    "like" : {
      "tweetId" : "1858611209135694326",
      "fullText" : "O abaixeu els lloguers, o ho farem nosaltres. Avui, la @carmearcarazo al Congrés dels Diputats. https://t.co/C2TdcnvWmZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1858611209135694326"
    }
  },
  {
    "like" : {
      "tweetId" : "1857327072273641871",
      "fullText" : "🦺BRIGADES LLOGATERES🦺\n\n⚠️ La propera:\ndissabte 16/11 a les 11h\nal C. Villarroel, 10 (BCN) https://t.co/v4TJfU2FpE",
      "expandedUrl" : "https://twitter.com/i/web/status/1857327072273641871"
    }
  },
  {
    "like" : {
      "tweetId" : "1857105409363857872",
      "fullText" : "📢 El pròxim #23N omplirem els carrers de Barcelona i, per això, el moviment per l'habitatge ha organitzat busos d'anada i tornada a la manifestació des d'El Vendrell, Lleida, Reus i Tarragona! 🚌\n\nFORMULARIS D'INSCRIPCIÓ 🖋️https://t.co/eGMYusgvJ4 https://t.co/zWiBBojjPF",
      "expandedUrl" : "https://twitter.com/i/web/status/1857105409363857872"
    }
  },
  {
    "like" : {
      "tweetId" : "1857095371169636719",
      "fullText" : "Excited to see this out in @JSP_journal! Research shows that key supporters of UBI arelow-income, high-risk, or unemployed—but do they prefer a UBI over other altervatives? Spoiler: no! A key takeaway: it's crucial to distinguish between support levels and actual preferences. https://t.co/OELBQQgU9d",
      "expandedUrl" : "https://twitter.com/i/web/status/1857095371169636719"
    }
  },
  {
    "like" : {
      "tweetId" : "1857078031807873306",
      "fullText" : "How partisan preferences and strategic behaviour related to the composition of the court  explain the constitutional challenges of regional laws. With @PSUBRodilla: A game of tug-of-war: regional laws before the Spanish Constitutional Court @RSA_TPG  https://t.co/x2Me0sQtbb",
      "expandedUrl" : "https://twitter.com/i/web/status/1857078031807873306"
    }
  },
  {
    "like" : {
      "tweetId" : "1856597436979888411",
      "fullText" : "Per què sortim als carrers el #23N? 🙋 https://t.co/93IA7BhrhR",
      "expandedUrl" : "https://twitter.com/i/web/status/1856597436979888411"
    }
  },
  {
    "like" : {
      "tweetId" : "1854214997787939243",
      "fullText" : "Casi la mitad del dinero desaparece al instante en su mismísima cara, que ni el mejor truco del mago Pop.\n#23N💖🔥🔑🐎🏡💰 https://t.co/HwB1bEqupq",
      "expandedUrl" : "https://twitter.com/i/web/status/1854214997787939243"
    }
  },
  {
    "like" : {
      "tweetId" : "1853819729057615989",
      "fullText" : "So glad to hang out with @ablais_ in Barcelona. It has been a luxury to host one of the best mentors and election experts. Come back soon! https://t.co/L5ZyfPPpAQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1853819729057615989"
    }
  },
  {
    "like" : {
      "tweetId" : "1853761478479798631",
      "fullText" : "I had an amazing time delivering lectures on the theory and measurement of political polarization at the Barcelona edition of the Summer Institute in Computational Social Science #SICSS @CPoliticaUB. What a fantastic experience!\n\nThanks @cacristan for the organization! https://t.co/Q80Jm0rOvs",
      "expandedUrl" : "https://twitter.com/i/web/status/1853761478479798631"
    }
  },
  {
    "like" : {
      "tweetId" : "1853706345859465604",
      "fullText" : "Very happy to see this article with @VanDitmars published in @WEPsocial 🤩\nhttps://t.co/NB2fU5T8js\n👇Mathilde's great summary of our main findings https://t.co/85TYZfW3TM",
      "expandedUrl" : "https://twitter.com/i/web/status/1853706345859465604"
    }
  },
  {
    "like" : {
      "tweetId" : "1853373466889642110",
      "fullText" : "Valencia se llena de mierda  https://t.co/FnNFmFQVlm https://t.co/mq5hVWzcz1",
      "expandedUrl" : "https://twitter.com/i/web/status/1853373466889642110"
    }
  },
  {
    "like" : {
      "tweetId" : "1853086619374399620",
      "fullText" : "Online first &amp; part of the Symposium: Generations and Political Change: \"A life course approach to political preference formation across social classes\" by @macarena_ares &amp; @VanDitmars \n\nhttps://t.co/EAL7O0yP5i\n\n@Rout_PoliticsIR https://t.co/Q8hQykpPpL",
      "expandedUrl" : "https://twitter.com/i/web/status/1853086619374399620"
    }
  },
  {
    "like" : {
      "tweetId" : "1853020508280815631",
      "fullText" : "Valencia como parque de atracciones de la ultraderecha.\n\nEstos días en las calles de Valencia hay miles de personas arrimando el hombro. La inmensa mayoría, vecinos, lo hacen con el corazón encogido y con la única intención de echar una mano. Mientras tanto, una excursión de…",
      "expandedUrl" : "https://twitter.com/i/web/status/1853020508280815631"
    }
  },
  {
    "like" : {
      "tweetId" : "1851905720322515446",
      "fullText" : "La Dra. Rosa Ana Alija, professora de Dret Internacional Públic de la Facultat, distingida amb la medalla d’honor de la Generalitat per serveis excepcionals a la Justícia en reconeixement a la seva aposta pels drets humans i la justícia internacional https://t.co/uBeEHcGeeJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1851905720322515446"
    }
  },
  {
    "like" : {
      "tweetId" : "1849479886735335928",
      "fullText" : "Our article with @Andre_Bianculli in @scmrjems on regional responses to a transboundary reception crisis  in South America is now Open Access 🎉 https://t.co/CIgVyKwRYP",
      "expandedUrl" : "https://twitter.com/i/web/status/1849479886735335928"
    }
  },
  {
    "like" : {
      "tweetId" : "1846869047092101454",
      "fullText" : "Donem la benvinguda a @Xavier_Arbos  com a nou director de l'@autogoverncat . Catedràtic de Dret Constitucional a la UB, amb una àmplia trajectòria acadèmica i professional. Expert en dret comparat i organització territorial. Amb ell, comencem una nova etapa plena de reptes.",
      "expandedUrl" : "https://twitter.com/i/web/status/1846869047092101454"
    }
  },
  {
    "like" : {
      "tweetId" : "1846591852880752953",
      "fullText" : "Cada vegada paguem més de lloguer i hi ha més propietats en més poques mans.\n\nSi no s'abaixen els lloguers, deixarem de pagar-los.\n\nEl #23N, tothom al carrer! 🔑 https://t.co/X0fblYCu15",
      "expandedUrl" : "https://twitter.com/i/web/status/1846591852880752953"
    }
  },
  {
    "like" : {
      "tweetId" : "1846625438833299467",
      "fullText" : "La ministra d'Habitatge ens ha enviat una carta.\nLi hem fet unes petites correccions. ✉️🤡 https://t.co/wCxVz8a5MJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1846625438833299467"
    }
  },
  {
    "like" : {
      "tweetId" : "1843646277159891044",
      "fullText" : "📢New open-access article alert📢\nSquatrito &amp; @t_sommerer explore the variance in the openness of informal intergovernmental organizations to transnational actors (TNAs) and assess the conditions under which TNA access is more likely\nhttps://t.co/hBhnSKmPfp #RegGov @WileyPolitics",
      "expandedUrl" : "https://twitter.com/i/web/status/1843646277159891044"
    }
  },
  {
    "like" : {
      "tweetId" : "1838831282173690039",
      "fullText" : "El 13 de octubre tomamos las calles y ahí empezará todo. Esto no puede ser una manifestación más y, para eso, tenemos que hacerla posible entre todas.\n\nVente este sábado 28 por la tarde a la Plaza Peñuelas y vamos a construir esta mani desde cada barrio, calle y bloque ❤️‍🔥 https://t.co/sLfIM8BJCN",
      "expandedUrl" : "https://twitter.com/i/web/status/1838831282173690039"
    }
  },
  {
    "like" : {
      "tweetId" : "1837074010007326961",
      "fullText" : "😢Si una inquilina deja de pagar, el problema lo tiene ella\n\n🔥Si diez mil inquilinas se organizan para no pagar, el problema lo tienen sus caseros\n\n💡En eso consiste una #HuelgaDeAlquileres, una herramienta que necesitamos recuperar\n\n🎞 Aquí te resuelven muchas dudas al respecto https://t.co/Xu0dX60LT3",
      "expandedUrl" : "https://twitter.com/i/web/status/1837074010007326961"
    }
  },
  {
    "like" : {
      "tweetId" : "1836343533449421230",
      "fullText" : "Ahir Junts va votar a favor de seguir defraudant a les  llogateres i de saltar-se els pocs drets que hem conquerit. \n\nNo és normal que et puguin cobrar 1.000€ per una  habitació, despeses de l'immobiliària i fer-te fora al cap  d'uns mesos. \n\n💥Plantem-los cara! https://t.co/i6iopDykOa",
      "expandedUrl" : "https://twitter.com/i/web/status/1836343533449421230"
    }
  },
  {
    "like" : {
      "tweetId" : "1836319835518566434",
      "fullText" : "🔴 El @SindicatLloguer convoca una concentració de protesta a la seu de @JuntsXCat \n\n🔶 El portaveu de l'organització, @AJEnric, els acusa de mentir quan diuen que no han pogut negociar\nhttps://t.co/mlSSYFrs5i\nhttps://t.co/mlSSYFrs5i",
      "expandedUrl" : "https://twitter.com/i/web/status/1836319835518566434"
    }
  },
  {
    "like" : {
      "tweetId" : "1835713517384585587",
      "fullText" : "El #27S ens sumem a la vaga general i a les mobilitzacions en solidaritat amb el poble palestí. \n\nContra la complicitat de governs, institucions i empreses amb l'ens sionista, plantem cara!\n\n#VagaPerPalest1na lliure des del riu fins al mar!\n#SomInt1fada27S https://t.co/5DHB0DLYCX",
      "expandedUrl" : "https://twitter.com/i/web/status/1835713517384585587"
    }
  },
  {
    "like" : {
      "tweetId" : "1834193653763289261",
      "fullText" : "🎉🎉 Excited to announce that our paper \"Too Crooked to be Good? Trade-offs in the Electoral Punishment of Malfeasance and Corruption,\" co-authored with @EHernandezPe, is now published in @EPSRjournal! 📚  (1/6) https://t.co/BC9UEBUEJk \n@IBEI @PolitiquesUAB",
      "expandedUrl" : "https://twitter.com/i/web/status/1834193653763289261"
    }
  },
  {
    "like" : {
      "tweetId" : "1834496133906796895",
      "fullText" : "🚨 New paper exploring the trade-offs citizens face when deciding to punish corruption in elections https://t.co/JvOMV7iIwd",
      "expandedUrl" : "https://twitter.com/i/web/status/1834496133906796895"
    }
  },
  {
    "like" : {
      "tweetId" : "1834573639556997464",
      "fullText" : "Molt contenta d'haver participat a aquestes trobades sobre IA organitzades per @EEdHumanitats amb una xerrada sobre l'impacte de les xarxes socials en les decisions polítiques. Vídeo de totes les sessions a l'enllaç de més avall 👇🏽 https://t.co/nBRFtSYLok",
      "expandedUrl" : "https://twitter.com/i/web/status/1834573639556997464"
    }
  },
  {
    "like" : {
      "tweetId" : "1834176896990429202",
      "fullText" : "Very happy to be starting my new job @IEuniversity.\n\nAmong other things, very excited with the prospect of working with this view from my office! https://t.co/tKeb57hgrS",
      "expandedUrl" : "https://twitter.com/i/web/status/1834176896990429202"
    }
  },
  {
    "like" : {
      "tweetId" : "1833450150661955790",
      "fullText" : "📣Job Alert🚨 I am hiring a PhD to join a research project on ONLINEHATE at @CPoliticaUB funded by @AgEInves  . \nIt's a 4-year position. \nDeadline: September 27 at 14.00h. \nFind all info in the link below. \nPlease, get in touch if you have any questions! https://t.co/IIXPU1v6MB",
      "expandedUrl" : "https://twitter.com/i/web/status/1833450150661955790"
    }
  },
  {
    "like" : {
      "tweetId" : "1831753457210159442",
      "fullText" : "🚨Interested in doing a PhD in PoliSci? Interested in Historical Political Economy? Interested in democratization/political behavior?\n\nConsider applying for this 4-year fully-funded PhD Fellowship at @PolitiquesUPF, led by @tonirodon.\n\nApply https://t.co/QNmpHLUve2 (by Sept20)",
      "expandedUrl" : "https://twitter.com/i/web/status/1831753457210159442"
    }
  },
  {
    "like" : {
      "tweetId" : "1830612587857514793",
      "fullText" : "🚨 My book is out today: https://t.co/SIfrKnfPIY 🚨\n\n2024 has been full of elections. In many, radical-right politicians made important electoral gains.\n\nMy book hopes to contribute to debates on the rise of these politicians by putting forward a theory around social norms.\n\n1/23 https://t.co/i6URlXPC1Y",
      "expandedUrl" : "https://twitter.com/i/web/status/1830612587857514793"
    }
  },
  {
    "like" : {
      "tweetId" : "1830929255510725063",
      "fullText" : "M’assabento pels mitjans que avui el govern ha acordat el meu cessament com a director del @ceopinio. Me’n vaig raonablement satisfet de la feina feta, i content de tornar al meu lloc natural que és la @uniBarcelona a fer el que més m’agrada.",
      "expandedUrl" : "https://twitter.com/i/web/status/1830929255510725063"
    }
  },
  {
    "like" : {
      "tweetId" : "1829941828503621848",
      "fullText" : "#NuevaFotoDePerfil https://t.co/NxII0KFW1f",
      "expandedUrl" : "https://twitter.com/i/web/status/1829941828503621848"
    }
  },
  {
    "like" : {
      "tweetId" : "1829157496323289291",
      "fullText" : "From our new issue: \"Instrumentally Inclusive: The Political Psychology of Homonationalism\" by Stuart Turnbull-Dugarte and Alberto López Ortega. #ASPRNewIssue\n\nhttps://t.co/NNEHsN1Tli https://t.co/DU6qLDGM6D",
      "expandedUrl" : "https://twitter.com/i/web/status/1829157496323289291"
    }
  },
  {
    "like" : {
      "tweetId" : "1828070513291186404",
      "fullText" : "From our new issue: \"Bureaucratic Quality and the Gap between Implementation Burden and Administrative Capacities\" by Xavier Fernández-I-Marín, Christoph Knill (@christoph_knill), Christina Steinbacher (@Ch_Steinbacher), and Yves Steinebach #ASPRNewIssue.\n\nhttps://t.co/QCQ2y574OW https://t.co/8D0z2wkbHe",
      "expandedUrl" : "https://twitter.com/i/web/status/1828070513291186404"
    }
  },
  {
    "like" : {
      "tweetId" : "1826177385131118852",
      "fullText" : "Mientras la Fiscalía siga considerando víctimas de delitos de odio a los nazis, a Israel, a la extrema derecha y a las fuerzas y cuerpos de seguridad del Estado, cada refuerzo de esta ley será un arma de doble filo que se aplicará casi siempre a los de siempre. Primero, corrijan https://t.co/31BLdxx0KP",
      "expandedUrl" : "https://twitter.com/i/web/status/1826177385131118852"
    }
  },
  {
    "like" : {
      "tweetId" : "1823681903720894563",
      "fullText" : "Don't forget to join the #ecprgc24 business meeting today at 18:15! https://t.co/gvbdGXLnVu",
      "expandedUrl" : "https://twitter.com/i/web/status/1823681903720894563"
    }
  },
  {
    "like" : {
      "tweetId" : "1822591442683892172",
      "fullText" : "Looking forward to our section on the \"Politics of Law and Courts\" at #ecprgc24! https://t.co/6Jifkm5qPx",
      "expandedUrl" : "https://twitter.com/i/web/status/1822591442683892172"
    }
  },
  {
    "like" : {
      "tweetId" : "1822578609577484333",
      "fullText" : "At 9:00 on Monday we also have the excellent panel on \"Strategic actors in the legal field\" organized by @louisaboulaziz  and with @benjaminengst  as the discussant!  Paper presentations by @VMakszimov, Pablo Pizarro Zúñiga, and @pocza_kalman! https://t.co/wym00yhiTZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1822578609577484333"
    }
  },
  {
    "like" : {
      "tweetId" : "1822656891920539826",
      "fullText" : "Arrived in Dublin and ready to present at the first panel of the Law and Courts section at ECPR @ecpr_law_courts ! Looking forward to an incredible week of learning and collaborating with exceptional colleagues. See you all soon! https://t.co/rxHYag9cH4",
      "expandedUrl" : "https://twitter.com/i/web/status/1822656891920539826"
    }
  },
  {
    "like" : {
      "tweetId" : "1820841265564459222",
      "fullText" : "New publication🚨\n\nCan we use NLP to recognize complex legal arguments?\n\n@BentStohlmann and I just published a new paper in AI &amp; Law on the identification of proportionality in the case law of the German Federal Constitutional Court. (1/5)\n\nhttps://t.co/V6CfxpMRZH",
      "expandedUrl" : "https://twitter.com/i/web/status/1820841265564459222"
    }
  },
  {
    "like" : {
      "tweetId" : "1819029200637936084",
      "fullText" : "The input by @MarianaLlanosHa and me for the report of the UN Special Rapporteur on the independence of judges and lawyers has been published! https://t.co/YJOjgQpITp",
      "expandedUrl" : "https://twitter.com/i/web/status/1819029200637936084"
    }
  },
  {
    "like" : {
      "tweetId" : "1819041716826931484",
      "fullText" : "I am very happy that my article \"Latin American Courts Going Public: A Comparative Assessment\" has been published by Revista de Ciencia Política! It´s open access: https://t.co/J9H0ZQn5h7",
      "expandedUrl" : "https://twitter.com/i/web/status/1819041716826931484"
    }
  },
  {
    "like" : {
      "tweetId" : "1817956661539320020",
      "fullText" : "🏅 Premio a la mejor ponencia del #XVICongresoAECPA por \"Looking the other way? Selective information exposure and the electoral punishment of corruption\"\n\nEnhorabuena a @macarena_ares (@UniBarcelona), @sofiabrei (IBEI) y @EHernandezPe (@dec_gr-@UABBarcelona) 👏👏 https://t.co/h27bQEiCkH",
      "expandedUrl" : "https://twitter.com/i/web/status/1817956661539320020"
    }
  },
  {
    "like" : {
      "tweetId" : "1816504617817215140",
      "fullText" : "My paper got rejected from the APSR, but it was the single best review experience I have had. Reject and resubmit a day after first submission, with substantive comments from the editors. Then, received reviews one month after the resubmission. Kudos to the new editorial team!",
      "expandedUrl" : "https://twitter.com/i/web/status/1816504617817215140"
    }
  },
  {
    "like" : {
      "tweetId" : "1816502138501288167",
      "fullText" : "Muy satisfecho de haber podido presentar mi trabajo y aprender de muchos otros en #AECPA2024 en Burgos. Un agradecimiento especial a @macarena_ares y @bertous por organizar el magnífico panel \"Valores y comportamiento político: explorando influencias, orígenes y consecuencias\" https://t.co/lsmvNNuOfN",
      "expandedUrl" : "https://twitter.com/i/web/status/1816502138501288167"
    }
  },
  {
    "like" : {
      "tweetId" : "1618001716963868675",
      "fullText" : "So thrilled to see this article finally published: Courts and the Judicial Erosion of Democracy in Latin America https://t.co/qi4si5riMG #Judiciary #Democracy #LATAM https://t.co/JxH0dqisin",
      "expandedUrl" : "https://twitter.com/i/web/status/1618001716963868675"
    }
  },
  {
    "like" : {
      "tweetId" : "1617838713886879750",
      "fullText" : "Els seminaris de recerca de @CPoliticaUB https://t.co/Vpi0O7SUDs",
      "expandedUrl" : "https://twitter.com/i/web/status/1617838713886879750"
    }
  },
  {
    "like" : {
      "tweetId" : "1617835859017105408",
      "fullText" : "📯📯Announcing our great line-up of speakers for this semester's @CPoliticaUB Research Seminar! Full program below 👇🏽 https://t.co/LkQFmxuA3b",
      "expandedUrl" : "https://twitter.com/i/web/status/1617835859017105408"
    }
  },
  {
    "like" : {
      "tweetId" : "1617837166276808705",
      "fullText" : "The @CPoliticaUB has an amazing lineup prepared for the Spring semester's Research Seminar! https://t.co/uKNiocU4eo",
      "expandedUrl" : "https://twitter.com/i/web/status/1617837166276808705"
    }
  },
  {
    "like" : {
      "tweetId" : "1617495270413017088",
      "fullText" : "El Pla Pilot per Implementar la Renda Bàsica Universal planteja un model mixte per a mesurar els hipotètics efectes causals: un RCT (efectes individuals) i un control sintètic (efectes agregats).\n\n✅ Data-driven policy making https://t.co/eSE5hVxYO2",
      "expandedUrl" : "https://twitter.com/i/web/status/1617495270413017088"
    }
  },
  {
    "like" : {
      "tweetId" : "1613829383088652290",
      "fullText" : "📢Next Thursday our departmental seminar reconvenes for the first session of the year\n@palau_anna will be presenting joint work with @PSUBRodilla &amp; @CasAndreu: “Do multilevel politics influence the amending activity of legislators?”\n📅Thursday 19/01/2023, 14:30\n📌A-218 @Dret_UB https://t.co/1BiLkkQVA1",
      "expandedUrl" : "https://twitter.com/i/web/status/1613829383088652290"
    }
  },
  {
    "like" : {
      "tweetId" : "1612915724111978535",
      "fullText" : "Yo ya sé que a la propaganda le da igual la verdad, pero para vuestras discusiones sobre si lo de Brasil es igual que el \"rodea el Congreso\" del 15-M , algunas cosas para que no jueguen con vuestra memoria.",
      "expandedUrl" : "https://twitter.com/i/web/status/1612915724111978535"
    }
  },
  {
    "like" : {
      "tweetId" : "1610553443206193152",
      "fullText" : "A collection of #data resources related to #EuropeanIntegration initiated by @michal_ovadek.\n\nPlease share and contribute!\n\nhttps://t.co/Z5xO0S6IL8",
      "expandedUrl" : "https://twitter.com/i/web/status/1610553443206193152"
    }
  },
  {
    "like" : {
      "tweetId" : "1610016550378999814",
      "fullText" : "Però algú amb 2 dits de front creu que la gent que vivim a altres països tenim un sentiment d’identitat homogeni i lineal? Al principi tot es nou, després vols ser com la gent d’on vius i després et fa por perdre l’identitat i tornes a les arrels i després t’importa tot una polla",
      "expandedUrl" : "https://twitter.com/i/web/status/1610016550378999814"
    }
  },
  {
    "like" : {
      "tweetId" : "1604931089851568129",
      "fullText" : "Tras una larga etapa de mucho trabajo y grandes aprendizajes, hoy defendí con éxito mi tesis doctoral. Un proyecto que no hubiera sido posible sin el respaldo de mi directora, la Dra. @laurachaques, la @UniBarcelona y la @udg_oficial. https://t.co/GRYzFfjpYE",
      "expandedUrl" : "https://twitter.com/i/web/status/1604931089851568129"
    }
  },
  {
    "like" : {
      "tweetId" : "1603828628151668736",
      "fullText" : "@BicchiNicolas gave a very exciting presentation today at the VII PhD Workshop on Empirical Political Science at @CPoliticaUB. The seventh edition of the inter-university workshop was successfully concluded. See everyone in six months at @cpa_uab. https://t.co/cQ6RKyqYQ2",
      "expandedUrl" : "https://twitter.com/i/web/status/1603828628151668736"
    }
  },
  {
    "like" : {
      "tweetId" : "1603832805334581251",
      "fullText" : "Today we hosted the VII Workshop on Empirical Political Science at @CPoliticaUB. It's thrilling to meet with such a brilliant group of young researchers\n\nFor me, double excitement as I got to present my last paper. Thank you @LalaHMur and @bernat_puertas for the great comments! https://t.co/3UX1866Zmr",
      "expandedUrl" : "https://twitter.com/i/web/status/1603832805334581251"
    }
  },
  {
    "like" : {
      "tweetId" : "1602655276112515074",
      "fullText" : "📢Arriba el VII PhD Workshop on Empirical Political Science! Organitzat amb la @UniBarcelona i @UABBarcelona, el nostre doctorand @BicchiNicolas presentarà la seva recerca, i també hi participen @LalaHMur i @bernat_puertas\n\n🗓️ 16/12, a les 9:00h\nMés info👉 https://t.co/jY7Z7fOWTS https://t.co/6V0LrrZXAz",
      "expandedUrl" : "https://twitter.com/i/web/status/1602655276112515074"
    }
  },
  {
    "like" : {
      "tweetId" : "1602699073714364417",
      "fullText" : "This Friday December 16th, 4 PhD researchers from @cpa_uab @PolitiquesUPF @CPoliticaUB will present their research at the VII Barcelona PhD workshop👩‍🎓🧑‍🎓\n📆16/12, 9:00 - 13:30\n📌Seminar 30, Edifici Tomás i Valiente @Dret_UB \nCome and join us! https://t.co/4SNTgV3Peu",
      "expandedUrl" : "https://twitter.com/i/web/status/1602699073714364417"
    }
  },
  {
    "like" : {
      "tweetId" : "1602301180947955714",
      "fullText" : "Aquest divendres 4 estudiants de doctorat presentaran la seva recerca al VII Barcelona PhD workshop👩‍🎓🧑‍🎓\n📆16 de desembre, de 9:00 a 13:30\n📌Seminari 30, Edifici Tomás i Valiente\nRegistreu-vos aquí:\nhttps://t.co/C95P0CPZAM",
      "expandedUrl" : "https://twitter.com/i/web/status/1602301180947955714"
    }
  },
  {
    "like" : {
      "tweetId" : "1595750954112098304",
      "fullText" : "📢 ECPR's Section Call is out! Send us your panel proposal for the Law &amp; Courts section by 19 December and join us at #ecprgc23 in Prague next year. If you have any questions, don't hesitate to reach out, we're looking forward to hearing from you! https://t.co/ga6RuOCT1n",
      "expandedUrl" : "https://twitter.com/i/web/status/1595750954112098304"
    }
  },
  {
    "like" : {
      "tweetId" : "1592473693787426817",
      "fullText" : "Hay que agradecerle a @SerranoAlfonso la rectificación. La honradez no entiende de ideologías. Seguimos. https://t.co/1oVE1aEvLH https://t.co/5bBbDTnhe4",
      "expandedUrl" : "https://twitter.com/i/web/status/1592473693787426817"
    }
  },
  {
    "like" : {
      "tweetId" : "1590666386657116160",
      "fullText" : "The new administrative staff member updated the names in my office and, as I always talk to him in Catalan, he put my name in Catalan by mistake. I think I won't say anything until next week to enjoy what may be my peak of Catalan identity 😂 https://t.co/5rbsLM9f31",
      "expandedUrl" : "https://twitter.com/i/web/status/1590666386657116160"
    }
  },
  {
    "like" : {
      "tweetId" : "1590325438102261764",
      "fullText" : "In the workshop, early career researchers were introduced to existing databases on courts in Europe and to statistical tools that can be used to analyse such data. Read more about the ARENA co-organised event 👇\nhttps://t.co/5w7oJDPn3N",
      "expandedUrl" : "https://twitter.com/i/web/status/1590325438102261764"
    }
  },
  {
    "like" : {
      "tweetId" : "1589978146107174912",
      "fullText" : "I don't like selfies but here's proof that I'm in sunny Barcelona! Very excited about the next 3 months visiting @Evaanduiza at this great department @cpa_uab @UABBarcelona! ☺️ https://t.co/gmkmPI7Qw0",
      "expandedUrl" : "https://twitter.com/i/web/status/1589978146107174912"
    }
  },
  {
    "like" : {
      "tweetId" : "1588543087252762625",
      "fullText" : "Doncs ara si! Podríem dir que tanquem una bonica etapa de la meva vida! 🥳🥳 https://t.co/uFYhMwXkzN",
      "expandedUrl" : "https://twitter.com/i/web/status/1588543087252762625"
    }
  },
  {
    "like" : {
      "tweetId" : "1583148970427133952",
      "fullText" : "La principal característica de la derecha española ha sido históricamente su bajo nivel político. Y ese nivel no es bajo porque lo digan españoles de izquierdas, sino porque existe el puente aéreo Madrid-Bruselas para demostrarlo una y otra y otra vez.\n\nhttps://t.co/YyjtAilEmb",
      "expandedUrl" : "https://twitter.com/i/web/status/1583148970427133952"
    }
  },
  {
    "like" : {
      "tweetId" : "1583174543857762305",
      "fullText" : "@pruizrobledillo @Cazatalentos Creo que es este \n\nhttps://t.co/8clamfF8Rk",
      "expandedUrl" : "https://twitter.com/i/web/status/1583174543857762305"
    }
  },
  {
    "like" : {
      "tweetId" : "1582310146281127938",
      "fullText" : "🚨We have news!🚨\nAs you can see, our team has grown… and we take this opportunity to welcome @SergiFerrerJuan, Enrique Prada, and @leire_rincon\n⬇️Thread⬇️ https://t.co/kTqPiQuRpZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1582310146281127938"
    }
  },
  {
    "like" : {
      "tweetId" : "1581224599580467201",
      "fullText" : "Thanks for all the hard work organizing this @michal_ovadek! I had a great time. https://t.co/EY3xPLHvlr",
      "expandedUrl" : "https://twitter.com/i/web/status/1581224599580467201"
    }
  },
  {
    "like" : {
      "tweetId" : "1580574139428925443",
      "fullText" : "Finalment, aquí està! / Finally, here it is!\n#Thesis #Ibecaconselldelaterra @ConsellGeneral @PolitiquesUPF @ins https://t.co/nYThSuYLj7",
      "expandedUrl" : "https://twitter.com/i/web/status/1580574139428925443"
    }
  },
  {
    "like" : {
      "tweetId" : "1578460400030457858",
      "fullText" : "Seguimos con nuestra masterclass de planos con @AlejandroGCalvo. \n▶ Plano Medio: el que te corta por la cintura y muestra la parte superior. https://t.co/EiNFFm27CK",
      "expandedUrl" : "https://twitter.com/i/web/status/1578460400030457858"
    }
  },
  {
    "like" : {
      "tweetId" : "1578790858782085122",
      "fullText" : "Think I just echo everyones’s experience when I say this was an incredibly valuable and productive format - need more of this to come! \n\nThank you to all of you; for a great setup, for insightful papers, for lively discussions, for valuable feedback and, indeed, for a great time! https://t.co/23EbdwtFYf",
      "expandedUrl" : "https://twitter.com/i/web/status/1578790858782085122"
    }
  },
  {
    "like" : {
      "tweetId" : "1578655142949269504",
      "fullText" : "Georg Vanberg holding the keynote lecture on \"Transitional Justice and the Rule of Law: Tainted Judges and Accountability for Nazi Crimes in West Germany\"! Thank you @ECPR for generous support for the workshop! https://t.co/3mPdoptEPE https://t.co/WU5VBWHIbv",
      "expandedUrl" : "https://twitter.com/i/web/status/1578655142949269504"
    }
  },
  {
    "like" : {
      "tweetId" : "1578356492985454593",
      "fullText" : "The @ECPR group kicking off the first Joint Global Politics of Law &amp; Courts Workshop with workshops simultaneously in Berlin and Atlanta! Very much looking forward to the hybrid sessions later today! https://t.co/284srou6kv",
      "expandedUrl" : "https://twitter.com/i/web/status/1578356492985454593"
    }
  },
  {
    "like" : {
      "tweetId" : "1577006817770512385",
      "fullText" : "Esta entrevista de Jesús Quintero a José María García fue censurada en TV. Contó la corrupción de Florentino Pérez, Aznar y Miguel Blesa para fichar a Figo por el Real Madrid. Cortaron sus cabezas y los dos periodistas fueron borrados del mapa mediático.\n\nhttps://t.co/JJOGCzzdal",
      "expandedUrl" : "https://twitter.com/i/web/status/1577006817770512385"
    }
  },
  {
    "like" : {
      "tweetId" : "1577598318800150531",
      "fullText" : "1) El líder del partido fascista España 2.000 el 4 de junio de 2.022.\n2) El líder del partido fascista España 2.000 el 4 de octubre de 2.022 https://t.co/32LWeQM4Zj",
      "expandedUrl" : "https://twitter.com/i/web/status/1577598318800150531"
    }
  },
  {
    "like" : {
      "tweetId" : "1574661273601691648",
      "fullText" : "Liz Truss playing with the economy https://t.co/AKrbE7XlPD",
      "expandedUrl" : "https://twitter.com/i/web/status/1574661273601691648"
    }
  },
  {
    "like" : {
      "tweetId" : "1573238368128978946",
      "fullText" : "Conflictos armados y la construcción de narrativas a través de Twitter. El caso de la guerra entre Armenia y Azerbaiyán, un artículo de José Manuel Moreno-Mercado, Javier García-Marín, Óscar G. Luengo, publicado en el último número de la RECP.\n\n➡️ https://t.co/0cRT6aPAFS https://t.co/swDEDdnMCj",
      "expandedUrl" : "https://twitter.com/i/web/status/1573238368128978946"
    }
  },
  {
    "like" : {
      "tweetId" : "1568207838584905728",
      "fullText" : "Today I presented the research \"Where has everyone (and my GP) gone? Depopulation and electoral behaviour in Spain\" carried out with @tonirodon and @iMariathin. Many thanks to @CNavarroUAM for organising this WG at the XVI @AECPA_ Congress. https://t.co/QEmm8ttWl2",
      "expandedUrl" : "https://twitter.com/i/web/status/1568207838584905728"
    }
  },
  {
    "like" : {
      "tweetId" : "1567419366060298244",
      "fullText" : "Si vives en un piso de alquiler de una empresa y la inmobiliaria te ha cobrado honorarios de algún tipo, estás siendo víctima de una estafa. Te están robando.\n\nNi 500 no 3.000 euros: es ilegal cobrar por intermediación cuando el casero es persona jurídica. Si lo hacen, denuncia.",
      "expandedUrl" : "https://twitter.com/i/web/status/1567419366060298244"
    }
  },
  {
    "like" : {
      "tweetId" : "1358779133384421376",
      "fullText" : "Inmobiliaria: Tienes que pagarnos 1.500€ de honorarios.\n\n- Pero si el servicio se lo dáis a la empresa propietaria.\n\nInmobiliaria: ¿Quieres el piso o no?\n\n- Pero según la ley, lo tiene que pagar el propietario, al ser persona jurídica.\n\nInmobiliaria: El propietario no lo ve así.",
      "expandedUrl" : "https://twitter.com/i/web/status/1358779133384421376"
    }
  },
  {
    "like" : {
      "tweetId" : "1564268354894024707",
      "fullText" : "Cada vez encuentro más perfiles falsos vinculados a VOX que ponen como imagen de perfil a modelos eróticas haciéndose pasar por ellas. Lo llamativo es que en muchas ocasiones son promocionados por portavoces de VOX para que crezcan de seguidores. Sandra en realidad es Stephania. https://t.co/FOfesSnira",
      "expandedUrl" : "https://twitter.com/i/web/status/1564268354894024707"
    }
  },
  {
    "like" : {
      "tweetId" : "1562793152754307073",
      "fullText" : "Standing Group on Law &amp; Courts on the rise at @ECPR #ecprgc22! Taking a well deserved break from the great conference program. https://t.co/pL65eluVlE",
      "expandedUrl" : "https://twitter.com/i/web/status/1562793152754307073"
    }
  },
  {
    "like" : {
      "tweetId" : "1562464391462658051",
      "fullText" : "Today @AlbertoBueno_ is presenting our joint work (with Rafa Martínez  and Adolfo Calatrava) at the #ecprgc22. We propose a novel method to measure defense culture using a Mixed Factor Analysis https://t.co/KuwPno20b4",
      "expandedUrl" : "https://twitter.com/i/web/status/1562464391462658051"
    }
  },
  {
    "like" : {
      "tweetId" : "1562526786767900673",
      "fullText" : "Inspiring drinks after inspiring talks and great discussions among the law &amp; courts crowd @ECPR. Truly enjoying the in-person #ecprgc22 in Innsbruck. Cheers! https://t.co/VtpIB7yqtO",
      "expandedUrl" : "https://twitter.com/i/web/status/1562526786767900673"
    }
  },
  {
    "like" : {
      "tweetId" : "1562122626918645760",
      "fullText" : "felt bored. wanna play? https://t.co/nODD9THqvk https://t.co/nn61W7qRft",
      "expandedUrl" : "https://twitter.com/i/web/status/1562122626918645760"
    }
  },
  {
    "like" : {
      "tweetId" : "1560683053965524992",
      "fullText" : "PIN parental de vox https://t.co/VEQljWZmta",
      "expandedUrl" : "https://twitter.com/i/web/status/1560683053965524992"
    }
  },
  {
    "like" : {
      "tweetId" : "1560578999625125888",
      "fullText" : "És estiu, tothom està relaxat, però es veu que els defensors de la unitat d'Espanya no fan vacances. \n\nLlegiu aquest article (publicat a El País) i acompanyeu-me en aquesta trista història. https://t.co/EPQLfBxwJO",
      "expandedUrl" : "https://twitter.com/i/web/status/1560578999625125888"
    }
  },
  {
    "like" : {
      "tweetId" : "1816497069039014233",
      "fullText" : "Muy contenta con mi primera AECPA presentando mi paper “the influence of life transitions in populist attitudes” y participando en el GT “Emotividad y afectividad en política\" liderado por @carolgalais presentando también nuestro paper sobre emociones y voto a extrema derecha. https://t.co/TxAGsckk1v",
      "expandedUrl" : "https://twitter.com/i/web/status/1816497069039014233"
    }
  },
  {
    "like" : {
      "tweetId" : "1816464077364822264",
      "fullText" : "Very happy to have been awarded a National Research Grant for a 3-year project on the differences between left- &amp; right-wing Euroscepticism. It will be my first project as PI. Thanks to everyone who gave feedback and to all the great researchers who agreed to be part of the team! https://t.co/egEeWOfo2P",
      "expandedUrl" : "https://twitter.com/i/web/status/1816464077364822264"
    }
  },
  {
    "like" : {
      "tweetId" : "1816080536646848608",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1816080536646848608"
    }
  },
  {
    "like" : {
      "tweetId" : "1815678579193024774",
      "fullText" : "🍾Very happy to have been awarded a National Research Grant🕺 @PolitiquesUPF @UPFBarcelona\n\n➡️Nice excuse to continue studying voting behaviour during the Spanish Second Republic 😊 @pauvallprat @mguinjoan @magsedu https://t.co/E2iMiOPRUQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1815678579193024774"
    }
  },
  {
    "like" : {
      "tweetId" : "1812788186415833495",
      "fullText" : "“Plusvalía”.\nÓleo sobre lienzo. https://t.co/nT14bDr6TG",
      "expandedUrl" : "https://twitter.com/i/web/status/1812788186415833495"
    }
  },
  {
    "like" : {
      "tweetId" : "1798330029182747134",
      "fullText" : "🥳🚨 Over the moon to see our article (w/ my incredible co-authors @tonirodon and @iMariathin) “Where has everyone gone? Depopulation and voting behaviour in Spain” published in @EJPRjournal (open access🔓). https://t.co/Kf2jldplbk",
      "expandedUrl" : "https://twitter.com/i/web/status/1798330029182747134"
    }
  },
  {
    "like" : {
      "tweetId" : "1809135953774075995",
      "fullText" : "📢 #epsa2024 Join us for the Summer Institute in Computational Social Science in Barcelona on October 21-25  \n👉https://t.co/McyLWRu6vP\n📅Apply by July 12th!",
      "expandedUrl" : "https://twitter.com/i/web/status/1809135953774075995"
    }
  },
  {
    "like" : {
      "tweetId" : "1806006036429512996",
      "fullText" : "Pay attention to this Summer Institute https://t.co/WkypZw5bpn",
      "expandedUrl" : "https://twitter.com/i/web/status/1806006036429512996"
    }
  },
  {
    "like" : {
      "tweetId" : "1806001491427148070",
      "fullText" : "We have an incredible lineup and the opportunity to attend the Computational Social Science Conference organized by the Barcelona Supercomputing Center on the following week @BSC_CNS",
      "expandedUrl" : "https://twitter.com/i/web/status/1806001491427148070"
    }
  },
  {
    "like" : {
      "tweetId" : "1806001489619399149",
      "fullText" : "📢Join us for the last sigh of summer!\nThe Summer Institute in Computational Social Science in Barcelona is taking place on October 21-25  \n👉https://t.co/LKjouuuoBi\n📅Apply by July 12th!",
      "expandedUrl" : "https://twitter.com/i/web/status/1806001489619399149"
    }
  },
  {
    "like" : {
      "tweetId" : "1806060107496612194",
      "fullText" : "Join us for the next #SICSS in beautiful Barcelona ☀️. We are especially interested in polarization scholars using computational methods. https://t.co/8GG16RlIiv",
      "expandedUrl" : "https://twitter.com/i/web/status/1806060107496612194"
    }
  },
  {
    "like" : {
      "tweetId" : "1804099734593732782",
      "fullText" : "The Barcelona PhD Workshop on Empirical Political Science has reached its tenth edition🎉 @PolitiquesUPF  @PolitiquesUAB @CPoliticaUB https://t.co/AbJqQ1kzCj\n\n@irewrl presenting the results of a field civic education experiment on different Catalan schools @COVIDEUProject https://t.co/ZZNUc9Q58T",
      "expandedUrl" : "https://twitter.com/i/web/status/1804099734593732782"
    }
  },
  {
    "like" : {
      "tweetId" : "1803788311301095632",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1803788311301095632"
    }
  },
  {
    "like" : {
      "tweetId" : "1803700297602154681",
      "fullText" : "It's great to see how things institutionalize. Tomorrow we will have the 10th (!) Barcelona PhD Workshop on Empirical Political Science, organized at @CPoliticaUB with students and professors from @PolitiquesUPF and @PolitiquesUAB https://t.co/PsdGvJlJA3",
      "expandedUrl" : "https://twitter.com/i/web/status/1803700297602154681"
    }
  },
  {
    "like" : {
      "tweetId" : "1803378613317705836",
      "fullText" : "#CàtedresUB | ⚖️ El @RectorUB i la consellera @gemmaubasart han signat l’acord per crear una nova càtedra que avaluï l’impacte  social i econòmic del bon funcionament de l’administració de Justícia\n\n🎓 La dirigirà @pepvallbe, de @Dret_UB.\n\n👉 https://t.co/GB4XGn5BGW https://t.co/igZ2CuWEpq",
      "expandedUrl" : "https://twitter.com/i/web/status/1803378613317705836"
    }
  },
  {
    "like" : {
      "tweetId" : "1803339830442512695",
      "fullText" : "Two incredible months in Hamburg have come to an end. Many thanks to @GIGA_Institute, the entire ILAS team, and especially to @MarianaLlanosHa and @tibi_weber for hosting me and making this stay an unforgettable experience. \n\nSee you soon Hamburg! https://t.co/wZbGCkRx8S",
      "expandedUrl" : "https://twitter.com/i/web/status/1803339830442512695"
    }
  },
  {
    "like" : {
      "tweetId" : "1800826184479256636",
      "fullText" : "📢 CALL FOR ABSTRACTS!\n\n📝Workshop «Judicial Politics, Federalism, and Territorial Disputes»\n🗓️ 18-19 November 2024\n🏙️ Barcelona  \n🗣️ Keynote speaker: Patricia Popelier (@UAntwerpen)\n⏳ Deadline: 10 September https://t.co/e4tnIEBQEX",
      "expandedUrl" : "https://twitter.com/i/web/status/1800826184479256636"
    }
  },
  {
    "like" : {
      "tweetId" : "1803269880910610669",
      "fullText" : "If you are interested in the intersection between judicial politics and territorial politics, come see us next autumn in Barcelona. It's going to be fun! https://t.co/VYe3VL72UP",
      "expandedUrl" : "https://twitter.com/i/web/status/1803269880910610669"
    }
  },
  {
    "like" : {
      "tweetId" : "1803084713810100296",
      "fullText" : "Per a una jurista i amant de la Universitat com jo, és un repte molt motivador formar part d’aquesta comissió. \nPreparada per treballar i, com sempre, a disposició de tots i totes les estudiants. Gràcies per la vostra confiança! 💪🏽 https://t.co/2YvllwWEyE",
      "expandedUrl" : "https://twitter.com/i/web/status/1803084713810100296"
    }
  },
  {
    "like" : {
      "tweetId" : "1801615322069287404",
      "fullText" : "A huge thank you to everyone who joined us for the Barcelona CAP Conference. Looking forward to meet @bdjones_jones and you all at the next CAP conference chaired by @ckbreunig and @DeissHelbig https://t.co/HF0pvUHhAU",
      "expandedUrl" : "https://twitter.com/i/web/status/1801615322069287404"
    }
  },
  {
    "like" : {
      "tweetId" : "1801598576637645125",
      "fullText" : "IBEI hosted The Comparative Agendas Project Annual Conference, jointly organised with @CPoliticaUB.\n\nWe've had three days of thought-provoking discussions on agenda-setting, political representation, social media, and communication studies.\n\nMany thanks to all the participants!🙌 https://t.co/Qx6clav81s",
      "expandedUrl" : "https://twitter.com/i/web/status/1801598576637645125"
    }
  },
  {
    "like" : {
      "tweetId" : "1801387665356431785",
      "fullText" : "I’ve been at many conferences, but can’t remember one as warm and fun as the CAP conference this year. Thanks @IBEI, @laurachaques &amp; the policy agendas project https://t.co/d5LnrK6hYa",
      "expandedUrl" : "https://twitter.com/i/web/status/1801387665356431785"
    }
  },
  {
    "like" : {
      "tweetId" : "1799026384855249113",
      "fullText" : "BORJA VILLACÍS Y EL FRAY LUIS DE LEÓN\n\nBorja Villacís y Sergio Rodríguez Moreno, el \"Chopi\", dos conocidos neonazis que acaban de fallecer en circunstancias bastante turbias, estudiaron en el Fray Luis de León, un colegio de padres reparadores situado en el centro de Madrid. Yo… https://t.co/H9qrY3SBa1",
      "expandedUrl" : "https://twitter.com/i/web/status/1799026384855249113"
    }
  },
  {
    "like" : {
      "tweetId" : "1798982389768782027",
      "fullText" : "🟠 COMIENZA LA HUELGA DE ALQUILERES CONTRA NÉSTAR-AZORA 🟠\n\n9️⃣0️⃣0️⃣ inquilinas\n1️⃣0️⃣ bloques\n1️⃣ sola voz que exige\n📢 NO MÁS SUBIDAS ILEGALES \n📢 NEGOCIACIÓN COLECTIVA YA\n\nProbablemente el mayor conflicto colectivo que hemos organizado hasta hoy\n\n¿Quieres saber más? ¡Sigue hilo!\n🧵 https://t.co/FGdOllZJGo",
      "expandedUrl" : "https://twitter.com/i/web/status/1798982389768782027"
    }
  },
  {
    "like" : {
      "tweetId" : "1798619748269523094",
      "fullText" : "🚨New article❗️\n\nWhere has everyone gone? Depopulation and voting behaviour in Spain @EJPRjournal with my brilliant coauthors @alsanchezgarcia @iMariathin https://t.co/p3iZ8ZuLQM @PolitiquesUPF \n\n🚜Does depopulation change electoral support? Which party benefits from it?🧵",
      "expandedUrl" : "https://twitter.com/i/web/status/1798619748269523094"
    }
  },
  {
    "like" : {
      "tweetId" : "1797652170470502763",
      "fullText" : "Already in Bcn, assimilating what have been these incredible 4 months in NY and everything I've experienced. I will never forget the seminars with prof. Fraser, Harvey &amp; Arruzza and everything I learned together with the wonderful colleagues from @TheNewSchool &amp; @CUNY. Thanks ❤️ https://t.co/oDAqfehsbe",
      "expandedUrl" : "https://twitter.com/i/web/status/1797652170470502763"
    }
  },
  {
    "like" : {
      "tweetId" : "1796619113520845108",
      "fullText" : "Just presented my paper 'The Use of Criminal Typology of Terrorism in the Spanish State: Lawfare and Politicization of Justice' at the 'No War but the Class War' congress. Thank you @histmat &amp; @InstituteofRad1 for organizing this amazing conference at this beautiful university! https://t.co/CyeJMNuSDB",
      "expandedUrl" : "https://twitter.com/i/web/status/1796619113520845108"
    }
  },
  {
    "like" : {
      "tweetId" : "1796112225163256290",
      "fullText" : "Ja estan obertes les inscripcions al postgrau d'Analista de dades per a l'anàlisi política i la gestió pública que fem a @CPoliticaUB  https://t.co/PTMPuRRyrO",
      "expandedUrl" : "https://twitter.com/i/web/status/1796112225163256290"
    }
  },
  {
    "like" : {
      "tweetId" : "1793736279596871802",
      "fullText" : "És molt trist que els problemes reals mai s'enfronten. https://t.co/KBAoFjf3Dh",
      "expandedUrl" : "https://twitter.com/i/web/status/1793736279596871802"
    }
  },
  {
    "like" : {
      "tweetId" : "1791442637418815767",
      "fullText" : "\"Des d’un punt de vista intel·lectual, aquest és un moment molt emocionant\" entrevista en català a Nancy Fraser a @catarsimagazin 👉https://t.co/frgjZEgjsw ✊💜 https://t.co/q87IKD5a0O",
      "expandedUrl" : "https://twitter.com/i/web/status/1791442637418815767"
    }
  },
  {
    "like" : {
      "tweetId" : "1790789996506411479",
      "fullText" : "New doctor in the room! Congratulations @DaniBalinhas!\n\nWe wish you a fruitful career! https://t.co/judoxCSUj6",
      "expandedUrl" : "https://twitter.com/i/web/status/1790789996506411479"
    }
  },
  {
    "like" : {
      "tweetId" : "1789295480297357472",
      "fullText" : "✊ Aquesta legislatura seré claustral a la @UniBarcelona per la circumscripció de doctorat de la mà de @FemlaPublicaUB i @DocsLluitaUB\n\nEl Moviment Estudiantil divers, just i igualitari avança! #NingúEnrere 💜🏳️‍🌈🇵🇸 https://t.co/PlzKcouXjo",
      "expandedUrl" : "https://twitter.com/i/web/status/1789295480297357472"
    }
  },
  {
    "like" : {
      "tweetId" : "1788615226448921060",
      "fullText" : "I am happy to see that our article has just been published @Journal_CompPol In this study we try to explain the conditions under which the citizens tolerate government non-compliance with higher court decisions. https://t.co/IoM1IVkAWK",
      "expandedUrl" : "https://twitter.com/i/web/status/1788615226448921060"
    }
  },
  {
    "like" : {
      "tweetId" : "1788502937485852888",
      "fullText" : "Dissertation progress bar complete! 🎉🎉🎉🎉 https://t.co/Z0uKN2MmbP",
      "expandedUrl" : "https://twitter.com/i/web/status/1788502937485852888"
    }
  },
  {
    "like" : {
      "tweetId" : "1788512977819140279",
      "fullText" : "Molt content d'haver rebut ahir el Premi extraordinari de doctorat de la @UniBarcelona. I, sobretot, d'haver estat tan ben acompanyat acadèmicament i personalment al llarg d'aquest camí a @CPoliticaUB https://t.co/UWVBgDuAAm",
      "expandedUrl" : "https://twitter.com/i/web/status/1788512977819140279"
    }
  },
  {
    "like" : {
      "tweetId" : "1788253479049244893",
      "fullText" : "Molt contents del premi extraordinari de doctorat de la @UniBarcelona, que ha guanyat @pauvallprat, a qui vam dirigir la tesi amb @cescamat i @pepvallbe https://t.co/PEyuK0rUBY",
      "expandedUrl" : "https://twitter.com/i/web/status/1788253479049244893"
    }
  },
  {
    "like" : {
      "tweetId" : "1787477232417435860",
      "fullText" : "📢 \"Call for papers\" pel “VI International Doctoral Workshop” (“Digitalization and Technological Change”)\n\n⚠️ Termini: 31 de maig\n\n✏️ https://t.co/1IjI5SZRcd https://t.co/XMlDWlATPm",
      "expandedUrl" : "https://twitter.com/i/web/status/1787477232417435860"
    }
  },
  {
    "like" : {
      "tweetId" : "1787560037319155755",
      "fullText" : "🗳️ Vota per unes condicions dignes! \nEm presento com a candidata a representar el programa de doctorat en sociologia. Encara que aquesta candidatura sigui individual, forma part de la candidatura Fem-la Pública de la UB 👇 https://t.co/YZFQ408LuX",
      "expandedUrl" : "https://twitter.com/i/web/status/1787560037319155755"
    }
  },
  {
    "like" : {
      "tweetId" : "1787037463254290780",
      "fullText" : "Hace dos años de esta entrevista que nos hizo\n@CHFerreiro a @jaimebgl y a mí. Dos años de la mejor foto de portada de disco indie: https://t.co/ifJegJjA5H https://t.co/Nkce1ENy0l",
      "expandedUrl" : "https://twitter.com/i/web/status/1787037463254290780"
    }
  },
  {
    "like" : {
      "tweetId" : "1784909246678650906",
      "fullText" : "My new home for the next 3 weeks🙌 @MZESUniMannheim https://t.co/THCKmvADRU",
      "expandedUrl" : "https://twitter.com/i/web/status/1784909246678650906"
    }
  },
  {
    "like" : {
      "tweetId" : "1781336419123773690",
      "fullText" : "Molt emocionada per haver rebut el Premi Extraordinari de Grau @Dret_UB a la @UniBarcelona. És un orgull haver pogut estudiar el que m’apassiona a una universitat pública de tanta qualitat! 👩🏽‍🎓 https://t.co/7iX9NDli70",
      "expandedUrl" : "https://twitter.com/i/web/status/1781336419123773690"
    }
  },
  {
    "like" : {
      "tweetId" : "1780677999488331889",
      "fullText" : "@LuisMRemiro @CPoliticaUB @Evaanduiza @EelcoHarteveld @luismmiller Ueeeh!!! 🎉🎉 Grande, Dr. Luis Remiro 😁",
      "expandedUrl" : "https://twitter.com/i/web/status/1780677999488331889"
    }
  },
  {
    "like" : {
      "tweetId" : "1780677056147103880",
      "fullText" : "Today I successfully defended my PhD dissertation and I'm speechless. I'm deeply grateful for the support of all my colleagues at @CPoliticaUB and the insightful comments of this wonderful committee @Evaanduiza @EelcoHarteveld @luismmiller. https://t.co/sa992gQx8p",
      "expandedUrl" : "https://twitter.com/i/web/status/1780677056147103880"
    }
  },
  {
    "like" : {
      "tweetId" : "1775633345864487228",
      "fullText" : "Just arrived at Chicago for #MPSA! Say hi if you’re around! #MPSAnet https://t.co/z0Nz33yNjt",
      "expandedUrl" : "https://twitter.com/i/web/status/1775633345864487228"
    }
  },
  {
    "like" : {
      "tweetId" : "1775462306056376647",
      "fullText" : "Molt interessant aquesta iniciativa per aportar transparència al mercat del lloguer https://t.co/NEeETzMhtu",
      "expandedUrl" : "https://twitter.com/i/web/status/1775462306056376647"
    }
  },
  {
    "like" : {
      "tweetId" : "1771233026216767964",
      "fullText" : "Content i emocionat de poder anunciar que a partir del curs vinent m’incorporo a la @UOCedcp  com a professor lector🥳\n\nA treballar fort per retornar la confiança dipositada amb mi.",
      "expandedUrl" : "https://twitter.com/i/web/status/1771233026216767964"
    }
  },
  {
    "like" : {
      "tweetId" : "1768621940476919967",
      "fullText" : "My dissertation has been officially accepted by the PhD Commission 🎉\n\nThe public defence will take place on April 17th 2024 in Barcelona.📷 I won't be making any spoilers but I have to say that my defense panel is AMAZING🔥 https://t.co/PdnHDPmUGk",
      "expandedUrl" : "https://twitter.com/i/web/status/1768621940476919967"
    }
  },
  {
    "like" : {
      "tweetId" : "1767104504283926568",
      "fullText" : "📘Qui no vulgui pols...conflicte polític i polarització.\n\n🚨Ja és aquí, llest per Sant Jordi 🐉🌹A les vostres llibreries de confiança (i a les que no, també). \n\n▶️Un llibre en defensa del conflicte polític i en contra de l'obsessió pel consens 🧵 @peudemosca https://t.co/7iNcAaoc5L",
      "expandedUrl" : "https://twitter.com/i/web/status/1767104504283926568"
    }
  },
  {
    "like" : {
      "tweetId" : "1765409500255703083",
      "fullText" : "La llegada de la secta ultraderechista EL YUNQUE a España, décadas después de su creación en México.\n\nSu objetivo: instaurar una teocracia sin derechos e implementar la agenda de la extrema derecha global.\n\nEscucha DIOS PATRIA YUNQUE en @PodiumPodcast\n\nhttps://t.co/jS2E8hQYfW",
      "expandedUrl" : "https://twitter.com/i/web/status/1765409500255703083"
    }
  },
  {
    "like" : {
      "tweetId" : "1765330892732469274",
      "fullText" : "En política por muy legítimos que sean los problemas se deben enmarcar de manera correcta. Y desde luego que si los marcos en los que toca discutir son cerrar restaurantes pronto y bajar el IVA a las galerías de arte nos dirigimos inexorablemente hacia el desastre más absoluto.",
      "expandedUrl" : "https://twitter.com/i/web/status/1765330892732469274"
    }
  },
  {
    "like" : {
      "tweetId" : "1764914110620197214",
      "fullText" : "🚨New article, with the great @pauvallprat at @WEPsocial🎉 \n\n➡️How were the Spanish conservatives (PP) able to block (for a relatively long time) the far-right from emerging?\n\n🐉The \"chameleonic effect\" and other important things of the 23-J general election👇🏻 @PolitiquesUPF https://t.co/CTI7Rq8kQT",
      "expandedUrl" : "https://twitter.com/i/web/status/1764914110620197214"
    }
  },
  {
    "like" : {
      "tweetId" : "1764911364202451064",
      "fullText" : "🚨Publication Alert🚨📢\nIn a new article published with @tonirodon at @WEPsocial we analyse the 2023 Spanish Elections.\nCheck it out if you are interested in vote transfers, party evaluations and gendered differences in vote choices in Spanish politics!\nhttps://t.co/kdOLWCH06m https://t.co/5DYjId7dkt",
      "expandedUrl" : "https://twitter.com/i/web/status/1764911364202451064"
    }
  },
  {
    "like" : {
      "tweetId" : "1763848432651837753",
      "fullText" : "¿Quién debería gobernar al Poder judicial? De ello hablan @AlbertNogueraF y @lasa_lasa17444 con  @mylaibm en un nuevo podcast de Constitución desde los márgenes, el proyecto de innovación educativa de @UV_EG @DretUV @gidemocracia\n@Spotify  @ivoox \n https://t.co/rxAOp9TEhi",
      "expandedUrl" : "https://twitter.com/i/web/status/1763848432651837753"
    }
  },
  {
    "like" : {
      "tweetId" : "1762791427329704347",
      "fullText" : "📢¡Últimos días para enviar las ponencias! https://t.co/YZFYMoVYZ1",
      "expandedUrl" : "https://twitter.com/i/web/status/1762791427329704347"
    }
  },
  {
    "like" : {
      "tweetId" : "1762515155085128176",
      "fullText" : "Si te interesa la política judicial o el estudio empírico del derecho, tenemos buenas noticias para ti. Plazo para mandar tu propuesta: 29 feb. 24 @AECPA_ https://t.co/F0xhP3xTbQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1762515155085128176"
    }
  },
  {
    "like" : {
      "tweetId" : "1762485711746298306",
      "fullText" : "🚨 PubAlert @polcommjournal Open Source: looking at suspension patterns of users who follow Iranian elites on Twitter. Conservative users and those supportive of the Iranian government are suspended at higher rates, after controlling for other confounders. https://t.co/I3x9hBAq8C",
      "expandedUrl" : "https://twitter.com/i/web/status/1762485711746298306"
    }
  },
  {
    "like" : {
      "tweetId" : "1761086381378453567",
      "fullText" : "Best way to close the week? To have your paper accepted! 🔥🔥\n\nCongratulations to all the team @AlbertoBueno_ @calatravag and Rafa Martinez! https://t.co/4238JQS871",
      "expandedUrl" : "https://twitter.com/i/web/status/1761086381378453567"
    }
  },
  {
    "like" : {
      "tweetId" : "1760300961333907844",
      "fullText" : "🎦L'equip del programa 30 minuts de TV3 ha vingut al #CRAIBiblioteca de Dret per entrevistar a Sheila González, prof. Ciència Política UB, per un capítol sobre educació\n\n📚Les monografies de ciència política les trobareu a la signatura NB, de la 3a planta\n\nhttps://t.co/rpfQIDTiy4 https://t.co/eFHo989sQE",
      "expandedUrl" : "https://twitter.com/i/web/status/1760300961333907844"
    }
  },
  {
    "like" : {
      "tweetId" : "1759857152804433926",
      "fullText" : "Happy to share this paper, now online @The_JOP \nabout attitudinal consistency in welfare reform preferences with @SiljaHausermann @MatthiasEnggist @PinggeraMichael \n👉https://t.co/GESOiSFJa3 https://t.co/vtv9HSiwkx",
      "expandedUrl" : "https://twitter.com/i/web/status/1759857152804433926"
    }
  },
  {
    "like" : {
      "tweetId" : "1758914816863813884",
      "fullText" : "🆘🇵🇸 El diputado @EnriqueSantiago también ha participado en la mani de hoy. Hablamos del embargo de armas a 🇮🇱. @CanalRed_TV https://t.co/M2hSiujjz7",
      "expandedUrl" : "https://twitter.com/i/web/status/1758914816863813884"
    }
  },
  {
    "like" : {
      "tweetId" : "1758420714405712376",
      "fullText" : "New publication!🎉\nIn \"For every action a reaction?\" (@EJPRjournal), Amy Alexander, Nicholas Charron &amp; I compare two cultural threats: Refugee immigration &amp; women's rights. In a survey experiment across 27 EU countries... 🧵⬇️\n\nhttps://t.co/QcwChefU08",
      "expandedUrl" : "https://twitter.com/i/web/status/1758420714405712376"
    }
  },
  {
    "like" : {
      "tweetId" : "1753440199160353127",
      "fullText" : "Let the adventure begin! Surely one of the best opportunities I have ever had.  Molt contenta de passar aquest segon quadrimestre a @TheNewSchool amb el departament de polítiques. Privilegiada, passada per aigua i amb molt per llegir 🍎☔📚 https://t.co/IyCW1pAtgn",
      "expandedUrl" : "https://twitter.com/i/web/status/1753440199160353127"
    }
  },
  {
    "like" : {
      "tweetId" : "1757837675816460516",
      "fullText" : "I am very proud that you are achieving all your goals. https://t.co/daqa8HKQL4",
      "expandedUrl" : "https://twitter.com/i/web/status/1757837675816460516"
    }
  },
  {
    "like" : {
      "tweetId" : "1757745858496414152",
      "fullText" : "🚨 🇪🇺Si estás interesad@ en la investigación sobre la UE, no estás sol@. Hemos coordinado para ti un grupo de trabajo sobre \"Gobernanza y Actitudes hacia la UE\" para el próximo #XVIICongresoAECPA en Burgos. @AECPA_  @UPFBaces @EUGOVresearch @MACIES_UC3M @luisbouzagarcia Info 👇🏼 https://t.co/T9CddNZRPL",
      "expandedUrl" : "https://twitter.com/i/web/status/1757745858496414152"
    }
  },
  {
    "like" : {
      "tweetId" : "1756257187733684491",
      "fullText" : "👩🏻🔬Aquest diumenge és l'#11F, #DiaDonaiNenaCiència\n\n🗣 La catedràtica de la @Unibarcelona i directora de l'@IBEI, @laurachaques, parla del paper de les dones en la direcció de la #recerca com a referent per a les futures científiques\n\n🔗https://t.co/iIOLg6WeyR\n#WomenInScience https://t.co/GwFKJGaeNt",
      "expandedUrl" : "https://twitter.com/i/web/status/1756257187733684491"
    }
  },
  {
    "like" : {
      "tweetId" : "1755553142094041243",
      "fullText" : "Molt content del perfil i nivell dels membres del nou Consell Assessor internacional del CEO. Thank you all for accepting the invitation! https://t.co/lwFXclht3X",
      "expandedUrl" : "https://twitter.com/i/web/status/1755553142094041243"
    }
  },
  {
    "like" : {
      "tweetId" : "1754956538849140833",
      "fullText" : "Tomorrow, I am presenting my ongoing work on gender and intra-party politics at @EuropeAtHarvard! If you're interested in women within political parties, come and join us! https://t.co/DWtADYdrgq",
      "expandedUrl" : "https://twitter.com/i/web/status/1754956538849140833"
    }
  },
  {
    "like" : {
      "tweetId" : "1754789275923611938",
      "fullText" : "Todavía hay tiempo para enviar propuestas a nuestro grupo de trabajo sobre valores y comportamiento político hasta el 29 de febrero @bertous  @AECPA_ @CPoliticaUB https://t.co/cl46Nq1NVl",
      "expandedUrl" : "https://twitter.com/i/web/status/1754789275923611938"
    }
  },
  {
    "like" : {
      "tweetId" : "1753032223031169264",
      "fullText" : "Thrilled to join @CpoliticaUB as a Ramón y Cajal Fellow! 🎉🎉🎉\n\nEm fa molta il·lusió començar aquesta nova etapa professional. Amb ganes de sumar-me a aquest equipàs, de contribuir-hi la meva recerca i docència, de nous reptes, i de seguir creixent i aprenent! 😊 https://t.co/Yck5thMyca",
      "expandedUrl" : "https://twitter.com/i/web/status/1753032223031169264"
    }
  },
  {
    "like" : {
      "tweetId" : "1750570241363526032",
      "fullText" : "🤝@laurachaques, prof. of Political Science @UniBarcelona, is appointed new director of IBEI.\n\n@JacintJordana, prof. of Political Science &amp; Administration @UPFBarcelona, who has led IBEI since its foundation in 2004, now assumes the president position.\n\n🔗https://t.co/DTYNoMGG7v https://t.co/ETWaWJWcv7",
      "expandedUrl" : "https://twitter.com/i/web/status/1750570241363526032"
    }
  },
  {
    "like" : {
      "tweetId" : "1750510131253493841",
      "fullText" : "Xavier Fernández-I-Marín, @christoph_knill, @Ch_Steinbacher, &amp; Yves Steinebach leverage the gap between the number of policies requiring implementation &amp; the administrative capacities available to do so in democracies in this #APSRFirstView.\nhttps://t.co/3BQ2llz12x https://t.co/liPyJ4kxYz",
      "expandedUrl" : "https://twitter.com/i/web/status/1750510131253493841"
    }
  },
  {
    "like" : {
      "tweetId" : "1749760846555738324",
      "fullText" : "📣📊 Si estàs fent recerca en comportament judicial empíric, t'interessarà aquest grup de treball organitzat pel nostre company @PSUBRodilla i @jamayoralda al proper congrés AECPA (Burgos)\n\n📅Pots proposar la teva ponència fins al 29 de febrer!\nhttps://t.co/zl4Wn0ROhJ https://t.co/NeJefqXf3a",
      "expandedUrl" : "https://twitter.com/i/web/status/1749760846555738324"
    }
  },
  {
    "like" : {
      "tweetId" : "1749390999523049747",
      "fullText" : "Cada dia una raó més per fer anàlisi empírica del comportament judicial.  https://t.co/vhc2iqwRV1",
      "expandedUrl" : "https://twitter.com/i/web/status/1749390999523049747"
    }
  },
  {
    "like" : {
      "tweetId" : "1747330436613693778",
      "fullText" : "After finishing all the remaining bureaucracy, I can say that I have submitted my PhD thesis. This crazy run is coming to an end. https://t.co/LoF4M4viM3",
      "expandedUrl" : "https://twitter.com/i/web/status/1747330436613693778"
    }
  },
  {
    "like" : {
      "tweetId" : "1746948350039965965",
      "fullText" : "Molt content del premi d’@autogoverncat a @pauvallprat, un gran investigador format a @CPoliticaUB que és de justícia reconéixer https://t.co/5lBncjf3Uf",
      "expandedUrl" : "https://twitter.com/i/web/status/1746948350039965965"
    }
  },
  {
    "like" : {
      "tweetId" : "1745793411435659349",
      "fullText" : "Si us ha interessat, l'article on s'explica tot el procés de recollida d'informació i una descripció detallada de les dades la trobareu aquí: https://t.co/LjTCp6JYt3",
      "expandedUrl" : "https://twitter.com/i/web/status/1745793411435659349"
    }
  },
  {
    "like" : {
      "tweetId" : "1745793396868874576",
      "fullText" : "T'interessa la política i les eleccions🗳️? T'interessa la història📜? T'agraden els mapes🗺️? Doncs ara pots consultar els resultats electorals a nivell local entre 1890 i 1923 https://t.co/OwM2nR4E1Y gràcies a l'Explorador Social\n@CEDemografia! Petit fil🧵",
      "expandedUrl" : "https://twitter.com/i/web/status/1745793396868874576"
    }
  },
  {
    "like" : {
      "tweetId" : "1745075684576260388",
      "fullText" : "Today we launch the Progressive Politics Research Network with a first theme tackling some widespread myths around progressive politics\nIn this article, @SiljaHausermann and I reflect on some key findings from the six research briefs in this theme\nhttps://t.co/YtI7taw0QI",
      "expandedUrl" : "https://twitter.com/i/web/status/1745075684576260388"
    }
  },
  {
    "like" : {
      "tweetId" : "1744728004763537846",
      "fullText" : "Molt il·lusionat de poder rebre aquest premi! https://t.co/AiRVT8xm9L",
      "expandedUrl" : "https://twitter.com/i/web/status/1744728004763537846"
    }
  },
  {
    "like" : {
      "tweetId" : "1741886209058619556",
      "fullText" : "VOS ESTIMEM MOLT.\nGRÀCIES PER AQUESTS TRES DIES.\nVISCA TAVERNES, VISCA EL #FESTIVERN I VISCA VOSALTRES.\nENS VEIEM AL DESEMBRE ♥️\n\n#Festivern2024 https://t.co/e8rM5AUbL1",
      "expandedUrl" : "https://twitter.com/i/web/status/1741886209058619556"
    }
  },
  {
    "like" : {
      "tweetId" : "1670206938347450368",
      "fullText" : "#NuevaFotoDePerfil https://t.co/AUxkPOR3tU",
      "expandedUrl" : "https://twitter.com/i/web/status/1670206938347450368"
    }
  },
  {
    "like" : {
      "tweetId" : "1738464005381926992",
      "fullText" : "Sóc nouvinguda a @CPoliticaUB i aq dies han estat durs, especialment x gent q fa + temps q hi és. Contenta d tenir a prop companys/es amb capacitat d fer autocrítica i amb ganes d treballar x una universitat + sana i democràtica. No és un procés fàcil però és el q volem i farem. https://t.co/gMEydW4Yab",
      "expandedUrl" : "https://twitter.com/i/web/status/1738464005381926992"
    }
  },
  {
    "like" : {
      "tweetId" : "1737504655871975443",
      "fullText" : "📡Ya está abierto el plazo para presentar ponencias para el XVII Congreso AECPA\n@AECPA_\n\nNosotros coordinamos un grupo de trabajo sobre la transparencia en los gobiernos locales.  \n\nhttps://t.co/I6QjJEilGN\n\n#XVIICongresoAECPA https://t.co/9MtMVajUIF",
      "expandedUrl" : "https://twitter.com/i/web/status/1737504655871975443"
    }
  },
  {
    "like" : {
      "tweetId" : "1737448001033977876",
      "fullText" : "🥳🎉Beyond happy to have been awarded the José Manuel Blecua Prize, given to the top article derived from a PhD thesis published in a distinguished journal in the field of humanities and social sciences, awarded by the Consell Social of @UniBarcelona https://t.co/s3kjLD3tPO",
      "expandedUrl" : "https://twitter.com/i/web/status/1737448001033977876"
    }
  },
  {
    "like" : {
      "tweetId" : "1737447201557672432",
      "fullText" : "Gracias a @ICONS_Chile por organizar una gran II Conferencia Anual, donde pude presentar mi proyecto de tesis doctoral #ANID sobre comportamiento estratégico e independencia judicial, en un ambiente pluralista y multidisciplinar. Hasta la próxima! https://t.co/bK02rBjxC8",
      "expandedUrl" : "https://twitter.com/i/web/status/1737447201557672432"
    }
  },
  {
    "like" : {
      "tweetId" : "1735937500370145348",
      "fullText" : "📢 Publication Alert! Paper (with @CarmenRamirez97) \"The effect of judges' gender on decisions regarding intimate-partner violence\" has been published in the Journal of Empirical Legal Studies (https://t.co/8e4oMUP0U1). 📚 Here are the key findings ! (1/7)",
      "expandedUrl" : "https://twitter.com/i/web/status/1735937500370145348"
    }
  },
  {
    "like" : {
      "tweetId" : "1735682654203269576",
      "fullText" : "Happy to see this workshop consolidate. Very good papers and discussions today! #bcnpolisci https://t.co/bYYDea2Q9g",
      "expandedUrl" : "https://twitter.com/i/web/status/1735682654203269576"
    }
  },
  {
    "like" : {
      "tweetId" : "1735638661494915405",
      "fullText" : "Very happy to have participated in another edition of the PhD Workshop in Empirical Political Science. \n\n@ruizhdezmaria presented \"The evolution and change of populist attitudes: a panel data analysis\" \n\nSee you in the next Workshop! https://t.co/DAFAOeacSw https://t.co/FGXtwe9t2l",
      "expandedUrl" : "https://twitter.com/i/web/status/1735638661494915405"
    }
  },
  {
    "like" : {
      "tweetId" : "1735592264351588416",
      "fullText" : "🏛️We are very happy to host once again a new edition of the PhD Workshop on Empirical Political Science. \n\n▶️ If you are around, you still have time to make it 👉\n https://t.co/ApJhqk4NtU\n@PolitiquesUPF @PolitiquesUAB @CPoliticaUB 📷 @jordimunozm https://t.co/tXdm4j6K3N",
      "expandedUrl" : "https://twitter.com/i/web/status/1735592264351588416"
    }
  },
  {
    "like" : {
      "tweetId" : "1735230603211964921",
      "fullText" : "https://t.co/eZvzCl001O",
      "expandedUrl" : "https://twitter.com/i/web/status/1735230603211964921"
    }
  },
  {
    "like" : {
      "tweetId" : "1734678057536069949",
      "fullText" : "Muy contento de ver publicado mi artículo \"Polarización en la valoración de las Fuerzas Armadas españolas: identidad territorial e ideología política\" en la revista\"Cuadernos\" de la @Fundacion_MGA. https://t.co/FVzfAkW7tp",
      "expandedUrl" : "https://twitter.com/i/web/status/1734678057536069949"
    }
  },
  {
    "like" : {
      "tweetId" : "1733955415023489417",
      "fullText" : "Milei ya es presidente. Apenas lo acompañaron presidentes en la toma de posesión, si estuvieron sus amigos de Atlas Network, ultracatólicos y golpistas.\nSolo hace falta ver la representación española con Abascal, Tertsch, Cayetana y Esperanza Aguirre.\nABRO HILO.\n#MileiPresidente https://t.co/m8WP33l6oo",
      "expandedUrl" : "https://twitter.com/i/web/status/1733955415023489417"
    }
  },
  {
    "like" : {
      "tweetId" : "1734164317623263501",
      "fullText" : "I am so glad to share that I defended my dissertation \"Beyond the party's realm - The consequences of variation in candidate selection\"! 👩‍🎓🎉\n It feels amazing to be done and to get ready for the next step!  #PhDone https://t.co/7ndCBLi8fc",
      "expandedUrl" : "https://twitter.com/i/web/status/1734164317623263501"
    }
  },
  {
    "like" : {
      "tweetId" : "1733946784320307422",
      "fullText" : "@sanchezcastejon @BArevalodeLeon Acabo de conversar con mi Falcon",
      "expandedUrl" : "https://twitter.com/i/web/status/1733946784320307422"
    }
  },
  {
    "like" : {
      "tweetId" : "1731604152239681990",
      "fullText" : "🔊 Call for papers: Workshop on using LLMs and text-as-data in Political Science\nSubmissions: https://t.co/rG5hupm9DA https://t.co/0cdVKr1UO6",
      "expandedUrl" : "https://twitter.com/i/web/status/1731604152239681990"
    }
  },
  {
    "like" : {
      "tweetId" : "1730912192701096323",
      "fullText" : "La mayoría de los españoles quiere un referéndum para decidir entre monarquía y república\nhttps://t.co/qvJjTK5GYw Por @elenaherrerad y @VictriaVic",
      "expandedUrl" : "https://twitter.com/i/web/status/1730912192701096323"
    }
  },
  {
    "like" : {
      "tweetId" : "1730342963627036809",
      "fullText" : "😡És 😡 que 😡 ja 😡 no 😡 es 😡 pot 😡 fer 😡 broma 😡 de 😡 res😡\n\n#Polònia3Cat https://t.co/mKFwq61CYq",
      "expandedUrl" : "https://twitter.com/i/web/status/1730342963627036809"
    }
  },
  {
    "like" : {
      "tweetId" : "1728465693191164194",
      "fullText" : "It happened! Yesterday I successfully defended my thesis🎉\nThank you to my committee @dmorisi, @helene_helboe &amp; @JanRovny and to my supervisor @POINSproject @DaWS_SDU. https://t.co/vBzJFqpHCD",
      "expandedUrl" : "https://twitter.com/i/web/status/1728465693191164194"
    }
  },
  {
    "like" : {
      "tweetId" : "1726917579665744218",
      "fullText" : "Este juez se llama García Castellón y es quien dirige la investigación contra Tsunami Democràtic. Hoy ha pedido al Supremo imputar por terrorismo a Carles Puigdemont. La \"justicia\" en España.  https://t.co/abGBvjSb7z",
      "expandedUrl" : "https://twitter.com/i/web/status/1726917579665744218"
    }
  },
  {
    "like" : {
      "tweetId" : "1727031625647534410",
      "fullText" : "Feijóo promete otra legislatura de bloqueo en la renovación del CGPJ. Suponemos que asociaciones de jueces, fiscales, Colegios profesionales, etc. emitirán un comunicado condenándolo\nhttps://t.co/DRQ2cDrqw5",
      "expandedUrl" : "https://twitter.com/i/web/status/1727031625647534410"
    }
  },
  {
    "like" : {
      "tweetId" : "1726932412540817730",
      "fullText" : "No vendáis vuestra humanidad por 5 euros la hora. https://t.co/Gy6NX0U5Ut https://t.co/jrNRZZBHU6",
      "expandedUrl" : "https://twitter.com/i/web/status/1726932412540817730"
    }
  },
  {
    "like" : {
      "tweetId" : "1727055509579001921",
      "fullText" : "El Gobierno se estrena difundiendo el mito de que hay muchos rentistas que complementan su pensión con el alquiler y que están desprotegidos.\n\nHace poco publicamos un estudio que desmonta este bulo: la única población realmente vulnerable es la que no tiene vivienda en propiedad. https://t.co/eFdGPOll95 https://t.co/4TrxShUm5E",
      "expandedUrl" : "https://twitter.com/i/web/status/1727055509579001921"
    }
  },
  {
    "like" : {
      "tweetId" : "1726535696926802116",
      "fullText" : "Aparentemente, solo los pobres van a la cárcel... https://t.co/FIiAKyoKLW",
      "expandedUrl" : "https://twitter.com/i/web/status/1726535696926802116"
    }
  },
  {
    "like" : {
      "tweetId" : "1725267354009874761",
      "fullText" : "Hot off the press! “Research Handbook on Law and Political Systems” is out. I am happy to make a contribution with a chapter on “court-curbing”. https://t.co/38Eb8gpBpd",
      "expandedUrl" : "https://twitter.com/i/web/status/1725267354009874761"
    }
  },
  {
    "like" : {
      "tweetId" : "1724364491654144047",
      "fullText" : "If you are in Lisbon tomorrow, please join me, Alice Cunha (@nova_fcsh), Teresa Ruel (ISCSP, @CP_ISCSP) João Carvalho (@ISCTEIUL, @CIES_Iscte) and Rogério Peixoto (Ministério das Finanças) for my book presentation. https://t.co/TQjanqsX7B",
      "expandedUrl" : "https://twitter.com/i/web/status/1724364491654144047"
    }
  },
  {
    "like" : {
      "tweetId" : "1720748024400335100",
      "fullText" : "https://t.co/f7aTksqhCn",
      "expandedUrl" : "https://twitter.com/i/web/status/1720748024400335100"
    }
  },
  {
    "like" : {
      "tweetId" : "1719981902071779526",
      "fullText" : "En la encuesta piloto del proyecto @demotradeoff  hemos preguntado a los ciudadanos sobre el equilibrio de poder entre jueces, parlamento y gobierno 🧵\n\n¿Quién debería tener más poder e influencia en las decisiones políticas en España? El parlamento 👇 https://t.co/dsveII4Cd1",
      "expandedUrl" : "https://twitter.com/i/web/status/1719981902071779526"
    }
  },
  {
    "like" : {
      "tweetId" : "1714195103739199873",
      "fullText" : "📢Ja tenim el programa de la VI Jornada de Comportament Polític i Opinió Pública @Dret_UB!\nVine a conèixer la recerca i la comunitat treballant en comportament polític a Barcelona.\n📅9/11/2023 9:30 - 18.00\n👉https://t.co/xaEoP4nh5S https://t.co/ZWpFmnd3SK",
      "expandedUrl" : "https://twitter.com/i/web/status/1714195103739199873"
    }
  },
  {
    "like" : {
      "tweetId" : "1716382549465825640",
      "fullText" : "We are looking forward to receiving\n@alex_scacco at our departmental seminar! She will be presenting “Misinformation and Irregular Migration: Evidence from a Field Experiment in Nigeria” \n📅26/10 15:30 (notice the change in schedule)\n📌A-218 https://t.co/j9ynoTNNqn",
      "expandedUrl" : "https://twitter.com/i/web/status/1716382549465825640"
    }
  },
  {
    "like" : {
      "tweetId" : "1714974048034152831",
      "fullText" : "I am happy to organise next year´s section on Law &amp; Courts at #ecprgc2024 together with @EtienneHanelt ! Looking forward to reading your proposals! https://t.co/rShs8qUWAk",
      "expandedUrl" : "https://twitter.com/i/web/status/1714974048034152831"
    }
  },
  {
    "like" : {
      "tweetId" : "1714974801813512541",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1714974801813512541"
    }
  },
  {
    "like" : {
      "tweetId" : "1713878690818342942",
      "fullText" : "Molt content de rebre (ex aequo) el premi d'@autogoverncat a millor article publicat! 🥳🥳\nL'article sencer es pot trobar aquí: https://t.co/NaKos5FMDx i un resum en català aquí: https://t.co/E62BQr9O6O\nCongratulations also to @KarloBasta1 @dbchslr @andijot https://t.co/zw2vllOdfP",
      "expandedUrl" : "https://twitter.com/i/web/status/1713878690818342942"
    }
  },
  {
    "like" : {
      "tweetId" : "1712034553559163136",
      "fullText" : "With @vdignum talking at the European Parliamentary Technology Assessment Network about the economic and political implications of generative AI. It was great to see legislators and technicians thinking about how to address this challenge  #EPTA @parlamentcat https://t.co/jHphxPYs2u",
      "expandedUrl" : "https://twitter.com/i/web/status/1712034553559163136"
    }
  },
  {
    "like" : {
      "tweetId" : "1710689948746023401",
      "fullText" : "La Casa Real, que no deja nada al azar, ha querido que Leonor jure antes la bandera que la Constitución.\nLa Nación antes que la democracia.\nEs un error que el Gobierno se lo haya permitido. Un mensaje muy peligroso. https://t.co/hFe1gcFA08",
      "expandedUrl" : "https://twitter.com/i/web/status/1710689948746023401"
    }
  },
  {
    "like" : {
      "tweetId" : "1707678494681968656",
      "fullText" : "Amazing week in Oslo, great people and lots of learning. Many thanks to @arena_uio and the #IUROPA project. https://t.co/XMJr4UgmxL",
      "expandedUrl" : "https://twitter.com/i/web/status/1707678494681968656"
    }
  },
  {
    "like" : {
      "tweetId" : "1707075753320370386",
      "fullText" : "Alba Huidobro Torres y Pau Vall Prat, Premio 'Juan Linz', que ha entregado @emipajares, subdirector de Publicaciones y Documentación del @cepcgob https://t.co/LgzT56trFh",
      "expandedUrl" : "https://twitter.com/i/web/status/1707075753320370386"
    }
  },
  {
    "like" : {
      "tweetId" : "1674524011621908487",
      "fullText" : "Hilo con las subidas de sueldo que se están poniendo PP y Vox nada más tocar sillón. Los que venían a poner fin al despilfarro.\n\n1⃣ Bruno García (PP), nuevo alcalde de Cádiz. +30.000€ de golpe.\nPrácticamente dobla el sueldo de su antecesor. De 38.826,76€ pasa a 68.888 €. https://t.co/uQfXHAKsxc",
      "expandedUrl" : "https://twitter.com/i/web/status/1674524011621908487"
    }
  },
  {
    "like" : {
      "tweetId" : "1703676094363148674",
      "fullText" : "Con mucho gusto el viernes presentamos los resultados del proyecto @METROGOV1. Os esperamos! https://t.co/ZBQcixfpZQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1703676094363148674"
    }
  },
  {
    "like" : {
      "tweetId" : "1703709234406322586",
      "fullText" : "🎉🎉🎉 My first publication is finally out!\n\"Riding the COVID-19 Wave? Issue Attention during the Pandemic\" https://t.co/KXIys0tv6R",
      "expandedUrl" : "https://twitter.com/i/web/status/1703709234406322586"
    }
  },
  {
    "like" : {
      "tweetId" : "1703713357159686322",
      "fullText" : "This week we are kicking off our @CPoliticaUB research seminar for the upcoming fall semester!\nCheck the full program below &amp; join us for exciting talks!\n📅Thursdays, 14:30-15:30\n📌Room A-218, facultat @Dret_UB \n@macarena_ares https://t.co/InC76HL3qI",
      "expandedUrl" : "https://twitter.com/i/web/status/1703713357159686322"
    }
  },
  {
    "like" : {
      "tweetId" : "1702235584310251895",
      "fullText" : "Els peixcadors de cullera. Ara en anglès. https://t.co/OqyFFZzomQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1702235584310251895"
    }
  },
  {
    "like" : {
      "tweetId" : "1699049750153306437",
      "fullText" : "https://t.co/FJm0x6vDoK https://t.co/m700J7CkR0",
      "expandedUrl" : "https://twitter.com/i/web/status/1699049750153306437"
    }
  },
  {
    "like" : {
      "tweetId" : "1701597413067403552",
      "fullText" : "Some personal news, last week I joined @EuropeAtHarvard @harvard as the first Ramón Areces Fellow, and Visiting Scholar for the academic year 2023-24. I’m very much looking forward to exchange ideas with this vibrant community. DM me for a coffee if you’re in the Boston area! https://t.co/yobonjbozS",
      "expandedUrl" : "https://twitter.com/i/web/status/1701597413067403552"
    }
  },
  {
    "like" : {
      "tweetId" : "1701171071687254202",
      "fullText" : "Y se abrirán las grandes alamedas. https://t.co/OV6TOzTH0l",
      "expandedUrl" : "https://twitter.com/i/web/status/1701171071687254202"
    }
  },
  {
    "like" : {
      "tweetId" : "1700191590994608186",
      "fullText" : "No se me ocurre un escenario posible en el que Pablo Motos no termine con un mono naranja en Guantánamo. https://t.co/aY9BFmeLlT",
      "expandedUrl" : "https://twitter.com/i/web/status/1700191590994608186"
    }
  },
  {
    "like" : {
      "tweetId" : "1699769499942109315",
      "fullText" : "Thanks to all the participants in the @ecpr_law_courts  section for a great conference, and a special thanks to the organizers @khalikovayu &amp; @schroeder_pa and of course the panel discussant @benjaminengst! #ecprgc23 @ecpr https://t.co/RQDePsOKku",
      "expandedUrl" : "https://twitter.com/i/web/status/1699769499942109315"
    }
  },
  {
    "like" : {
      "tweetId" : "1699710242332750160",
      "fullText" : "The room is warm. Must be because the presentations are on 🔥. Now we have @Koritchi presenting research on how the party affiliations of lay judges in 🇸🇪  affect their decision making. https://t.co/OcOO82TCgG https://t.co/iklz83rZKj",
      "expandedUrl" : "https://twitter.com/i/web/status/1699710242332750160"
    }
  },
  {
    "like" : {
      "tweetId" : "1699039307196154163",
      "fullText" : "Excellent panel on \"Analyzing legal texts\" at #ecprgc23! https://t.co/AFalLsSdfp https://t.co/jxGOMPtyYf",
      "expandedUrl" : "https://twitter.com/i/web/status/1699039307196154163"
    }
  },
  {
    "like" : {
      "tweetId" : "1698993311397142959",
      "fullText" : "Join us for the panel on \"Analyzing legal texts\"  today at 13:30 with @schroeder_pa, @PSUBRodilla, @benjaminengst, @StefanThierse, and @Kilian_Lueders. Building: A - Faculty of Law, Floor: 3, Room: 347! https://t.co/SSz3oZMoeT",
      "expandedUrl" : "https://twitter.com/i/web/status/1698993311397142959"
    }
  },
  {
    "like" : {
      "tweetId" : "1698579018151268475",
      "fullText" : "The in-person fun continues with the panel on \"Analyzing legal texts\" on Tuesday at 13:30 chaired by @schroeder_pa and with presentations by @PSUBRodilla, @benjaminengst, @StefanThierse, and @Kilian_Lueders. Building: A - Faculty of Law, Floor: 3, Room: 347! https://t.co/6K4nE9UAzX",
      "expandedUrl" : "https://twitter.com/i/web/status/1698579018151268475"
    }
  },
  {
    "like" : {
      "tweetId" : "1697548224523895017",
      "fullText" : "Convoquem dues beques per a graduats recents o estudiants de darrer curs de grau per realitzar el postgrau d'anàlisi de dades sociopolítiques a @CPoliticaUB -la beca cobreix el 75% de la matrícula. Termini 3 de setembre. Més informació:  https://t.co/PTMPuRRyrO",
      "expandedUrl" : "https://twitter.com/i/web/status/1697548224523895017"
    }
  },
  {
    "like" : {
      "tweetId" : "1697009799001436306",
      "fullText" : "El PP lleva ya 1.728 días incumpliendo la Constitución al bloquear la renovación del Consejo General del Poder Judicial.",
      "expandedUrl" : "https://twitter.com/i/web/status/1697009799001436306"
    }
  },
  {
    "like" : {
      "tweetId" : "1696610774603440491",
      "fullText" : "Válido en 1931, válido en 2023. https://t.co/IY7iUmSgpI https://t.co/WDt6BQlZaI",
      "expandedUrl" : "https://twitter.com/i/web/status/1696610774603440491"
    }
  },
  {
    "like" : {
      "tweetId" : "1696940545040400538",
      "fullText" : "https://t.co/AQajBJh7Mm",
      "expandedUrl" : "https://twitter.com/i/web/status/1696940545040400538"
    }
  },
  {
    "like" : {
      "tweetId" : "1694053031736725557",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1694053031736725557"
    }
  },
  {
    "like" : {
      "tweetId" : "1689366849408913409",
      "fullText" : "Jajajajaja em desorine https://t.co/sRM5RbDKNr",
      "expandedUrl" : "https://twitter.com/i/web/status/1689366849408913409"
    }
  },
  {
    "like" : {
      "tweetId" : "1687083354246512640",
      "fullText" : "🔴ÚLTIMA HORA | Cierre total a la carretera de los Lagos de Covadonga para coches y caravanas\n\nLa medida durará todo el año y entrará en vigor en los próximos días\n\n@RTVEAsturias \n\n⏯️https://t.co/lMToc173VA https://t.co/fC8IZGaWHE",
      "expandedUrl" : "https://twitter.com/i/web/status/1687083354246512640"
    }
  },
  {
    "like" : {
      "tweetId" : "1685941881841045504",
      "fullText" : "I am thrilled to announce that I will be joining @politiquesUPF as a Marie Skłodowska-Curie postdoctoral fellow next month with a project examining the influence of domestic political institutions on maximalist state claims. Molt agraït per tot el suport i amb molta il·lusió. 🙂",
      "expandedUrl" : "https://twitter.com/i/web/status/1685941881841045504"
    }
  },
  {
    "like" : {
      "tweetId" : "1685718383742832642",
      "fullText" : "Paradigma del zasca epistolar. 😊\n\n“Estimado Alberto: Agradezco la oportunidad que me brinda su carta para retomar la comunicación  interrumpida de manera abrupta y unilateral con la ruptura del preacuerdo para la renovación del CGPJ, que lleva pendiente más de cuatro años…” https://t.co/TdajFovIvf",
      "expandedUrl" : "https://twitter.com/i/web/status/1685718383742832642"
    }
  },
  {
    "like" : {
      "tweetId" : "1684897352572682240",
      "fullText" : "I have been awarded the Juan Linz prize for the best dissertation in Political Science (by @cepcgob). The best part, it was ex aequo with my beloved friend and great scholar @albahuidobro.🥳\nInfinite gratitude to my advisors @cescamat @jordimunozm @pepvallbe at @CPoliticaUB https://t.co/EYnuOAsvqm",
      "expandedUrl" : "https://twitter.com/i/web/status/1684897352572682240"
    }
  },
  {
    "like" : {
      "tweetId" : "1683458053797027840",
      "fullText" : "Zapatero no se cansa de dar lecciones. Es increíble.\n\n https://t.co/qxlj8qbVPU",
      "expandedUrl" : "https://twitter.com/i/web/status/1683458053797027840"
    }
  },
  {
    "like" : {
      "tweetId" : "1683399117291278336",
      "fullText" : "‼️ EH Bildu cumple su palabra: por nosotros y nosotras no será; si depende de EH Bildu, no habrá gobierno del bloque reaccionario en el Estado español.\n\n@MertxeAizpurua: «Vamos a trabajar para construir una alternativa a la derecha. Es posible».\n\n#EginDugu https://t.co/OBZIe6N9tz",
      "expandedUrl" : "https://twitter.com/i/web/status/1683399117291278336"
    }
  },
  {
    "like" : {
      "tweetId" : "1683222330040897536",
      "fullText" : "El Emérito volviendo a España. https://t.co/fdij3rKH6U",
      "expandedUrl" : "https://twitter.com/i/web/status/1683222330040897536"
    }
  },
  {
    "like" : {
      "tweetId" : "1683081718603939841",
      "fullText" : "Ojalá seamos conscientes de la importancia que tiene el día de hoy para el futuro. Para cuidar nuestros derechos humanos y seguir creciendo. \nOs animo a votar, votemos a favor del progreso.",
      "expandedUrl" : "https://twitter.com/i/web/status/1683081718603939841"
    }
  },
  {
    "like" : {
      "tweetId" : "1683030031436488704",
      "fullText" : "A votar con alegría y optimismo. También con dudas, si se quiere, o por responsabilidad. Por convicción o por temor a que entre el fascismo. Pero que nadie, nadie se quede en casa y permita que nos roben la sanidad, la educación, la cultura, la justicia,  los derechos...",
      "expandedUrl" : "https://twitter.com/i/web/status/1683030031436488704"
    }
  },
  {
    "like" : {
      "tweetId" : "1682145422251270146",
      "fullText" : "En estas elecciones ha sido evidente mi postura contra partidos antiderechos como PP y VOX. \n\nEso ha generado “sorpresa” entre algunas personas de Venezuela. No entiendo el porqué si saben que soy gay y migrante.\n\nAbro hilo sobre #migración 🇻🇪 en 🇪🇸.",
      "expandedUrl" : "https://twitter.com/i/web/status/1682145422251270146"
    }
  },
  {
    "like" : {
      "tweetId" : "1682361945339379721",
      "fullText" : "¿Pero quién hace estas maravillas? https://t.co/eFQ1HDxEv9",
      "expandedUrl" : "https://twitter.com/i/web/status/1682361945339379721"
    }
  },
  {
    "like" : {
      "tweetId" : "1682396611018727424",
      "fullText" : "NOS VAMOS A VOTAR!!! https://t.co/67nHNyH0Qf",
      "expandedUrl" : "https://twitter.com/i/web/status/1682396611018727424"
    }
  },
  {
    "like" : {
      "tweetId" : "1682340703953641472",
      "fullText" : "Happy to see this article out on @RepJournal\n\n'The effect of ideological distance on voting behaviour in parliament under changing economic conditions: a comparison btw Portugal and Spain'\n\nby A. Palau @munozmarquezluz @joaoc &amp; myself\n\nFREE copies here 👇\n\nhttps://t.co/wfIjfeLtX9 https://t.co/CHh2NrfyKz",
      "expandedUrl" : "https://twitter.com/i/web/status/1682340703953641472"
    }
  },
  {
    "like" : {
      "tweetId" : "1682162163232718853",
      "fullText" : "Cuando vives en un mundo donde se normaliza que se deje de atender a 7.000 ancianos que murieron en las residencias sin trasladarlos a centros hospitalarios según lo que se conoce como los \"protocolos de la vergüenza\" no me extraña que las cosas cotidianas te descoloquen un poco. https://t.co/eOYrjhoAwG",
      "expandedUrl" : "https://twitter.com/i/web/status/1682162163232718853"
    }
  },
  {
    "like" : {
      "tweetId" : "1681970090625888260",
      "expandedUrl" : "https://twitter.com/i/web/status/1681970090625888260"
    }
  },
  {
    "like" : {
      "tweetId" : "1681763075303833601",
      "fullText" : "Yolanda está 🔥🔥🔥 #DebateFinalRTVE",
      "expandedUrl" : "https://twitter.com/i/web/status/1681763075303833601"
    }
  },
  {
    "like" : {
      "tweetId" : "1681587208661106688",
      "fullText" : "Nunca he podido soportar a los mentirosos. Lo saben los que me conocen y los que han trabajado para mí.\n\nSi calumnian al adversario con lo más abyecto o mienten, es para tangarte y que votes en contra de tus propios intereses.",
      "expandedUrl" : "https://twitter.com/i/web/status/1681587208661106688"
    }
  },
  {
    "like" : {
      "tweetId" : "1681634456245878784",
      "fullText" : "He oído alguien en Correos que votaba un partido sin relevancia porque no cree en nadie. Si \"nadie\" son personas LGTBI+, víctimas de violencia machista, personas de salario mínimo, migrantes, entonces su problema no es creer, es su falta de solidaridad y sentido de comunidad.",
      "expandedUrl" : "https://twitter.com/i/web/status/1681634456245878784"
    }
  },
  {
    "like" : {
      "tweetId" : "1679613089358946305",
      "fullText" : "Populist gov, judicial independence, and public trust in the courts. Just out. With @PCMagalhaes. Yes, populist gov decrease public trust in the courts. On average. But not for everyone. https://t.co/xy37NX3nCa",
      "expandedUrl" : "https://twitter.com/i/web/status/1679613089358946305"
    }
  },
  {
    "like" : {
      "tweetId" : "1679119681725014017",
      "fullText" : "PP está intentando eliminar este vídeo de las redes.\nAlgunas de las numerosas, brutales y flagrantes mentiras de Feijóo en el 'cara a cara' con Pedro Sánchez.\n\nNo difundáis el video bajo ningún concepto, que el PP no quiere. 😏 https://t.co/c3uRmb9qYd",
      "expandedUrl" : "https://twitter.com/i/web/status/1679119681725014017"
    }
  },
  {
    "like" : {
      "tweetId" : "1679409770942418945",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1679409770942418945"
    }
  },
  {
    "like" : {
      "tweetId" : "1678366851112288260",
      "fullText" : "Vota. O no votes. O sé un cuñado y mete una loncha de chorizo en la papeleta y monta el numerito. Pero no digas que un gobierno fascista con ministros de VOX será un revulsivo para que la clase obrera despierte. El cuanto peor mejor, es una falacia histórica refutada 1M de veces.",
      "expandedUrl" : "https://twitter.com/i/web/status/1678366851112288260"
    }
  },
  {
    "like" : {
      "tweetId" : "1678293325315551232",
      "fullText" : "Los guardias civiles que hemos tenido que mirar muchos años debajo de nuestro coche sabemos que el momento actual no es más difícil que cuando ETA mataba. Los familiares de las víctimas de ETA también lo saben. Ya está bien de tanta inmundicia. https://t.co/f1jQ44rIE9",
      "expandedUrl" : "https://twitter.com/i/web/status/1678293325315551232"
    }
  },
  {
    "like" : {
      "tweetId" : "1677933299593801729",
      "fullText" : "Salimos a ganar. https://t.co/rc9FsUUE7g",
      "expandedUrl" : "https://twitter.com/i/web/status/1677933299593801729"
    }
  },
  {
    "like" : {
      "tweetId" : "1676217590794911744",
      "fullText" : "Las dos Españas.  Una mira atrás, a Franco, a Hitler, está muerta.  La otra no sabe quizás dónde mirar, pero está viva. No hay dos Españas. Hay una España viva y otra muerta… https://t.co/P5i84pjFnK",
      "expandedUrl" : "https://twitter.com/i/web/status/1676217590794911744"
    }
  },
  {
    "like" : {
      "tweetId" : "1675866697255854080",
      "fullText" : "Professional news! (and a tired post-moving selfie ☺️😴)\nI am happy to start working as a postdoctoral researcher at @sa_engler's Chair of Comparative Politics at @leuphana! Next to an exciting new chapter as a researcher, on a more private note, ... https://t.co/Hak1HOOGUj",
      "expandedUrl" : "https://twitter.com/i/web/status/1675866697255854080"
    }
  },
  {
    "like" : {
      "tweetId" : "1675787262343229443",
      "fullText" : "Article online 👇\nDifferent sides, same story. Common factors that contributed to the success of the populist radical parties in Spain\nÁlvaro Sánchez-García &amp; Imanol Negral👇https://t.co/O3a0e6lRe9",
      "expandedUrl" : "https://twitter.com/i/web/status/1675787262343229443"
    }
  },
  {
    "like" : {
      "tweetId" : "1674730565294071809",
      "fullText" : "Today we are hosting at @PolitiquesUAB the VIII Workshop on Empirical Political Science. A nice opportunity for knowing about young scholars’ projects and sharing knowledge!\n\nThanks to everyone for coming and participating! https://t.co/c6gwSvSxRK",
      "expandedUrl" : "https://twitter.com/i/web/status/1674730565294071809"
    }
  },
  {
    "like" : {
      "tweetId" : "1672628379646926848",
      "fullText" : "As always, @europsa was a combination of lots of fun, amazing papers, and many (new and old) friends. See you next year! #EPSA2023 #EPSAphotocomp23 https://t.co/TjjI28rwpD",
      "expandedUrl" : "https://twitter.com/i/web/status/1672628379646926848"
    }
  },
  {
    "like" : {
      "tweetId" : "1669367973314740228",
      "fullText" : "En Valencia ha funcionado la 'fórmula virtuosa' que la derecha busca conseguir el 23-J. Mi análisis de hoy en @elpais_opinion https://t.co/2WVmm4GCzV @a_publica https://t.co/LJfurbqkJe",
      "expandedUrl" : "https://twitter.com/i/web/status/1669367973314740228"
    }
  },
  {
    "like" : {
      "tweetId" : "1668253135431663617",
      "fullText" : "Si voleu treballar a #Rstats amb les dades de totes les enquestes que es van publicant sobre les eleccions generals espanyoles, podeu utilitzar aquest codi i en dues línies tindreu un data frame llest per utilitzar #deres https://t.co/3oqz5btFxD",
      "expandedUrl" : "https://twitter.com/i/web/status/1668253135431663617"
    }
  },
  {
    "like" : {
      "tweetId" : "1666824551928397826",
      "fullText" : "L’àudio dels pescadors de Cullera queda pràcticament bé on el poses. Però en este video és pura màgia. 🥘 https://t.co/ztDFF3fZuD",
      "expandedUrl" : "https://twitter.com/i/web/status/1666824551928397826"
    }
  },
  {
    "like" : {
      "tweetId" : "1666437350929432578",
      "fullText" : "El poder y la corrupción de algunos partidos políticos, de parte de la judicatura y de los medios de comunicación lo permiten y lo otorgan los ciudadanos/as con su voto.\n\nMónica Oltra.\n https://t.co/4cEPi1WQ5R",
      "expandedUrl" : "https://twitter.com/i/web/status/1666437350929432578"
    }
  },
  {
    "like" : {
      "tweetId" : "1666415472777089025",
      "fullText" : "Pásalo https://t.co/QBgkYG7zUw",
      "expandedUrl" : "https://twitter.com/i/web/status/1666415472777089025"
    }
  },
  {
    "like" : {
      "tweetId" : "1666384047751217154",
      "fullText" : "Hola @cristina_pardo Vas a pedir disculpas por el daño cometido contra Mónica Oltra, o vas a seguir señalando a gente sin pruebas? Tu sonrisa cínica lo dice todo sobre tí. Ética periodista 0. https://t.co/oxw0eHAa7S",
      "expandedUrl" : "https://twitter.com/i/web/status/1666384047751217154"
    }
  },
  {
    "like" : {
      "tweetId" : "1663898671518236673",
      "fullText" : "Muy apropiado el nuevo inicio de “El Hormiguero”.\nhttps://t.co/pQtD4Yp5xK",
      "expandedUrl" : "https://twitter.com/i/web/status/1663898671518236673"
    }
  },
  {
    "like" : {
      "tweetId" : "1662098017766240256",
      "fullText" : "Mi prima ha aprobado una oposición. Se muda de ciudad a donde le han dado la plaza. ¿Sueldo? 1300.\n¿Alquiler? 900.\nLa otra opción era renunciar al trabajo.\n\nPero el problema es ETA.",
      "expandedUrl" : "https://twitter.com/i/web/status/1662098017766240256"
    }
  },
  {
    "like" : {
      "tweetId" : "1661309675969601536",
      "fullText" : "Are you an early career researcher interested in working with data on law and courts?\nCome join us in Oslo in September for the 2nd edition of the IUROPA Law and Courts workshop (funding available)! https://t.co/1kpyWG8dxX",
      "expandedUrl" : "https://twitter.com/i/web/status/1661309675969601536"
    }
  },
  {
    "like" : {
      "tweetId" : "1658220030901747714",
      "fullText" : "Estos ultraderechistas cayetanos del Espanyol se llaman Yago Darnell y Carlos Ferrer-Calbetó y eran candidatos del PP en Cerdanyola y Sant Joan Despí. Saltaron al campo en la celebración del FC Barcelona. Sus colegas fachas me están amenanzando por mostrar sus caras. Qué rulen. https://t.co/ey8JEn3gPG",
      "expandedUrl" : "https://twitter.com/i/web/status/1658220030901747714"
    }
  },
  {
    "like" : {
      "tweetId" : "1658355036307480579",
      "fullText" : "\"Militar de la Guardia Real en excedencia y concejala candidata de Vox, acusados de vender droga todos los días a cualquier hora. En la web del partido era responsable de calidad, compras y RRHH. Lamentaba que los okupas traen problemas de narcotráfico\" https://t.co/beZGsbG6Sw https://t.co/TIE4Dx9YeO",
      "expandedUrl" : "https://twitter.com/i/web/status/1658355036307480579"
    }
  },
  {
    "like" : {
      "tweetId" : "1657287503060119554",
      "fullText" : "🔴 Coses que encara no havies vist de la manifestació de Desokupa a Bonanova, que t'ajudaran a entendre la campanya de la por i que no et sorprendran. Aquí 🧵 https://t.co/AxdY8mKYu1",
      "expandedUrl" : "https://twitter.com/i/web/status/1657287503060119554"
    }
  },
  {
    "like" : {
      "tweetId" : "1656970679068098561",
      "fullText" : "Finalmente una toma basada en datos sobre el \"problema\" de ocupación en España.\n\nSpoiler: No hay problema de ocupación en España https://t.co/FvZRkPabpp",
      "expandedUrl" : "https://twitter.com/i/web/status/1656970679068098561"
    }
  },
  {
    "like" : {
      "tweetId" : "1655467571364380672",
      "fullText" : "Inflación energética 👇🏼\n\nUK🇬🇧: 48.3\nTurquía🇹🇷: 42.2\nRep. Checa🇨🇿: 33.8\nPolonia 🇵🇱: 31\nItalia🇮🇹: 28.2\nAlemania🇩🇪: 20\nEU🇪🇺: 16.6\nFrancia🇫🇷: 14\nChile🇨🇱: 13.2\nKorea🇰🇷: 11.5\nEEUU🇺🇸: 5.2\nMexico🇲🇽: 1.6\nCanada🇨🇦: -0.6\nJapón🇯🇵: -0.7\nEspaña🇪🇸: -8.9\n\nY le llamaban “timo ibérico” 😅 https://t.co/W34hvkfNgA",
      "expandedUrl" : "https://twitter.com/i/web/status/1655467571364380672"
    }
  },
  {
    "like" : {
      "tweetId" : "1655243227216109569",
      "fullText" : "20/ Esta tesis aporta nuevas herramientas y bases de datos para analizar los medios de comunicación y su impacto en la opinión pública. Mientras se publica, tienes aquí un esquema de todas sus páginas y capítulos. Mañana la defiendo. https://t.co/3xev48zrjo https://t.co/XyUeqIeEag",
      "expandedUrl" : "https://twitter.com/i/web/status/1655243227216109569"
    }
  },
  {
    "like" : {
      "tweetId" : "1649729644810084352",
      "fullText" : "Las próximas elecciones son mucho más importantes de lo que pueda parecer. O la izquierda se deja de boberías y se unen de una vez o lo presentamos.\n\nUstedes verán lo que hacen… https://t.co/ikj3ZX4e9Y",
      "expandedUrl" : "https://twitter.com/i/web/status/1649729644810084352"
    }
  },
  {
    "like" : {
      "tweetId" : "1649427568280367105",
      "fullText" : "Fent un teletubbie amb Santiago Abascal. https://t.co/EkYmYjIBKd",
      "expandedUrl" : "https://twitter.com/i/web/status/1649427568280367105"
    }
  },
  {
    "like" : {
      "tweetId" : "1649686979271958533",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1649686979271958533"
    }
  },
  {
    "like" : {
      "tweetId" : "1649069839296737286",
      "fullText" : "Much enjoyed questions and discussions with students and faculty at the beautiful @CPoliticaUB on the implications of AI for the study of politics and political communication. \n\nThanks @laiacastroh and @macarena_ares for the invitation 🙏🏽 https://t.co/MmVCd1SVFj",
      "expandedUrl" : "https://twitter.com/i/web/status/1649069839296737286"
    }
  },
  {
    "like" : {
      "tweetId" : "1646621257406840837",
      "fullText" : "¡¡Salud y República!!\n\nFriday is the 92nd anniversary of the proclamation of Spain's Second Republic. \n\nWe’re proud as ever that our Away shirt pays tribute to those who fought to defend democracy &amp; we’d love to see friends &amp; fans posting their shirts. ✊ https://t.co/NcKs2Zgz7i",
      "expandedUrl" : "https://twitter.com/i/web/status/1646621257406840837"
    }
  },
  {
    "like" : {
      "tweetId" : "1645700856350756864",
      "fullText" : "Ni oblit ni perdó!\n\n#30Anys30Guillems #30anysambtu https://t.co/pUGfwrLEAQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1645700856350756864"
    }
  },
  {
    "like" : {
      "tweetId" : "1641152310867787797",
      "fullText" : "🚨🥳I'm really thrilled to see my article \"In troubled waters, conservatives gain: An analysis of depopulation and electoral behaviour in the heart of Empty Spain\" with @tonirodon published in the @rep_cepc. \n\n📎https://t.co/AgysIfcnWb",
      "expandedUrl" : "https://twitter.com/i/web/status/1641152310867787797"
    }
  },
  {
    "like" : {
      "tweetId" : "1639253019345969154",
      "fullText" : "Este es el primer de (espero) muchos artículos en la revista referente de los militantes del @PSUC_Viu. https://t.co/ITiXHPdFM4",
      "expandedUrl" : "https://twitter.com/i/web/status/1639253019345969154"
    }
  },
  {
    "like" : {
      "tweetId" : "1639912718911131650",
      "fullText" : "Alberto Núñez Feijóo sufre el síndrome del presidente interino. ¿Os acordáis de Guaidó? Pues eso. Esta enfermedad, por la que ya pasó el Pablo Casado que pasaba revista a tropas de trabajadores del Ayuntamiento de Madrid, te obliga a comportarte como presidente sin serlo (...)",
      "expandedUrl" : "https://twitter.com/i/web/status/1639912718911131650"
    }
  },
  {
    "like" : {
      "tweetId" : "1638586454136832000",
      "fullText" : "Entrepà de botifarra d'ou amb carxofa i moniato fregit https://t.co/CpmKfkoKN8",
      "expandedUrl" : "https://twitter.com/i/web/status/1638586454136832000"
    }
  },
  {
    "like" : {
      "tweetId" : "1636093572242980866",
      "fullText" : "Aldeanos ofrenant glòries a Madrid.😄😄😄😄 Foto: unkown. https://t.co/aw7FDGWe8o",
      "expandedUrl" : "https://twitter.com/i/web/status/1636093572242980866"
    }
  },
  {
    "like" : {
      "tweetId" : "1634502512395841538",
      "fullText" : "-Hoy especialmente quiero recordar a Pilar Manjón @PlarManjon . que perdió a su hijo el 11-M. Lo que pasó no se lo deseo a ningún padre/madre. Esto solo es un extracto del acoso BRUTAL que sufrió por parte de la derecha PP de este país #NiOlvidoNiPerdon https://t.co/u8rPGPBmgF",
      "expandedUrl" : "https://twitter.com/i/web/status/1634502512395841538"
    }
  },
  {
    "like" : {
      "tweetId" : "1631894205764366337",
      "fullText" : "Finally attending an offline hackathon and guess what Zerodha’s CTO Kailash Nadh is in the same room! 🤯\n\nSaw him first on ScalerPod with @championswimmer and now I’m having my first celebrity fan moment! \n\n#FossHack #FossHack2023 https://t.co/nytGbJHVTj",
      "expandedUrl" : "https://twitter.com/i/web/status/1631894205764366337"
    }
  },
  {
    "like" : {
      "tweetId" : "1630613690868285446",
      "fullText" : "Weekly reminder that correlation does not imply causation.\n\nThat's the tweet.",
      "expandedUrl" : "https://twitter.com/i/web/status/1630613690868285446"
    }
  },
  {
    "like" : {
      "tweetId" : "1630128702104260608",
      "fullText" : "📢 We are looking forward to receiving @RIBernhard at our departmental seminar this Thursday!\nShe will be presenting \"Alphabet Soup: Ballot Order \nGender- and Ethnicity-Based Voter Biases\".\n📅Thursday 2/3/23, 14:30\n📌A-218 \n@Dret_UB \nJoin us! https://t.co/LC6OLbH5dA",
      "expandedUrl" : "https://twitter.com/i/web/status/1630128702104260608"
    }
  },
  {
    "like" : {
      "tweetId" : "1628004314093346816",
      "fullText" : "\"Manuscript accepted\" and here we go! Congratulations to all of you @AlbertoBueno_ @calatravag and Rafa Martinez https://t.co/xN2LpivuGv",
      "expandedUrl" : "https://twitter.com/i/web/status/1628004314093346816"
    }
  },
  {
    "like" : {
      "tweetId" : "1625776790043037698",
      "fullText" : "How to use ChatGPT ethically to write a perfect first draft (of your journal article, dissertation chapter, etc.):",
      "expandedUrl" : "https://twitter.com/i/web/status/1625776790043037698"
    }
  },
  {
    "like" : {
      "tweetId" : "1620044905543520256",
      "fullText" : "Happy to be in a department that is doing cutting-edge research, as the one Xavier Fernández-i-Marin is presenting at a reading group today at @CPoliticaUB https://t.co/TCtYLyvI5h",
      "expandedUrl" : "https://twitter.com/i/web/status/1620044905543520256"
    }
  },
  {
    "like" : {
      "tweetId" : "1619997436902256640",
      "fullText" : "I am incredible proud that we are now able to publish the first version of the IUROPA CJEU Database, the most comprehensive research-oriented database on the Court of Justice of the EU: https://t.co/5g9Tr6q50z https://t.co/mK45WOM57X",
      "expandedUrl" : "https://twitter.com/i/web/status/1619997436902256640"
    }
  },
  {
    "like" : {
      "tweetId" : "1618982538793611265",
      "fullText" : "Gracias @rosaborgeb, @balcells_joan, @apadro_solanet por invitarnos a presentar el proyecto Adsom en esta excelente jornada. Con muchas ganas de seguir colaborando en el estudio de redes sociales y calidad de la democracia. https://t.co/AZEZM0qYnY",
      "expandedUrl" : "https://twitter.com/i/web/status/1618982538793611265"
    }
  }
]