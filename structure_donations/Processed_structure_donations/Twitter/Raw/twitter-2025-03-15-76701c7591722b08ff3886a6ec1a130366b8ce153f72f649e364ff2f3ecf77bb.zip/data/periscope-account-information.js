window.YTD.periscope_account_information.part0 = [
  {
    "periscopeAccountInformation" : {
      "displayName" : "Rodilla",
      "digitsId" : "",
      "username" : "PSUBRodilla",
      "twitterId" : "1312048977538437120",
      "id" : "1PmKqVMYMpGjo",
      "twitterScreenName" : "PSUBRodilla",
      "isTwitterUser" : true,
      "createdAt" : "2022-03-29T20:35:10.756797706Z"
    }
  }
]