window.YTD.key_registry.part0 = [
  {
    "keyRegistryData" : {
      "userId" : "1312048977538437120",
      "registeredDevices" : {
        "deviceMetadataList" : [
          {
            "userAgent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36",
            "registrationToken" : "c361e7e281767b4e4191aaa711705dea",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEZvBekCx5Ze5BiTKa82rx8H7Rwq1NNdwi20W6JYdNa8fIwSi0aO3V2o1br/M5SQPNOxhVxdYFnRp2GQmnWrdVHQ==",
            "createdAt" : "2023-10-26T09:41:11.707Z",
            "deviceId" : "404e3298-ae6c-4da3-b704-1476bd7f31fb"
          },
          {
            "userAgent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
            "registrationToken" : "7cc7dde2e7be6e21aab9e0305c379c50",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEf27mRg7zfzCivm8ytaBjq3/eK2M9uDgk9AvME3G+PJ8eHjfx4d4U5xkcY39TrX8yGggHm+CZOoOHDHa7kpFPcA==",
            "createdAt" : "2024-10-24T14:19:08.887Z",
            "deviceId" : "6f49e150-8cdb-4599-b5e1-f3042df36e2d"
          },
          {
            "userAgent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0",
            "registrationToken" : "94c4cc6980c6278c80d2f3a9cbd59346",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE8mGcmjH7jQvxK81tGYtb0mQ9kZ0TryPRrD4mix1d2AUcM31YUsdQ/XyBNL6xbhWruBaR2/Sov3LrpAES/51R8Q==",
            "createdAt" : "2024-10-24T14:24:58.405Z",
            "deviceId" : "91444e03-c775-4d15-845b-1c548c4482b5"
          },
          {
            "userAgent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
            "registrationToken" : "12019b776260e6cb4b1525f760d768c4",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAErZGRFcixUlyiHnEK8AblaYqWfnYx0LsAqV1y4JR/Qy+bUuA9Y89DTmT381rJsDRIV2dgjw+Q4KYl4HCpO9MXKg==",
            "createdAt" : "2023-08-02T11:30:09.139Z",
            "deviceId" : "b5ac51d1-9c6c-47cd-ab8e-3d2ff911d07a"
          },
          {
            "userAgent" : "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36",
            "registrationToken" : "e6fddd995313fbd2e76741863b6dad14",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEcWOh1ZP0WVhlDzMaT0dBrvbnLLpy5h8/FZCFJ5wani8d/qbdIbc3RzloNR0Gt5x/z+Sx2RQjJFXdLCPPm3SQHQ==",
            "createdAt" : "2025-02-09T20:13:42.763Z",
            "deviceId" : "df0faab3-d171-454c-aaaf-9264d67153a1"
          },
          {
            "userAgent" : "TwitterAndroid/9.87.0-release.0 (29870000-r-0) M2102J20SG/12 (Xiaomi;M2102J20SG;POCO;vayu_global;0;;1;2016)",
            "registrationToken" : "c1b5857b8175117749a11dd5083449a5",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEaFq/c29woXZUFtr3YziHAkSYsziEXq2jpfErr8W4bfWYWR/1NNtcDJ2TcopBATX1n1+DRs05lX52AT6d8u5+sA==",
            "createdAt" : "2023-05-08T18:18:14.676Z",
            "deviceId" : "e00a5823-e639-4057-adec-da236b6af0b5"
          },
          {
            "userAgent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "registrationToken" : "1732a9a08756a36e3a34bfb4f37099a6",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEmNO+E2Aj6ruQma8S8w6aURfU9+gOctHsvv2aTOEOh2hXOvrgiczYTjSzmrwILcWSSByFMckRDRR2P+T9Fataaw==",
            "createdAt" : "2024-05-06T10:10:18.499Z",
            "deviceId" : "e8eaadea-4938-41b9-a390-e6a4cba7cf6d"
          }
        ]
      },
      "deregisteredDevices" : {
        "deRegisteredDeviceMetadataList" : [ ]
      }
    }
  }
]