window.YTD.tweets.part0 = [
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1892553760213188976"
          ],
          "editableUntil" : "2025-02-20T13:35:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/t8bxc8SFYt",
            "expanded_url" : "https://papers.ssrn.com/sol3/papers.cfm?abstract_id=5124478",
            "display_url" : "papers.ssrn.com/sol3/papers.cf…",
            "indices" : [
              "243",
              "266"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "266"
      ],
      "favorite_count" : "10",
      "id_str" : "1892553760213188976",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1892553760213188976",
      "possibly_sensitive" : false,
      "created_at" : "Thu Feb 20 12:35:53 +0000 2025",
      "favorited" : false,
      "full_text" : "📢 New Preprint Alert! 📢\nI am excited to share the preprint summarizing the results of research conducted with my excellent colleague and host Athur Dyevre (KU Leuven):\n\n\"Ideological Polarization on Constitutional Courts: Evidence from Spain\"\n\nhttps://t.co/t8bxc8SFYt",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867251140670214210"
          ],
          "editableUntil" : "2024-12-12T17:52:18.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Toni Rodon",
            "screen_name" : "tonirodon",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1084732873670828032",
            "id" : "1084732873670828032"
          },
          {
            "name" : "UPF Ciències Polítiques i Socials",
            "screen_name" : "PolitiquesUPF",
            "indices" : [
              "11",
              "25"
            ],
            "id_str" : "1270657910",
            "id" : "1270657910"
          },
          {
            "name" : "UPF Barcelona",
            "screen_name" : "UPFBarcelona",
            "indices" : [
              "26",
              "39"
            ],
            "id_str" : "241191056",
            "id" : "241191056"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "56"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1867221377520185509",
      "id_str" : "1867251140670214210",
      "in_reply_to_user_id" : "1084732873670828032",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867251140670214210",
      "in_reply_to_status_id" : "1867221377520185509",
      "created_at" : "Thu Dec 12 16:52:18 +0000 2024",
      "favorited" : false,
      "full_text" : "@tonirodon @PolitiquesUPF @UPFBarcelona Enhorabona Toni!",
      "lang" : "pt",
      "in_reply_to_screen_name" : "tonirodon",
      "in_reply_to_user_id_str" : "1084732873670828032"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1857078183167762874"
          ],
          "editableUntil" : "2024-11-14T16:08:36.368Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Luz Muñoz-Marquez",
            "screen_name" : "munozmarquezluz",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "130432576",
            "id" : "130432576"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1857078183167762874",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1857078183167762874",
      "created_at" : "Thu Nov 14 15:08:36 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @munozmarquezluz: How partisan preferences and strategic behaviour related to the composition of the court  explain the constitutional c…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1853033566227030334"
          ],
          "editableUntil" : "2024-11-03T12:16:44.544Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "gerardo tecé",
            "screen_name" : "gerardotc",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "20909329",
            "id" : "20909329"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1853033566227030334",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1853033566227030334",
      "created_at" : "Sun Nov 03 11:16:44 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @gerardotc: Valencia como parque de atracciones de la ultraderecha.\n\nEstos días en las calles de Valencia hay miles de personas arrimand…",
      "lang" : "es"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1849380108722728968"
          ],
          "editableUntil" : "2024-10-24T10:19:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1849373700442804710",
      "id_str" : "1849380108722728968",
      "in_reply_to_user_id" : "1469332098825732098",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1849380108722728968",
      "in_reply_to_status_id" : "1849373700442804710",
      "created_at" : "Thu Oct 24 09:19:12 +0000 2024",
      "favorited" : false,
      "full_text" : "@jtudcis 🙌🙌🙌🙌🙌🙌 Me n'alegro molt Juli!",
      "lang" : "nl",
      "in_reply_to_user_id_str" : "1469332098825732098"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1838975443585937724"
          ],
          "editableUntil" : "2024-09-25T17:14:46.919Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Sindicato de Inquilinas e Inquilinos de Madrid",
            "screen_name" : "InquilinatoMad",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "856801009905147904",
            "id" : "856801009905147904"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1838975443585937724",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1838975443585937724",
      "created_at" : "Wed Sep 25 16:14:46 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @InquilinatoMad: El 13 de octubre tomamos las calles y ahí empezará todo. Esto no puede ser una manifestación más y, para eso, tenemos q…",
      "lang" : "es"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1836474335009140768"
          ],
          "editableUntil" : "2024-09-18T19:36:16.166Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "EnsQuedem",
            "indices" : [
              "86",
              "96"
            ]
          },
          {
            "text" : "AbaixemElsLloguers",
            "indices" : [
              "97",
              "116"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Sindicat de Llogateres i Llogaters",
            "screen_name" : "SindicatLloguer",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "854361921277046784",
            "id" : "854361921277046784"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "116"
      ],
      "favorite_count" : "0",
      "id_str" : "1836474335009140768",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1836474335009140768",
      "created_at" : "Wed Sep 18 18:36:16 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @SindicatLloguer: La gent no pot pagar. Hem de caminar cap a la vaga de lloguers.\n\n#EnsQuedem\n#AbaixemElsLloguers",
      "lang" : "ca"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1836474116511007202"
          ],
          "editableUntil" : "2024-09-18T19:35:24.072Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "bàsics",
            "screen_name" : "basicsbtv",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "3543404475",
            "id" : "3543404475"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1836474116511007202",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1836474116511007202",
      "created_at" : "Wed Sep 18 18:35:24 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @basicsbtv: \"Cada vegada hi ha gent més farta dels preus dels lloguers, perquè no els pot pagar. Ens plantegem seriosament caminar cap a…",
      "lang" : "ca"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1836431169279185056"
          ],
          "editableUntil" : "2024-09-18T16:44:44.654Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Sindicat de Llogateres i Llogaters",
            "screen_name" : "SindicatLloguer",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "854361921277046784",
            "id" : "854361921277046784"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1836431169279185056",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1836431169279185056",
      "created_at" : "Wed Sep 18 15:44:44 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @SindicatLloguer: Mentre tanquen la porta a defensar un dret bàsic, Barcelona es transforma en la capital de l'especulació i el parasiti…",
      "lang" : "ca"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1833464373274194296"
          ],
          "editableUntil" : "2024-09-10T12:15:45.366Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Laia Castro",
            "screen_name" : "laiacastroh",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "117104237",
            "id" : "117104237"
          },
          {
            "name" : "Ciència Política UB",
            "screen_name" : "CPoliticaUB",
            "indices" : [
              "91",
              "103"
            ],
            "id_str" : "2337914782",
            "id" : "2337914782"
          },
          {
            "name" : "Agencia Estatal de Investigación",
            "screen_name" : "AgEInves",
            "indices" : [
              "114",
              "123"
            ],
            "id_str" : "192981712",
            "id" : "192981712"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1833464373274194296",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1833464373274194296",
      "created_at" : "Tue Sep 10 11:15:45 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @laiacastroh: 📣Job Alert🚨 I am hiring a PhD to join a research project on ONLINEHATE at @CPoliticaUB funded by @AgEInves  . \nIt's a 4-ye…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1831778052285854020"
          ],
          "editableUntil" : "2024-09-05T20:34:55.112Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Toni Rodon",
            "screen_name" : "tonirodon",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "1084732873670828032",
            "id" : "1084732873670828032"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1831778052285854020",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1831778052285854020",
      "created_at" : "Thu Sep 05 19:34:55 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @tonirodon: 🚨Interested in doing a PhD in political science?🚨\n\n➡️We invite applications for a 4-year fully funded PhD Fellowship in Poli…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1809165848952619467"
          ],
          "editableUntil" : "2024-07-05T11:02:05.723Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "epsa2024",
            "indices" : [
              "17",
              "26"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Camilo Cristancho",
            "screen_name" : "cacristan",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "171421468",
            "id" : "171421468"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1809165848952619467",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1809165848952619467",
      "created_at" : "Fri Jul 05 10:02:05 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @cacristan: 📢 #epsa2024 Join us for the Summer Institute in Computational Social Science in Barcelona on October 21-25  \n👉https://t.co/M…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1806157902110925248"
          ],
          "editableUntil" : "2024-06-27T03:49:35.311Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ciència Política UB",
            "screen_name" : "CPoliticaUB",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "2337914782",
            "id" : "2337914782"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1806157902110925248",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1806157902110925248",
      "created_at" : "Thu Jun 27 02:49:35 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @CPoliticaUB: We have an incredible lineup and the opportunity to attend the Computational Social Science Conference organized by the Ba…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1806157883177857462"
          ],
          "editableUntil" : "2024-06-27T03:49:30.797Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ciència Política UB",
            "screen_name" : "CPoliticaUB",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "2337914782",
            "id" : "2337914782"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1806157883177857462",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1806157883177857462",
      "created_at" : "Thu Jun 27 02:49:30 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @CPoliticaUB: 📢Join us for the last sigh of summer!\nThe Summer Institute in Computational Social Science in Barcelona is taking place on…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1803706135876079975"
          ],
          "editableUntil" : "2024-06-20T09:27:08.689Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jordi Muñoz",
            "screen_name" : "jordimunozm",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "260451268",
            "id" : "260451268"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1803706135876079975",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1803706135876079975",
      "created_at" : "Thu Jun 20 08:27:08 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @jordimunozm: It's great to see how things institutionalize. Tomorrow we will have the 10th (!) Barcelona PhD Workshop on Empirical Poli…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1803330969337758091"
          ],
          "editableUntil" : "2024-06-19T08:36:22.016Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Daniel Cetrà",
            "screen_name" : "DaniCetra",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "230310765",
            "id" : "230310765"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1803330969337758091",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1803330969337758091",
      "created_at" : "Wed Jun 19 07:36:22 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @DaniCetra: 📢 CALL FOR ABSTRACTS!\n\n📝Workshop «Judicial Politics, Federalism, and Territorial Disputes»\n🗓️ 18-19 November 2024\n🏙️ Barcelo…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1787578862215344319"
          ],
          "editableUntil" : "2024-05-06T21:23:07.018Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Facultat de Dret UB",
            "screen_name" : "Dret_UB",
            "indices" : [
              "3",
              "11"
            ],
            "id_str" : "875314602816524288",
            "id" : "875314602816524288"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1787578862215344319",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1787578862215344319",
      "created_at" : "Mon May 06 20:23:07 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @Dret_UB: 📢 \"Call for papers\" pel “VI International Doctoral Workshop” (“Digitalization and Technological Change”)\n\n⚠️ Termini: 31 de ma…",
      "lang" : "ro"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1780679931296366647"
          ],
          "editableUntil" : "2024-04-17T20:29:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Luis Remiro",
            "screen_name" : "LuisMRemiro",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "49451947",
            "id" : "49451947"
          },
          {
            "name" : "Ciència Política UB",
            "screen_name" : "CPoliticaUB",
            "indices" : [
              "13",
              "25"
            ],
            "id_str" : "2337914782",
            "id" : "2337914782"
          },
          {
            "name" : "Eva  Anduiza",
            "screen_name" : "Evaanduiza",
            "indices" : [
              "26",
              "37"
            ],
            "id_str" : "308680473",
            "id" : "308680473"
          },
          {
            "name" : "Eelco Harteveld",
            "screen_name" : "EelcoHarteveld",
            "indices" : [
              "38",
              "53"
            ],
            "id_str" : "2221645207",
            "id" : "2221645207"
          },
          {
            "name" : "Luis Miller",
            "screen_name" : "luismmiller",
            "indices" : [
              "54",
              "66"
            ],
            "id_str" : "1486082834",
            "id" : "1486082834"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "106"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1780677056147103880",
      "id_str" : "1780679931296366647",
      "in_reply_to_user_id" : "49451947",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1780679931296366647",
      "in_reply_to_status_id" : "1780677056147103880",
      "created_at" : "Wed Apr 17 19:29:13 +0000 2024",
      "favorited" : false,
      "full_text" : "@LuisMRemiro @CPoliticaUB @Evaanduiza @EelcoHarteveld @luismmiller What an exciting day, my pana!!!!❤️❤️❤️",
      "lang" : "en",
      "in_reply_to_screen_name" : "LuisMRemiro",
      "in_reply_to_user_id_str" : "49451947"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1762792105972310295"
          ],
          "editableUntil" : "2024-02-28T11:49:23.814Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Juan A. Mayoral 🦋: @jamayoral.bsky.social",
            "screen_name" : "jamayoralda",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "459501286",
            "id" : "459501286"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1762792105972310295",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1762792105972310295",
      "created_at" : "Wed Feb 28 10:49:23 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @jamayoralda: Si te interesa la política judicial o el estudio empírico del derecho, tenemos buenas noticias para ti. Plazo para mandar…",
      "lang" : "es"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1749761502695825851"
          ],
          "editableUntil" : "2024-01-23T12:50:25.896Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ciència Política UB",
            "screen_name" : "CPoliticaUB",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "2337914782",
            "id" : "2337914782"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1749761502695825851",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1749761502695825851",
      "created_at" : "Tue Jan 23 11:50:25 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @CPoliticaUB: 📣📊 Si estàs fent recerca en comportament judicial empíric, t'interessarà aquest grup de treball organitzat pel nostre comp…",
      "lang" : "ca"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1749457820745974194"
          ],
          "editableUntil" : "2024-01-22T16:43:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Juan A. Mayoral 🦋: @jamayoral.bsky.social",
            "screen_name" : "jamayoralda",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "459501286",
            "id" : "459501286"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/PSUBRodilla/status/1749457820745974194/photo/1",
            "indices" : [
              "217",
              "240"
            ],
            "url" : "https://t.co/tQj8xLWaii",
            "media_url" : "http://pbs.twimg.com/media/GEdSlQcWoAATF6w.jpg",
            "id_str" : "1749457780279255040",
            "id" : "1749457780279255040",
            "media_url_https" : "https://pbs.twimg.com/media/GEdSlQcWoAATF6w.jpg",
            "sizes" : {
              "small" : {
                "w" : "482",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1080",
                "h" : "1523",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "851",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/tQj8xLWaii"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "240"
      ],
      "favorite_count" : "7",
      "id_str" : "1749457820745974194",
      "in_reply_to_user_id" : "459501286",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1749457820745974194",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jan 22 15:43:42 +0000 2024",
      "favorited" : false,
      "full_text" : "@jamayoralda y yo mismo coordinamos un panel sobre empirical judicial behavior y judicial politics en el próximo Congreso AECPA (Burgos). \n\nSi estás trabajando en el tema no dudes en aplicar!\n\n(Más info en el cartel) https://t.co/tQj8xLWaii",
      "lang" : "es",
      "in_reply_to_screen_name" : "jamayoralda",
      "in_reply_to_user_id_str" : "459501286",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/PSUBRodilla/status/1749457820745974194/photo/1",
            "indices" : [
              "217",
              "240"
            ],
            "url" : "https://t.co/tQj8xLWaii",
            "media_url" : "http://pbs.twimg.com/media/GEdSlQcWoAATF6w.jpg",
            "id_str" : "1749457780279255040",
            "id" : "1749457780279255040",
            "media_url_https" : "https://pbs.twimg.com/media/GEdSlQcWoAATF6w.jpg",
            "sizes" : {
              "small" : {
                "w" : "482",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1080",
                "h" : "1523",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "851",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/tQj8xLWaii"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1738197628272148880"
          ],
          "editableUntil" : "2023-12-22T14:59:43.387Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Ciència Política UB",
            "screen_name" : "CPoliticaUB",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "2337914782",
            "id" : "2337914782"
          },
          {
            "name" : "Universitat de Barcelona",
            "screen_name" : "UniBarcelona",
            "indices" : [
              "81",
              "94"
            ],
            "id_str" : "188725330",
            "id" : "188725330"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/CPoliticaUB/status/1738152641073496146/photo/1",
            "source_status_id" : "1738152641073496146",
            "indices" : [
              "95",
              "118"
            ],
            "url" : "https://t.co/MtDbzNXz79",
            "media_url" : "http://pbs.twimg.com/media/GB8okcDXMAAGVqw.jpg",
            "id_str" : "1738152587658997760",
            "source_user_id" : "2337914782",
            "id" : "1738152587658997760",
            "media_url_https" : "https://pbs.twimg.com/media/GB8okcDXMAAGVqw.jpg",
            "source_user_id_str" : "2337914782",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "548",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1538",
                "h" : "1240",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "967",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1738152641073496146",
            "display_url" : "pic.x.com/MtDbzNXz79"
          }
        ],
        "hashtags" : [
          {
            "text" : "ComunicatUB",
            "indices" : [
              "17",
              "29"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "118"
      ],
      "favorite_count" : "0",
      "id_str" : "1738197628272148880",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1738197628272148880",
      "possibly_sensitive" : false,
      "created_at" : "Fri Dec 22 13:59:43 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @CPoliticaUB: #ComunicatUB | Comunicat de la Secció de Ciència Política de la @UniBarcelona https://t.co/MtDbzNXz79",
      "lang" : "ca",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/CPoliticaUB/status/1738152641073496146/photo/1",
            "source_status_id" : "1738152641073496146",
            "indices" : [
              "95",
              "118"
            ],
            "url" : "https://t.co/MtDbzNXz79",
            "media_url" : "http://pbs.twimg.com/media/GB8okcDXMAAGVqw.jpg",
            "id_str" : "1738152587658997760",
            "source_user_id" : "2337914782",
            "id" : "1738152587658997760",
            "media_url_https" : "https://pbs.twimg.com/media/GB8okcDXMAAGVqw.jpg",
            "source_user_id_str" : "2337914782",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "548",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1538",
                "h" : "1240",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "967",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1738152641073496146",
            "display_url" : "pic.x.com/MtDbzNXz79"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1736791940652302485"
          ],
          "editableUntil" : "2023-12-18T17:54:01.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Juan A. Mayoral 🦋: @jamayoral.bsky.social",
            "screen_name" : "jamayoralda",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "459501286",
            "id" : "459501286"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/e15MFq0KjY",
            "expanded_url" : "https://t.co/e15MFq0KjY",
            "display_url" : "t.co/e15MFq0KjY",
            "indices" : [
              "239",
              "262"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "262"
      ],
      "favorite_count" : "1",
      "id_str" : "1736791940652302485",
      "in_reply_to_user_id" : "459501286",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1736791940652302485",
      "possibly_sensitive" : false,
      "created_at" : "Mon Dec 18 16:54:01 +0000 2023",
      "favorited" : false,
      "full_text" : "@jamayoralda y yo coordinamos un Grupo de Trabajo en el próximo Congreso de la AECPA. Si tienes cualquier trabajo (o conoces a algxn interesadx) empírico sobre comportamiento judicial o sobre el uso de los tribunales, no dudes en aplicar. https://t.co/e15MFq0KjY",
      "lang" : "es",
      "in_reply_to_screen_name" : "jamayoralda",
      "in_reply_to_user_id_str" : "459501286"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1735622853821694008"
          ],
          "editableUntil" : "2023-12-15T12:28:29.321Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Toni Rodon",
            "screen_name" : "tonirodon",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "1084732873670828032",
            "id" : "1084732873670828032"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1735622853821694008",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1735622853821694008",
      "created_at" : "Fri Dec 15 11:28:29 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @tonirodon: 🏛️We are very happy to host once again a new edition of the PhD Workshop on Empirical Political Science. \n\n▶️ If you are aro…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1727211404040827376"
          ],
          "editableUntil" : "2023-11-22T07:24:23.416Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jaime Palomera",
            "screen_name" : "JaimePalomera",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "100259974",
            "id" : "100259974"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1727211404040827376",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1727211404040827376",
      "created_at" : "Wed Nov 22 06:24:23 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @JaimePalomera: El Gobierno se estrena difundiendo el mito de que hay muchos rentistas que complementan su pensión con el alquiler y que…",
      "lang" : "es"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1717475474614399184"
          ],
          "editableUntil" : "2023-10-26T10:37:16.956Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ciència Política UB",
            "screen_name" : "CPoliticaUB",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "2337914782",
            "id" : "2337914782"
          },
          {
            "name" : "Alex Scacco",
            "screen_name" : "alex_scacco",
            "indices" : [
              "53",
              "65"
            ],
            "id_str" : "982264621384925186",
            "id" : "982264621384925186"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1717475474614399184",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1717475474614399184",
      "created_at" : "Thu Oct 26 09:37:16 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @CPoliticaUB: We are looking forward to receiving\n@alex_scacco at our departmental seminar! She will be presenting “Misinformation and I…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1703731335666274307"
          ],
          "editableUntil" : "2023-09-18T12:22:58.877Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Laia Castro",
            "screen_name" : "laiacastroh",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "117104237",
            "id" : "117104237"
          },
          {
            "name" : "Ciència Política UB",
            "screen_name" : "CPoliticaUB",
            "indices" : [
              "50",
              "62"
            ],
            "id_str" : "2337914782",
            "id" : "2337914782"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1703731335666274307",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1703731335666274307",
      "created_at" : "Mon Sep 18 11:22:58 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @laiacastroh: This week we are kicking off our @CPoliticaUB research seminar for the upcoming fall semester!\nCheck the full program belo…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1699108852510118359"
          ],
          "editableUntil" : "2023-09-05T18:14:53.011Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "ecprgc23",
            "indices" : [
              "67",
              "76"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ECPR Law & Courts 🇺🇦🇪🇺",
            "screen_name" : "ecpr_law_courts",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "831192480171319296",
            "id" : "831192480171319296"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "101"
      ],
      "favorite_count" : "0",
      "id_str" : "1699108852510118359",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1699108852510118359",
      "created_at" : "Tue Sep 05 17:14:53 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @ecpr_law_courts: Excellent panel on \"Analyzing legal texts\" at #ecprgc23! https://t.co/jxGOMPtyYf",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1698994026123350337"
          ],
          "editableUntil" : "2023-09-05T10:38:36.267Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ECPR Law & Courts 🇺🇦🇪🇺",
            "screen_name" : "ecpr_law_courts",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "831192480171319296",
            "id" : "831192480171319296"
          },
          {
            "name" : "Philipp Schroeder",
            "screen_name" : "schroeder_pa",
            "indices" : [
              "91",
              "104"
            ],
            "id_str" : "1115547179697963008",
            "id" : "1115547179697963008"
          },
          {
            "name" : "Rodilla",
            "screen_name" : "PSUBRodilla",
            "indices" : [
              "106",
              "118"
            ],
            "id_str" : "1312048977538437120",
            "id" : "1312048977538437120"
          },
          {
            "name" : "Benjamin G. Engst",
            "screen_name" : "benjaminengst",
            "indices" : [
              "120",
              "134"
            ],
            "id_str" : "368378360",
            "id" : "368378360"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1698994026123350337",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1698994026123350337",
      "created_at" : "Tue Sep 05 09:38:36 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @ecpr_law_courts: Join us for the panel on \"Analyzing legal texts\"  today at 13:30 with @schroeder_pa, @PSUBRodilla, @benjaminengst, @St…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1698580931970318384"
          ],
          "editableUntil" : "2023-09-04T07:17:06.946Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ECPR Law & Courts 🇺🇦🇪🇺",
            "screen_name" : "ecpr_law_courts",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "831192480171319296",
            "id" : "831192480171319296"
          },
          {
            "name" : "Philipp Schroeder",
            "screen_name" : "schroeder_pa",
            "indices" : [
              "122",
              "135"
            ],
            "id_str" : "1115547179697963008",
            "id" : "1115547179697963008"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1698580931970318384",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1698580931970318384",
      "created_at" : "Mon Sep 04 06:17:06 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @ecpr_law_courts: The in-person fun continues with the panel on \"Analyzing legal texts\" on Tuesday at 13:30 chaired by @schroeder_pa and…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1698132315657179240"
          ],
          "editableUntil" : "2023-09-03T01:34:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/PSUBRodilla/status/1698132315657179240/photo/1",
            "indices" : [
              "243",
              "266"
            ],
            "url" : "https://t.co/Z1ZrlM1OqF",
            "media_url" : "http://pbs.twimg.com/media/F5D6V34bMAAQziu.jpg",
            "id_str" : "1698132313203486720",
            "id" : "1698132313203486720",
            "media_url_https" : "https://pbs.twimg.com/media/F5D6V34bMAAQziu.jpg",
            "sizes" : {
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/Z1ZrlM1OqF"
          }
        ],
        "hashtags" : [
          {
            "text" : "APSA23",
            "indices" : [
              "39",
              "46"
            ]
          },
          {
            "text" : "ecprgc23",
            "indices" : [
              "231",
              "240"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "266"
      ],
      "favorite_count" : "6",
      "id_str" : "1698132315657179240",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1698132315657179240",
      "possibly_sensitive" : false,
      "created_at" : "Sun Sep 03 00:34:28 +0000 2023",
      "favorited" : false,
      "full_text" : "Leaving Los Angeles after an inspiring #APSA23 conference. Thanks to the valuable discussants, mentors and colleagues, especially those in the Law and Courts Section - see you soon! (Some of you the day after tomorrow in Prague at #ecprgc23). https://t.co/Z1ZrlM1OqF",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/PSUBRodilla/status/1698132315657179240/photo/1",
            "indices" : [
              "243",
              "266"
            ],
            "url" : "https://t.co/Z1ZrlM1OqF",
            "media_url" : "http://pbs.twimg.com/media/F5D6V34bMAAQziu.jpg",
            "id_str" : "1698132313203486720",
            "id" : "1698132313203486720",
            "media_url_https" : "https://pbs.twimg.com/media/F5D6V34bMAAQziu.jpg",
            "sizes" : {
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/Z1ZrlM1OqF"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1697604776786317732"
          ],
          "editableUntil" : "2023-09-01T14:38:13.414Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jordi Muñoz",
            "screen_name" : "jordimunozm",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "260451268",
            "id" : "260451268"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1697604776786317732",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1697604776786317732",
      "created_at" : "Fri Sep 01 13:38:13 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @jordimunozm: Convoquem dues beques per a graduats recents o estudiants de darrer curs de grau per realitzar el postgrau d'anàlisi de da…",
      "lang" : "ca"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1696994789311267223"
          ],
          "editableUntil" : "2023-08-30T22:14:21.067Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Infusión Ideológica 🫖🍵",
            "screen_name" : "Infusionlogica",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "1248332926602838016",
            "id" : "1248332926602838016"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "75"
      ],
      "favorite_count" : "0",
      "id_str" : "1696994789311267223",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1696994789311267223",
      "created_at" : "Wed Aug 30 21:14:21 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @Infusionlogica: Válido en 1931, válido en 2023. https://t.co/WDt6BQlZaI",
      "lang" : "es"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1674732829823889409"
          ],
          "editableUntil" : "2023-06-30T11:53:16.318Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "DEC",
            "screen_name" : "dec_gr",
            "indices" : [
              "3",
              "10"
            ],
            "id_str" : "725323015861448706",
            "id" : "725323015861448706"
          },
          {
            "name" : "Facultat de Ciències Polítiques i deSociologia UAB",
            "screen_name" : "PolitiquesUAB",
            "indices" : [
              "36",
              "50"
            ],
            "id_str" : "1243408776",
            "id" : "1243408776"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1674732829823889409",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1674732829823889409",
      "created_at" : "Fri Jun 30 10:53:16 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @dec_gr: Today we are hosting at @PolitiquesUAB the VIII Workshop on Empirical Political Science. A nice opportunity for knowing about y…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1667045154752954370"
          ],
          "editableUntil" : "2023-06-09T06:45:11.751Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Paco Alonso 🍊👉🦋",
            "screen_name" : "pacolonso",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "18430246",
            "id" : "18430246"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1667045154752954370",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1667045154752954370",
      "created_at" : "Fri Jun 09 05:45:11 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @pacolonso: L’àudio dels pescadors de Cullera queda pràcticament bé on el poses. Però en este video és pura màgia. 🥘 https://t.co/ztDFF3…",
      "lang" : "ca"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1646954766629588993"
          ],
          "editableUntil" : "2023-04-14T19:43:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "MPSA2023",
            "indices" : [
              "213",
              "222"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "222"
      ],
      "favorite_count" : "7",
      "id_str" : "1646954766629588993",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1646954766629588993",
      "created_at" : "Fri Apr 14 19:13:09 +0000 2023",
      "favorited" : false,
      "full_text" : "Happy to be presenting today on the International Court's pannel \"Analyzing the opposition's use of Abstract Review. Is it about policy or politics?\" If you'r interested on how parties use courts, join us at 3pm. #MPSA2023",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1617877488230879238"
          ],
          "editableUntil" : "2023-01-24T14:00:26.561Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Luis Remiro",
            "screen_name" : "LuisMRemiro",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "49451947",
            "id" : "49451947"
          },
          {
            "name" : "Ciència Política UB",
            "screen_name" : "CPoliticaUB",
            "indices" : [
              "21",
              "33"
            ],
            "id_str" : "2337914782",
            "id" : "2337914782"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "108"
      ],
      "favorite_count" : "0",
      "id_str" : "1617877488230879238",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1617877488230879238",
      "created_at" : "Tue Jan 24 13:30:26 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @LuisMRemiro: The @CPoliticaUB has an amazing lineup prepared for the Spring semester's Research Seminar!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1613844266538700802"
          ],
          "editableUntil" : "2023-01-13T10:53:51.576Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ciència Política UB",
            "screen_name" : "CPoliticaUB",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "2337914782",
            "id" : "2337914782"
          },
          {
            "name" : "Anna M. Palau",
            "screen_name" : "palau_anna",
            "indices" : [
              "102",
              "113"
            ],
            "id_str" : "406433769",
            "id" : "406433769"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1613844266538700802",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1613844266538700802",
      "created_at" : "Fri Jan 13 10:23:51 +0000 2023",
      "favorited" : false,
      "full_text" : "RT @CPoliticaUB: 📢Next Thursday our departmental seminar reconvenes for the first session of the year\n@palau_anna will be presenting joint…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1602701881008160770"
          ],
          "editableUntil" : "2022-12-13T16:57:59.850Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UPF Ciències Polítiques i Socials",
            "screen_name" : "PolitiquesUPF",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1270657910",
            "id" : "1270657910"
          },
          {
            "name" : "Universitat de Barcelona",
            "screen_name" : "UniBarcelona",
            "indices" : [
              "97",
              "110"
            ],
            "id_str" : "188725330",
            "id" : "188725330"
          },
          {
            "name" : "Universitat Autònoma de Barcelona",
            "screen_name" : "UABBarcelona",
            "indices" : [
              "113",
              "126"
            ],
            "id_str" : "304338078",
            "id" : "304338078"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1602701881008160770",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1602701881008160770",
      "created_at" : "Tue Dec 13 16:27:59 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @PolitiquesUPF: 📢Arriba el VII PhD Workshop on Empirical Political Science! Organitzat amb la @UniBarcelona i @UABBarcelona, el nostre d…",
      "lang" : "ca"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1602701398361210883"
          ],
          "editableUntil" : "2022-12-13T16:56:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ciència Política UB",
            "screen_name" : "CPoliticaUB",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "2337914782",
            "id" : "2337914782"
          },
          {
            "name" : "Ciencia Política UAB",
            "screen_name" : "cpa_uab",
            "indices" : [
              "13",
              "21"
            ],
            "id_str" : "3091125009",
            "id" : "3091125009"
          },
          {
            "name" : "UPF Ciències Polítiques i Socials",
            "screen_name" : "PolitiquesUPF",
            "indices" : [
              "22",
              "36"
            ],
            "id_str" : "1270657910",
            "id" : "1270657910"
          },
          {
            "name" : "Facultat de Dret UB",
            "screen_name" : "Dret_UB",
            "indices" : [
              "37",
              "45"
            ],
            "id_str" : "875314602816524288",
            "id" : "875314602816524288"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/nYSWCVUz2f",
            "expanded_url" : "https://sites.google.com/view/barcelonaphdworkshop",
            "display_url" : "sites.google.com/view/barcelona…",
            "indices" : [
              "46",
              "69"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "69"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1602699073714364417",
      "id_str" : "1602701398361210883",
      "in_reply_to_user_id" : "2337914782",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1602701398361210883",
      "in_reply_to_status_id" : "1602699073714364417",
      "possibly_sensitive" : false,
      "created_at" : "Tue Dec 13 16:26:04 +0000 2022",
      "favorited" : false,
      "full_text" : "@CPoliticaUB @cpa_uab @PolitiquesUPF @Dret_UB https://t.co/nYSWCVUz2f",
      "lang" : "qme",
      "in_reply_to_screen_name" : "CPoliticaUB",
      "in_reply_to_user_id_str" : "2337914782"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1602700289148129280"
          ],
          "editableUntil" : "2022-12-13T16:51:40.321Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ciència Política UB",
            "screen_name" : "CPoliticaUB",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "2337914782",
            "id" : "2337914782"
          },
          {
            "name" : "Ciencia Política UAB",
            "screen_name" : "cpa_uab",
            "indices" : [
              "67",
              "75"
            ],
            "id_str" : "3091125009",
            "id" : "3091125009"
          },
          {
            "name" : "UPF Ciències Polítiques i Socials",
            "screen_name" : "PolitiquesUPF",
            "indices" : [
              "76",
              "90"
            ],
            "id_str" : "1270657910",
            "id" : "1270657910"
          },
          {
            "name" : "Ciència Política UB",
            "screen_name" : "CPoliticaUB",
            "indices" : [
              "91",
              "103"
            ],
            "id_str" : "2337914782",
            "id" : "2337914782"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1602700289148129280",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1602700289148129280",
      "created_at" : "Tue Dec 13 16:21:40 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @CPoliticaUB: This Friday December 16th, 4 PhD researchers from @cpa_uab @PolitiquesUPF @CPoliticaUB will present their research at the…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1602675370607755264"
          ],
          "editableUntil" : "2022-12-13T15:12:39.278Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ciència Política UB",
            "screen_name" : "CPoliticaUB",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "2337914782",
            "id" : "2337914782"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1602675370607755264",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1602675370607755264",
      "created_at" : "Tue Dec 13 14:42:39 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @CPoliticaUB: Aquest divendres 4 estudiants de doctorat presentaran la seva recerca al VII Barcelona PhD workshop👩‍🎓🧑‍🎓\n📆16 de desembre,…",
      "lang" : "ca"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1578807438589194240"
          ],
          "editableUntil" : "2022-10-08T18:30:00.840Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ECPR Law & Courts 🇺🇦🇪🇺",
            "screen_name" : "ecpr_law_courts",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "831192480171319296",
            "id" : "831192480171319296"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1578807438589194240",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1578807438589194240",
      "created_at" : "Sat Oct 08 18:00:00 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @ecpr_law_courts: Georg Vanberg holding the keynote lecture on \"Transitional Justice and the Rule of Law: Tainted Judges and Accountabil…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1578806780918128640"
          ],
          "editableUntil" : "2022-10-08T18:27:24.039Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ECPR Law & Courts 🇺🇦🇪🇺",
            "screen_name" : "ecpr_law_courts",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "831192480171319296",
            "id" : "831192480171319296"
          },
          {
            "name" : "European Consortium for Political Research",
            "screen_name" : "ECPR",
            "indices" : [
              "25",
              "30"
            ],
            "id_str" : "132839879",
            "id" : "132839879"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "143"
      ],
      "favorite_count" : "0",
      "id_str" : "1578806780918128640",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1578806780918128640",
      "created_at" : "Sat Oct 08 17:57:24 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @ecpr_law_courts: The @ECPR group kicking off the first Joint Global Politics of Law &amp; Courts Workshop with workshops simultaneously in…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1562809832373047296"
          ],
          "editableUntil" : "2022-08-25T15:01:14.297Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "ecprgc22",
            "indices" : [
              "77",
              "86"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ECPR Law & Courts 🇺🇦🇪🇺",
            "screen_name" : "ecpr_law_courts",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "831192480171319296",
            "id" : "831192480171319296"
          },
          {
            "name" : "European Consortium for Political Research",
            "screen_name" : "ECPR",
            "indices" : [
              "71",
              "76"
            ],
            "id_str" : "132839879",
            "id" : "132839879"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "143"
      ],
      "favorite_count" : "0",
      "id_str" : "1562809832373047296",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1562809832373047296",
      "created_at" : "Thu Aug 25 14:31:14 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @ecpr_law_courts: Standing Group on Law &amp; Courts on the rise at @ECPR #ecprgc22! Taking a well deserved break from the great conference…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1562527031472009217"
          ],
          "editableUntil" : "2022-08-24T20:17:29.308Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ECPR Law & Courts 🇺🇦🇪🇺",
            "screen_name" : "ecpr_law_courts",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "831192480171319296",
            "id" : "831192480171319296"
          },
          {
            "name" : "European Consortium for Political Research",
            "screen_name" : "ECPR",
            "indices" : [
              "115",
              "120"
            ],
            "id_str" : "132839879",
            "id" : "132839879"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "144"
      ],
      "favorite_count" : "0",
      "id_str" : "1562527031472009217",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1562527031472009217",
      "created_at" : "Wed Aug 24 19:47:29 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @ecpr_law_courts: Inspiring drinks after inspiring talks and great discussions among the law &amp; courts crowd @ECPR. Truly enjoying the in…",
      "lang" : "en"
    }
  }
]