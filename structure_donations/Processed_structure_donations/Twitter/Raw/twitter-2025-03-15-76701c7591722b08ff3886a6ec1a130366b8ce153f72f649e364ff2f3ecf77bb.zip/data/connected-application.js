window.YTD.connected_application.part0 = [
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Twitter, Inc.",
        "url" : ""
      },
      "name" : "Twitter for Android",
      "description" : "Twitter for Android",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2024-10-24T15:27:38.000Z",
      "id" : "258901"
    }
  }
]