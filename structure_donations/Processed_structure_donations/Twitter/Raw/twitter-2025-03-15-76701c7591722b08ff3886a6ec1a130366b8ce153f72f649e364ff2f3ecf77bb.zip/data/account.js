window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "anrola1994@gmail.com",
      "createdVia" : "oauth:3033300",
      "username" : "PSUBRodilla",
      "accountId" : "1312048977538437120",
      "createdAt" : "2020-10-02T15:17:21.455Z",
      "accountDisplayName" : "Rodilla"
    }
  }
]