window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "",
        "website" : "",
        "location" : ""
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1702638342968414208/UtFif0lf.jpg",
      "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/1312048977538437120/1647801128"
    }
  }
]