window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "GKPc1QugkH2zHPnzlwPCLzWXE11V5Di1MfsVcg2b",
      "createdAt" : "2024-11-07T12:55:28.765Z",
      "lastSeenAt" : "2024-11-07T12:55:28.767Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  }
]