window.YTD.tweets.part0 = [
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1858865773487247535"
          ],
          "editableUntil" : "2024-11-19T14:31:51.112Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Elon Musk",
            "screen_name" : "elonmusk",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "44196397",
            "id" : "44196397"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1858865773487247535",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1858865773487247535",
      "created_at" : "Tue Nov 19 13:31:51 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @elonmusk: If you look closely, you can see a human walking around the base of the rocket. \n\nEach Raptor rocket engine produces twice as…",
      "lang" : "en"
    }
  }
]