window.YTD.following.part0 = [
  {
    "following" : {
      "accountId" : "1410758193286950912",
      "userLink" : "https://twitter.com/intent/user?user_id=1410758193286950912"
    }
  },
  {
    "following" : {
      "accountId" : "34743251",
      "userLink" : "https://twitter.com/intent/user?user_id=34743251"
    }
  },
  {
    "following" : {
      "accountId" : "17919972",
      "userLink" : "https://twitter.com/intent/user?user_id=17919972"
    }
  },
  {
    "following" : {
      "accountId" : "4429003533",
      "userLink" : "https://twitter.com/intent/user?user_id=4429003533"
    }
  },
  {
    "following" : {
      "accountId" : "1314159555127971840",
      "userLink" : "https://twitter.com/intent/user?user_id=1314159555127971840"
    }
  },
  {
    "following" : {
      "accountId" : "1339619325578240000",
      "userLink" : "https://twitter.com/intent/user?user_id=1339619325578240000"
    }
  },
  {
    "following" : {
      "accountId" : "2276698777",
      "userLink" : "https://twitter.com/intent/user?user_id=2276698777"
    }
  },
  {
    "following" : {
      "accountId" : "25073877",
      "userLink" : "https://twitter.com/intent/user?user_id=25073877"
    }
  },
  {
    "following" : {
      "accountId" : "17469289",
      "userLink" : "https://twitter.com/intent/user?user_id=17469289"
    }
  },
  {
    "following" : {
      "accountId" : "1650863136424230912",
      "userLink" : "https://twitter.com/intent/user?user_id=1650863136424230912"
    }
  },
  {
    "following" : {
      "accountId" : "1408480800438374406",
      "userLink" : "https://twitter.com/intent/user?user_id=1408480800438374406"
    }
  },
  {
    "following" : {
      "accountId" : "628253959",
      "userLink" : "https://twitter.com/intent/user?user_id=628253959"
    }
  },
  {
    "following" : {
      "accountId" : "1720891078516375552",
      "userLink" : "https://twitter.com/intent/user?user_id=1720891078516375552"
    }
  },
  {
    "following" : {
      "accountId" : "1138458175663988738",
      "userLink" : "https://twitter.com/intent/user?user_id=1138458175663988738"
    }
  },
  {
    "following" : {
      "accountId" : "759251",
      "userLink" : "https://twitter.com/intent/user?user_id=759251"
    }
  },
  {
    "following" : {
      "accountId" : "1791489495453388800",
      "userLink" : "https://twitter.com/intent/user?user_id=1791489495453388800"
    }
  },
  {
    "following" : {
      "accountId" : "28785486",
      "userLink" : "https://twitter.com/intent/user?user_id=28785486"
    }
  },
  {
    "following" : {
      "accountId" : "1367531",
      "userLink" : "https://twitter.com/intent/user?user_id=1367531"
    }
  },
  {
    "following" : {
      "accountId" : "15012486",
      "userLink" : "https://twitter.com/intent/user?user_id=15012486"
    }
  },
  {
    "following" : {
      "accountId" : "1917731",
      "userLink" : "https://twitter.com/intent/user?user_id=1917731"
    }
  },
  {
    "following" : {
      "accountId" : "1652541",
      "userLink" : "https://twitter.com/intent/user?user_id=1652541"
    }
  },
  {
    "following" : {
      "accountId" : "152656121",
      "userLink" : "https://twitter.com/intent/user?user_id=152656121"
    }
  },
  {
    "following" : {
      "accountId" : "19644592",
      "userLink" : "https://twitter.com/intent/user?user_id=19644592"
    }
  },
  {
    "following" : {
      "accountId" : "95092020",
      "userLink" : "https://twitter.com/intent/user?user_id=95092020"
    }
  },
  {
    "following" : {
      "accountId" : "2425571623",
      "userLink" : "https://twitter.com/intent/user?user_id=2425571623"
    }
  },
  {
    "following" : {
      "accountId" : "44196397",
      "userLink" : "https://twitter.com/intent/user?user_id=44196397"
    }
  },
  {
    "following" : {
      "accountId" : "216299334",
      "userLink" : "https://twitter.com/intent/user?user_id=216299334"
    }
  }
]