window.YTD.follower.part0 = [
  {
    "follower" : {
      "accountId" : "1683143088221331459",
      "userLink" : "https://twitter.com/intent/user?user_id=1683143088221331459"
    }
  },
  {
    "follower" : {
      "accountId" : "1728991662834159616",
      "userLink" : "https://twitter.com/intent/user?user_id=1728991662834159616"
    }
  },
  {
    "follower" : {
      "accountId" : "1663836951634677760",
      "userLink" : "https://twitter.com/intent/user?user_id=1663836951634677760"
    }
  },
  {
    "follower" : {
      "accountId" : "1705561859972022272",
      "userLink" : "https://twitter.com/intent/user?user_id=1705561859972022272"
    }
  },
  {
    "follower" : {
      "accountId" : "1683229899279024130",
      "userLink" : "https://twitter.com/intent/user?user_id=1683229899279024130"
    }
  },
  {
    "follower" : {
      "accountId" : "1726921668621385728",
      "userLink" : "https://twitter.com/intent/user?user_id=1726921668621385728"
    }
  },
  {
    "follower" : {
      "accountId" : "1696861534650077185",
      "userLink" : "https://twitter.com/intent/user?user_id=1696861534650077185"
    }
  },
  {
    "follower" : {
      "accountId" : "1714459100996567040",
      "userLink" : "https://twitter.com/intent/user?user_id=1714459100996567040"
    }
  },
  {
    "follower" : {
      "accountId" : "1697428871417659392",
      "userLink" : "https://twitter.com/intent/user?user_id=1697428871417659392"
    }
  },
  {
    "follower" : {
      "accountId" : "1849719716102762497",
      "userLink" : "https://twitter.com/intent/user?user_id=1849719716102762497"
    }
  },
  {
    "follower" : {
      "accountId" : "1698538524243283968",
      "userLink" : "https://twitter.com/intent/user?user_id=1698538524243283968"
    }
  },
  {
    "follower" : {
      "accountId" : "1717426057966411776",
      "userLink" : "https://twitter.com/intent/user?user_id=1717426057966411776"
    }
  },
  {
    "follower" : {
      "accountId" : "1685652108438360064",
      "userLink" : "https://twitter.com/intent/user?user_id=1685652108438360064"
    }
  },
  {
    "follower" : {
      "accountId" : "1719822524563984384",
      "userLink" : "https://twitter.com/intent/user?user_id=1719822524563984384"
    }
  },
  {
    "follower" : {
      "accountId" : "1683599214016593921",
      "userLink" : "https://twitter.com/intent/user?user_id=1683599214016593921"
    }
  },
  {
    "follower" : {
      "accountId" : "1719326761614196736",
      "userLink" : "https://twitter.com/intent/user?user_id=1719326761614196736"
    }
  },
  {
    "follower" : {
      "accountId" : "1705026407875698688",
      "userLink" : "https://twitter.com/intent/user?user_id=1705026407875698688"
    }
  },
  {
    "follower" : {
      "accountId" : "1811120335573368832",
      "userLink" : "https://twitter.com/intent/user?user_id=1811120335573368832"
    }
  },
  {
    "follower" : {
      "accountId" : "1732392597979561984",
      "userLink" : "https://twitter.com/intent/user?user_id=1732392597979561984"
    }
  },
  {
    "follower" : {
      "accountId" : "1698506782522408960",
      "userLink" : "https://twitter.com/intent/user?user_id=1698506782522408960"
    }
  },
  {
    "follower" : {
      "accountId" : "1695987798644338689",
      "userLink" : "https://twitter.com/intent/user?user_id=1695987798644338689"
    }
  },
  {
    "follower" : {
      "accountId" : "1728731718268383232",
      "userLink" : "https://twitter.com/intent/user?user_id=1728731718268383232"
    }
  },
  {
    "follower" : {
      "accountId" : "1703806885730902016",
      "userLink" : "https://twitter.com/intent/user?user_id=1703806885730902016"
    }
  },
  {
    "follower" : {
      "accountId" : "1706274577934884864",
      "userLink" : "https://twitter.com/intent/user?user_id=1706274577934884864"
    }
  },
  {
    "follower" : {
      "accountId" : "1685944182614220800",
      "userLink" : "https://twitter.com/intent/user?user_id=1685944182614220800"
    }
  },
  {
    "follower" : {
      "accountId" : "1733861551608655872",
      "userLink" : "https://twitter.com/intent/user?user_id=1733861551608655872"
    }
  },
  {
    "follower" : {
      "accountId" : "1742325332668190720",
      "userLink" : "https://twitter.com/intent/user?user_id=1742325332668190720"
    }
  },
  {
    "follower" : {
      "accountId" : "1705750106287341568",
      "userLink" : "https://twitter.com/intent/user?user_id=1705750106287341568"
    }
  },
  {
    "follower" : {
      "accountId" : "1728882287721209856",
      "userLink" : "https://twitter.com/intent/user?user_id=1728882287721209856"
    }
  },
  {
    "follower" : {
      "accountId" : "1678225605605638145",
      "userLink" : "https://twitter.com/intent/user?user_id=1678225605605638145"
    }
  },
  {
    "follower" : {
      "accountId" : "1688191547807039488",
      "userLink" : "https://twitter.com/intent/user?user_id=1688191547807039488"
    }
  },
  {
    "follower" : {
      "accountId" : "1684455569912909824",
      "userLink" : "https://twitter.com/intent/user?user_id=1684455569912909824"
    }
  },
  {
    "follower" : {
      "accountId" : "1705635380802813953",
      "userLink" : "https://twitter.com/intent/user?user_id=1705635380802813953"
    }
  }
]