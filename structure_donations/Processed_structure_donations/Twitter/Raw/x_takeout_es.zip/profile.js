window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "Animals and nature 🌼🍀",
        "website" : "",
        "location" : "United Kingdom"
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1854508604444782604/maJh3zim.jpg",
      "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/1854507704154497024/1732439580"
    }
  }
]