window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "1854507704154497024"
    }
  }
]