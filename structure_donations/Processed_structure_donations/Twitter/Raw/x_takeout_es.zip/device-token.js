window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "-1",
      "token" : "bkWti1fRxGGfDF8C3oKQE05VsNNSVLLvT8UUnXWa",
      "createdAt" : "1970-01-01T00:00:00.000Z",
      "lastSeenAt" : "2024-11-22T22:30:16.465Z",
      "clientApplicationName" : ""
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "7oHuDDjXmVpmCjtJ0Gr5JoKMk2QPcxGAvqkPzQNG",
      "createdAt" : "2024-12-27T11:16:18.752Z",
      "lastSeenAt" : "2024-12-27T11:16:18.753Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "GKPc1QugkH2zHPnzlwPCLzWXE11V5Di1MfsVcg2b",
      "createdAt" : "2024-11-07T12:55:28.765Z",
      "lastSeenAt" : "2025-01-29T15:55:54.785Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  }
]