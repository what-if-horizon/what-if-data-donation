window.YTD.tweet_headers.part0 = [
  {
    "tweet" : {
      "tweet_id" : "1864227208530669712",
      "user_id" : "1854507704154497024",
      "created_at" : "Wed Dec 04 08:36:16 +0000 2024"
    }
  },
  {
    "tweet" : {
      "tweet_id" : "1860611463569686724",
      "user_id" : "1854507704154497024",
      "created_at" : "Sun Nov 24 09:08:36 +0000 2024"
    }
  },
  {
    "tweet" : {
      "tweet_id" : "1860610742912774647",
      "user_id" : "1854507704154497024",
      "created_at" : "Sun Nov 24 09:05:44 +0000 2024"
    }
  },
  {
    "tweet" : {
      "tweet_id" : "1860091431882490193",
      "user_id" : "1854507704154497024",
      "created_at" : "Fri Nov 22 22:42:10 +0000 2024"
    }
  },
  {
    "tweet" : {
      "tweet_id" : "1860090739629400229",
      "user_id" : "1854507704154497024",
      "created_at" : "Fri Nov 22 22:39:25 +0000 2024"
    }
  },
  {
    "tweet" : {
      "tweet_id" : "1858865773487247535",
      "user_id" : "1854507704154497024",
      "created_at" : "Tue Nov 19 13:31:51 +0000 2024"
    }
  }
]