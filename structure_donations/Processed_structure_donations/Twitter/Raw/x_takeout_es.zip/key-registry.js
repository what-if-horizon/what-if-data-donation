window.YTD.key_registry.part0 = [
  {
    "keyRegistryData" : {
      "userId" : "1854507704154497024",
      "registeredDevices" : {
        "deviceMetadataList" : [
          {
            "userAgent" : "Twitter-iPhone/10.68 iOS/17.6.1 (Apple;iPhone14,4;;;;;0;2021)",
            "registrationToken" : "3bcf38ddf129f3efa717b310dee32cbc",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEbKrIx0ZndIWP6m99uMeMoQPq9tYU2RXPJhp7f+JzWGxK23/O3bWnpqsuEtxCu/lK4xrIxrl4rK9HCVgqv9CFjg==",
            "createdAt" : "2024-11-22T22:31:26.481Z",
            "deviceId" : "21692C9A-AF60-4505-9222-12CEA5E873F6"
          },
          {
            "userAgent" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
            "registrationToken" : "bf83853c64e8b2ad7d25c65ea6cbe2c2",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEEDFxC7VdyNudMNiQpVU+/uk3hdkjoDWO50gTJtKnL1pw2+dOc5fT9O2jZ8ZiZtzLmbd5rtEXzgEo2aRWj6+T5w==",
            "createdAt" : "2024-11-07T13:11:07.952Z",
            "deviceId" : "8cb20314-521e-44e8-aeae-923017b82dfe"
          },
          {
            "userAgent" : "Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1",
            "registrationToken" : "540cd64b1bec7d91b690fa24f307b13f",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEMwvpej+JEcKLcc5rV8fWHj9p1x2j64Gk6z6ZACYU1YQB8PGX1isWs+sZULvoVsHcbr6LCkBzghZLt4OMyphLsA==",
            "createdAt" : "2024-12-27T11:16:20.671Z",
            "deviceId" : "9f1cd454-3332-4b67-80eb-c8d0ec3e9323"
          }
        ]
      },
      "deregisteredDevices" : {
        "deRegisteredDeviceMetadataList" : [ ]
      }
    }
  }
]