window.YTD.ad_engagements.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1859597585138270244",
                  "tweetText" : "Thousands swear by the tips in the \"80/20 Principle\" book. I gave it a go to see what all the fuss was about.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Blinkist",
                  "screenName" : "@blinkist"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-12-27 11:13:01"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-27 11:13:03",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1867148592869425264",
                  "tweetText" : "To Brawl and Beyond",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Brawl Stars",
                  "screenName" : "@BrawlStars"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Brawl Stars IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 12.0 and above"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Lebanon"
                  }
                ],
                "impressionTime" : "2024-12-29 14:52:16"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-29 14:55:33",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-29 14:52:27",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-29 14:55:03",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-29 14:53:36",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-29 14:52:18",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-29 14:53:43",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-29 14:52:18",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-12-29 14:56:22",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-29 14:53:25",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-29 14:54:31",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1865068684399776246",
                  "tweetText" : "Diriyah Art Futures is a hub that is connected to the world and wired for the region. It's a platform for pioneering ideas and groundbreaking creativity. Visit DAF. #DAF",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "DiriyahArtFutures",
                  "screenName" : "@DAFmoc"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Lebanon"
                  }
                ],
                "impressionTime" : "2024-12-29 14:52:16"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-29 15:02:59",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1871177121067946448",
                  "tweetText" : "Apple recommends Blinkist for lifelong learners, top thinkers, and anyone who wishes they had more time to learn the powerful ideas in nonfiction books.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Blinkist",
                  "screenName" : "@blinkist"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  }
                ],
                "impressionTime" : "2024-12-29 15:02:59"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-29 15:03:02",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1867149737323033056",
                  "tweetText" : "Brawl Stars | Toy Story",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Brawl Stars",
                  "screenName" : "@BrawlStars"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Brawl Stars IOS All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Lebanon"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 12.0 and above"
                  }
                ],
                "impressionTime" : "2024-12-30 14:21:22"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-30 14:21:24",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-30 14:21:36",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-30 14:21:26",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-12-30 14:21:24",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1867148592869425264",
                  "tweetText" : "To Brawl and Beyond",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Brawl Stars",
                  "screenName" : "@BrawlStars"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Brawl Stars IOS All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Lebanon"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 12.0 and above"
                  }
                ],
                "impressionTime" : "2024-12-30 14:21:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-30 14:21:34",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-12-30 14:22:01",
                  "engagementType" : "DismissWithoutReason"
                },
                {
                  "engagementTime" : "2024-12-30 14:22:19",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-30 14:21:56",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1876403414617174235",
                  "tweetText" : "💙 like this post to witness the next evolution of #GalaxyAI\n\nA true AI companion is coming — are you ready for #GalaxyUnpacked? https://t.co/djbjSNo82Q",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/djbjSNo82Q"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Samsung Mobile",
                  "screenName" : "@SamsungMobile"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United Kingdom"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2025-01-23 17:32:29"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-23 17:32:37",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-01-23 17:32:33",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-23 17:32:35",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2025-01-23 17:32:36",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2025-01-23 17:33:21",
                  "engagementType" : "VideoSession"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1849080839386398914",
                  "tweetText" : "Thousands swear by the tips to unf*ck themselves in the 30 books. \n\nHas any of the books on the list helped YOU improve your life? Comment below!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Blinkist",
                  "screenName" : "@blinkist"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United Kingdom"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 15.0 and above"
                  }
                ],
                "impressionTime" : "2025-01-25 21:02:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-25 21:02:21",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1843188167228494285",
                  "tweetText" : "Enjoy posting on X?\n\nSubscribe to Premium to join our revenue share program.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Premium",
                  "screenName" : "@premium"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "List",
                    "targetingValue" : "Premium subs Aug 5"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United Kingdom"
                  }
                ],
                "impressionTime" : "2025-01-25 21:01:55"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-25 21:01:58",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1858839943381930473",
                  "tweetText" : "Bitcoin bull run is here? 👀",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "eToro",
                  "screenName" : "@eToro"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "List",
                    "targetingValue" : "110_Depositors_4mfqsb"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "101_AllRegistrations_4mfqsb"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install eToro: Trade. Invest. Connect. ANDROID All"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United Kingdom"
                  }
                ],
                "impressionTime" : "2025-01-25 21:02:27"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-25 21:02:31",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-01-25 21:02:33",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2025-01-25 21:02:30",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-01-25 21:02:42",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1880380609853530305",
                  "tweetText" : "For a limited time only, lock in big savings on annual Verified Org subscriptions.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Business",
                  "screenName" : "@XBusiness"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United Kingdom"
                  }
                ],
                "impressionTime" : "2025-01-25 21:02:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-01-25 21:02:40",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  }
]