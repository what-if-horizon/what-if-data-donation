window.YTD.connected_application.part0 = [
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Twitter",
        "url" : ""
      },
      "name" : "Twitter for iPhone",
      "description" : "Twitter for iPhone",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2024-11-22T22:30:16.000Z",
      "id" : "129032"
    }
  }
]