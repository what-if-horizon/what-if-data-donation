window.YTD.follower.part0 = [
  {
    "follower" : {
      "accountId" : "275019",
      "userLink" : "https://twitter.com/intent/user?user_id=blabla"
    }
  },
  {
    "follower" : {
      "accountId" : "1332646",
      "userLink" : "https://twitter.com/intent/user?user_id=133962146"
    }
  },
  {
    "follower" : {
      "accountId" : "1793",
      "userLink" : "https://twitter.com/intent/user?user_id=173073"
    }
  },
  {
    "follower" : {
      "accountId" : "1793",
      "userLink" : "https://twitter.com/intent/user?user_id=17882"
    }
  },
  {
    "follower" : {
      "accountId" : "10511008",
      "userLink" : "https://twitter.com/intent/user?user_id=1052931008"
    }
  },
  {
    "follower" : {
      "accountId" : "67649",
      "userLink" : "https://twitter.com/intent/user?user_id=1467649"
    }
  },
  {
    "follower" : {
      "accountId" : "92",
      "userLink" : "https://twitter.com/intent/user?user_id=92"
    }
  }
]