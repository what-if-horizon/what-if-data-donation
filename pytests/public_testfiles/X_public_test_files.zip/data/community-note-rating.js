window.YTD.community_note_rating.part0 = [
  {
    "communityNoteRating" : {
      "noteId" : "1698220651905268",
      "helpfulnessLevel" : "Helpful",
      "createdAt" : "2023-09-04T21:55:48.974Z",
      "userId" : "13120438437120",
      "helpfulTags" : [
        "ImportantContext",
        "UnbiasedLanguage",
        "Clear",
        "AddressesClaim"
      ]
    }
  },
  {
    "communityNoteRating" : {
      "noteId" : "172706087620663",
      "helpfulnessLevel" : "Helpful",
      "createdAt" : "2023-11-22T06:07:30.661Z",
      "userId" : "131204897753840",
      "helpfulTags" : [
        "ImportantContext",
        "AddressesClaim",
        "GoodSources",
        "UnbiasedLanguage",
        "Clear"
      ]
    }
  }
]