window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "Spa",
            "isDisabled" : false
          },
          {
            "language" : "Spa",
            "isDisabled" : false
          },
          {
            "language" : "Spa",
            "isDisabled" : false
          },
          {
            "language" : "Spa",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : "ma"
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "Test File",
            "isDisabled" : false
          },
          {
            "name" : "Commentary",
            "isDisabled" : false
          },
          {
            "name" : "Test File",
            "isDisabled" : false
          },
          {
            "name" : "BSC",
            "isDisabled" : false
          },
          {
            "name" : "BSC",
            "isDisabled" : false
          },
          {
            "name" : "Politics",
            "isDisabled" : false
          },
          {
            "name" : "BSC",
            "isDisabled" : false
          },
          {
            "name" : "Science",
            "isDisabled" : false
          },
          {
            "name" : "Space and astronomy",
            "isDisabled" : false
          },
          {
            "name" : "Spain",
            "isDisabled" : false
          },
          {
            "name" : "Sporting events",
            "isDisabled" : false
          },
          {
            "name" : "Sports news",
            "isDisabled" : false
          },
          {
            "name" : "Tech news",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "BSC",
            "isDisabled" : false
          },
          {
            "name" : "Travel",
            "isDisabled" : false
          },
          {
            "name" : "Weather",
            "isDisabled" : false
          },
          {
            "name" : "BSC",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "lookalikeAdvertisers" : [
            "@BSC",
            "@BSC",
            "@BSC",
            "@bsc"
          ],
          "advertisers" : [ ],
          "doNotReachAdvertisers" : [ ],
          "catalogAudienceAdvertisers" : [ ],
          "numAudiences" : "0"
        },
        "shows" : [
          "The Office",    
          "Friends",
        ]
      },
      "locationHistory" : [ ],
      "inferredAgeInfo" : {
        "age" : [
          "bla"
        ],
        "birthDate" : ""
      }
    }
  }
]