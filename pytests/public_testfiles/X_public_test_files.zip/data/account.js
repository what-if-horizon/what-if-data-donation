window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "testfile@gmail.com",
      "createdVia" : "oauth:303300",
      "username" : "TestFile0",
      "accountId" : "1348977538437120",
      "createdAt" : "2020-10-02T15:17:21.455Z",
      "accountDisplayName" : "TF"
    }
  }
]