window.YTD.periscope_account_information.part0 = [
  {
    "periscopeAccountInformation" : {
      "displayName" : "Tes",
      "digitsId" : "",
      "username" : "test",
      "twitterId" : "13538437120",
      "id" : "1PmKqGjo",
      "twitterScreenName" : "Test",
      "isTwitterUser" : true,
      "createdAt" : "2022-03-29T20:35:10.756797706Z"
    }
  }
]