window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "189877387",
      "fullText" : "blablabla",
      "expandedUrl" : "https://twitter.com/i/web/status/181077387"
    }
  },
  {
    "like" : {
      "tweetId" : "187878645949",
      "fullText" : "blabla",
      "expandedUrl" : "https://twitter.com/i/web/status/18749"
    }
  },
  {
    "like" : {
      "tweetId" : "13611265",
      "fullText" : "blablabla",
      "expandedUrl" : "https://twitter.com/i/web/status/16165"
    }
  }
]