window.YTD.direct_message_group_headers.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "163265749633536",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "163962182592772",
            "senderId" : "1980526",
            "createdAt" : "2023-03-25T13:32:33.511Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "163859636019210",
            "senderId" : "1980526",
            "createdAt" : "2023-03-22T17:16:10.446Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "163859064936966",
            "senderId" : "1980526",
            "createdAt" : "2023-03-22T17:15:43.753Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "163847960496324",
            "senderId" : "131277538437120",
            "createdAt" : "2023-03-22T09:56:54.847Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "163847308576389",
            "senderId" : "171468",
            "createdAt" : "2023-03-22T09:29:51.367Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1632353014794",
            "senderId" : "138977538437120",
            "createdAt" : "2023-03-06T09:40:59.253Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1632649633540",
            "senderId" : "171421468",
            "createdAt" : "2023-03-06T08:21:10.512Z"
          }
        },
        {
          "joinConversation" : {
            "initiatingUserId" : "171468",
            "participantsSnapshot" : [
              "131204897437120",
              "1910526",
              "421468"
            ],
            "createdAt" : "2023-03-06T08:21:10.509Z"
          }
        }
      ]
    }
  }
]