window.YTD.direct_messages.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "7849082-131204897753",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "131204897750",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Blalalala",
            "mediaUrls" : [ ],
            "senderId" : "782",
            "id" : "15983",
            "createdAt" : "2022-12-01T15:57:33.211Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "782",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Blalala",
            "mediaUrls" : [ ],
            "senderId" : "13120489770",
            "id" : "159831419",
            "createdAt" : "2022-12-01T13:52:53.731Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1312048",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "blablabla",
            "mediaUrls" : [ ],
            "senderId" : "7849082",
            "id" : "1598300973746819076",
            "createdAt" : "2022-12-01T13:00:21.830Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "7849082",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "blablabal",
            "mediaUrls" : [ ],
            "senderId" : "13127120",
            "id" : "15982760",
            "createdAt" : "2022-12-01T11:24:31.016Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "7882",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "balablabla",
            "mediaUrls" : [ ],
            "senderId" : "13120120",
            "id" : "159881674757",
            "createdAt" : "2022-12-01T10:28:44.347Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  }
]
