window.YTD.tweet_headers.part0 = [
  {
    "tweet" : {
      "tweet_id" : "bal",
      "user_id" : "bla",
      "created_at" : "Thu Feb 20 12:35:53 +0000 2025"
    }
  },
  {
    "tweet" : {
      "tweet_id" : "18672670214210",
      "user_id" : "18977538437120",
      "created_at" : "Thu Dec 12 16:52:18 +0000 2024"
    }
  },
  {
    "tweet" : {
      "tweet_id" : "bla",
      "user_id" : "bla",
      "created_at" : "Thu Nov 14 15:08:36 +0000 2024"
    }
  },
  {
    "tweet" : {
      "tweet_id" : "bla",
      "user_id" : "bla",
      "created_at" : "Wed Aug 24 19:47:29 +0000 2022"
    }
  }
]