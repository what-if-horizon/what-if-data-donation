window.YTD.direct_messages_group.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "1665",
      "messages" : [
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https",
                "expanded" : "https",
                "display" : "twitter.com"
              }
            ],
            "text" : "https",
            "mediaUrls" : [ ],
            "senderId" : "17",
            "id" : "163992772",
            "createdAt" : "2023-03-25T13:32:33.511Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Blablabla",
            "mediaUrls" : [ ],
            "senderId" : "196",
            "id" : "1636010",
            "createdAt" : "2023-03-22T17:16:10.446Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Blablabla",
            "mediaUrls" : [ ],
            "senderId" : "19176",
            "id" : "16384936966",
            "createdAt" : "2023-03-22T17:15:43.753Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Blablabla",
            "mediaUrls" : [ ],
            "senderId" : "131238437120",
            "id" : "16360237496324",
            "createdAt" : "2023-03-22T09:56:54.847Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https",
                "expanded" : "https",
                "display" : "twitter.com/
            ],
            "text" : "https:",
            "mediaUrls" : [ ],
            "senderId" : "1714468",
            "id" : "160818576389",
            "createdAt" : "2023-03-22T09:29:51.367Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Blablabla",
            "mediaUrls" : [ ],
            "senderId" : "131237120",
            "id" : "163353014794",
            "createdAt" : "2023-03-06T09:40:59.253Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "reactions" : [
              {
                "senderId" : "1926",
                "reactionKey" : "Blababla",
                "eventId" : "1632667416378458112",
                "createdAt" : "2023-03-06T09:00:20.221Z"
              }
            ],
            "urls" : [
              {
                "url" : "https",
                "expanded" : "https:",
                "display" : "twitter.com"
              }
            ],
            "text" : "https:",
            "mediaUrls" : [ ],
            "senderId" : "18",
            "id" : "163265750",
            "createdAt" : "2023-03-06T08:21:10.512Z",
            "editHistory" : [ ]
          }
        },
        {
          "joinConversation" : {
            "initiatingUserId" : "1714268",
            "participantsSnapshot" : [
              "13120489437120",
              "10526",
              "17468"
            ],
            "createdAt" : "2023-03-06T08:21:10.509Z"
          }
        }
      ]
    }
  }
]
