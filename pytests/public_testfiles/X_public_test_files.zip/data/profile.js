window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "",
        "website" : "",
        "location" : ""
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/17022968/Utlf.jpg",
      "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/18437120/16128"
    }
  }
]