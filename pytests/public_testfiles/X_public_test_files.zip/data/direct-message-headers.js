window.YTD.direct_message_headers.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "7849082-1377538437120",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "1598345564846",
            "senderId" : "7082",
            "recipientId" : "13127538437120",
            "createdAt" : "2022-12-01T15:57:33.211Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "15983141224644",
            "senderId" : "1348977538437120",
            "recipientId" : "7082",
            "createdAt" : "2022-12-01T13:52:53.731Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "159830746819076",
            "senderId" : "7082",
            "recipientId" : "131204437120",
            "createdAt" : "2022-12-01T13:00:21.830Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "159827685286660",
            "senderId" : "1348977538437120",
            "recipientId" : "7082",
            "createdAt" : "2022-12-01T11:24:31.016Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1598881674757",
            "senderId" : "13120489777120",
            "recipientId" : "782",
            "createdAt" : "2022-12-01T10:28:44.347Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "171421468-48977538437120",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "1897010494629999",
            "senderId" : "171468",
            "recipientId" : "1048977538437120",
            "createdAt" : "2025-03-04T19:45:21.376Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "18759941257592",
            "senderId" : "171468",
            "recipientId" : "148977538437120",
            "createdAt" : "2025-01-05T19:49:32.191Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "18661350699219",
            "senderId" : "121468",
            "recipientId" : "048977538437120",
            "createdAt" : "2024-12-09T16:12:02.907Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "18551747490999",
            "senderId" : "1714214",
            "recipientId" : "1048977538437120",
            "createdAt" : "2024-11-09T09:05:13.973Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1852424918411375",
            "senderId" : "17148",
            "recipientId" : "048977538437120",
            "createdAt" : "2024-11-01T18:58:13.193Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "185225667345866",
            "senderId" : "171468",
            "recipientId" : "13120489437120",
            "createdAt" : "2024-11-01T10:00:37.732Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "18515322602540",
            "senderId" : "131277538437120",
            "recipientId" : "171468",
            "createdAt" : "2024-10-30T07:50:51.990Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1851539494569",
            "senderId" : "121468",
            "recipientId" : "18977538437120",
            "createdAt" : "2024-10-30T07:50:12.626Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "18515359253803",
            "senderId" : "131207538437120",
            "recipientId" : "11468",
            "createdAt" : "2024-10-30T07:48:40.048Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1851517871376",
            "senderId" : "11468",
            "recipientId" : "1338437120",
            "createdAt" : "2024-10-30T06:53:59.251Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "184792188113",
            "senderId" : "176547538437120",
            "recipientId" : "11468",
            "createdAt" : "2024-10-20T09:15:04.131Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "177623853194578",
            "senderId" : "131207538437120",
            "recipientId" : "21468",
            "createdAt" : "2024-04-05T13:19:40.493Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "17286046532",
            "senderId" : "171468",
            "recipientId" : "1048977538437120",
            "createdAt" : "2024-01-23T16:15:26.940Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1696897297",
            "senderId" : "1312538437120",
            "recipientId" : "17468",
            "createdAt" : "2023-08-30T14:26:50.930Z"
          }
        }
      ]
    }
  }
]