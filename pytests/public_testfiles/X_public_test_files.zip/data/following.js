window.YTD.following.part0 = [
  {
    "following" : {
      "accountId" : "41676",
      "userLink" : "https://twitter.com/intent/user?user_id=41676"
    }
  },
  {
    "following" : {
      "accountId" : "1096",
      "userLink" : "https://twitter.com/intent/user?user_id=10996"
    }
  }
]