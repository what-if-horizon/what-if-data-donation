window.YTD.ad_engagements.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1DWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "184973850435",
                  "tweetText" : "BlaBlaBla",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/aDgT7WDQ1"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "BlaBla",
                  "screenName" : "@testi"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Women"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 34"
                  }
                ],
                "impressionTime" : "2024-12-15 20:54:45"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-15 20:55:06",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-15 20:54:49",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-15 20:54:51",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-12-15 20:54:48",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjA314T1W3lFsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "Spotlight",
                "promotedTrendInfo" : {
                  "trendId" : "10080",
                  "name" : "#Test",
                  "description" : "Blabla"
                },
                "advertiserInfo" : {
                  "advertiserName" : " BSC",
                  "screenName" : "@Test"
                },
                "impressionTime" : "2024-12-15 20:54:48"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-15 20:54:51",
                  "engagementType" : "SpotlightView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314T1WsDWY3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "186649324525328",
                  "tweetText" : "Bla Bla BLa",
                  "urls" : [
                    "https://t.co/IF1zqVYr"
                  ],
                  "mediaUrls" : [
                    "https://t.co/qGBzyfCD"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Blabla",
                  "screenName" : "@blabla"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Catalonia"
                  }
                ],
                "impressionTime" : "2024-12-17 20:23:02"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-17 20:23:37",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-12-17 20:23:50",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-17 20:23:35",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-17 20:23:41",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-12-17 20:23:10",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Android",
                  "deviceId" : "CjiWxhdA314sD3k7JncaqGXL4e90bq3Z2hY="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "18689298350748160",
                  "tweetText" : "Blabla",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "BSC Airways",
                  "screenName" : "@BSCairways"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "blabla"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "bla"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Bla"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Bla"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Spain"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-12-17 20:12:02"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-12-17 20:12:07",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-12-17 20:12:05",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-12-17 20:12:05",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  }
]