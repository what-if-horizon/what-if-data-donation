window.YTD.screen_name_change.part0 = [
  {
    "screenNameChange" : {
      "accountId" : "13437120",
      "screenNameChange" : {
        "changedAt" : "2021-09-15T14:46:35.000Z",
        "changedFrom" : "test",
        "changedTo" : "test2"
      }
    }
  }
]