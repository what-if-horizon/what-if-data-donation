window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "1312048977437120"
    }
  }
]