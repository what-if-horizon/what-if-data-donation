window.YTD.key_registry.part0 = [
  {
    "keyRegistryData" : {
      "userId" : "1312048977538437120",
      "registeredDevices" : {
        "deviceMetadataList" : [
          {
            "userAgent" : "bla bla bla",
            "registrationToken" : "bla bla bla",
            "identityKey" : "bla bla bla/M5SQPNOxhVxdYFnRp2GQmnWrdVHQ==",
            "createdAt" : "2023-10-26T09:41:11.707Z",
            "deviceId" : "404la bla bla1476bd7f31fb"
          },
          {
            "userAgent" : "blablabla",
            "registrationToken" : "77be6e21aab9e0305c379c50",
            "identityKey" : "blablabalba",
            "createdAt" : "2024-10-24T14:19:08.887Z",
            "deviceId" : "6f49easd"
          },
          {
            "userAgent" : "blablabla",
            "registrationToken" : "blabla",
            "identityKey" : "blabla/blabla/=",
            "createdAt" : "2024-10-24T14:24:58.405Z",
            "deviceId" : "91444e03-c7"
          },
          {
            "userAgent" : "blabal",
            "registrationToken" : "blabla",
            "identityKey" : "blabla/Qy+blabla+bla==",
            "createdAt" : "2023-08-02T11:30:09.139Z",
            "deviceId" : "b5acd-ab8e-f911d07a"
          },
          {
            "userAgent" : "blablabla",
            "registrationToken" : "blablabla",
            "identityKey" : "/Fnlasnin==",
            "createdAt" : "2025-02-09T20:13:42.763Z",
            "deviceId" : "df0faf-9153a1"
          }
        ]
      },
      "deregisteredDevices" : {
        "deRegisteredDeviceMetadataList" : [ ]
      }
    }
  }
]