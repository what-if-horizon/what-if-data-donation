window.YTD.tweets.part0 = [
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "189288976"
          ],
          "editableUntil" : "2025-02-20T13:35:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/t8bxYt",
            "expanded_url" : "https://papers.ssrn.com/sol3/papers.cfm?abstract_id=5478",
            "display_url" : "papers.ssrn.com/sol3/papers.cf…",
            "indices" : [
              "243",
              "266"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "266"
      ],
      "favorite_count" : "0",
      "id_str" : "18923188976",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1892188976",
      "possibly_sensitive" : false,
      "created_at" : "Thu Feb 20 12:35:53 +0000 2025",
      "favorited" : false,
      "full_text" : "blabla",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "15629217"
          ],
          "editableUntil" : "2022-08-24T20:17:29.308Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "bla",
            "screen_name" : "ebla",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "831171319296",
            "id" : "880171319296"
          },
          {
            "name" : "Testtt",
            "screen_name" : "TF",
            "indices" : [
              "115",
              "120"
            ],
            "id_str" : "1339879",
            "id" : "13879"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "144"
      ],
      "favorite_count" : "0",
      "id_str" : "15625472009217",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "15621472009217",
      "created_at" : "Wed Aug 24 19:47:29 +0000 2022",
      "favorited" : false,
      "full_text" : "",
      "lang" : "en"
    }
  }
]